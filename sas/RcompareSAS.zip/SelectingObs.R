# R Program to Select Observations.
# Filename: SelectingObs.R 

setwd("c:/myRfolder")
load(file = "myWorkspace.RData")
print(mydata)


# ---Selecting Observations by Index---

# Print all rows.
print( mydata[ ] )
print( mydata[ , ] )
print( mydata[1:8, ] )

# Just observation 5.
print( mydata[5 , ] )

# Just the males:
print( mydata[ c(5, 6, 7, 8) , ] )
print( mydata[ 5:8, ] )

# Excluding the females with minus sign.
print( mydata[ -c(1, 2, 3, 4), ] )
print( mydata[ -(1:4), ] )

# Saving the Male (M) indices for reuse.
myMindices <- c(5, 6, 7, 8)
summary( mydata[myMindices, ] )

# Print a list of index numbers for each observation.
data.frame(myindex = 1:8, mydata)

# Select data using length as the end.
print( mydata[ 1:nrow(mydata),  ]  )
print( mydata[ 5:nrow(mydata),  ]  )


# ---Selecting Observations by Row Name---

# Display row names.
row.names(mydata)

# Select rows by their row name.
print( mydata[ c("1", "2", "3", "4"), ] )

# Assign more interesting names.
mynames <- c("Ann", "Cary", "Sue", "Carla",
             "Bob", "Scott", "Mike", "Rich")
print(mynames)

# Store the new names in mydata.
row.names(mydata) <- mynames
print(mydata)

# Print Ann's data.
print( mydata["Ann" , ] )
mydata["Ann" , ]

# Select the females by row name.
print( mydata[ c("Ann", "Cary", "Sue", "Carla"), ] )

# Save names of females to a character vector.
myFnames <- c("Ann", "Cary", "Sue", "Carla")
print(myFnames)

# Use character vector to select females.
print( mydata[ myFnames, ] )


# ---Selecting Observations Using Logic---

#Selecting first four rows using TRUE/FALSE.
myRows <- c(TRUE, TRUE, TRUE, TRUE,
  FALSE, FALSE, FALSE, FALSE)
print( mydata[myRows, ]  )

# Selecting first four rows using 1s and 0s.
myBinary <- c(1, 1, 1, 1, 0, 0, 0, 0)
print( mydata[myBinary, ] )
myRows <- as.logical(myBinary)
print( mydata[ myRows, ] )

# Use a logical comparison to select the females.
mydata$gender == "f"
print( mydata[ mydata$gender == "f", ] )
which( mydata$gender == "f" )
print( mydata[ which(mydata$gender == "f") , ] )

# Select females again, this time using a saved vector.
myFemales <- which( mydata$gender == "f" )
print(myFemales)
print( mydata[ myFemales , ] )

# Excluding the females using the "!" NOT symbol.
print( mydata[-myFemales , ] )

# Select the happy males.
HappyMales <- which(mydata$gender == "m"
  & mydata$q4 == 5)
print(HappyMales)
print( mydata[HappyMales , ] )

# Selecting observations using %in%.
myRsas <-
  which( mydata$workshop %in% c("R", "SAS") )
print(myRsas)
print( mydata[myRsas , ] )

# Equivalent selections using different
# ways to refer to the variables.

print( subset(mydata, gender == 'f') )

attach(mydata)
  print(  mydata[ which(gender == "f") , ] )
detach(mydata)

with(mydata,
  print ( mydata[ which(gender == "f"), ] )
)

print( mydata[ which(mydata["gender"] == "f") , ] )

print( mydata[ which(mydata$gender == "f") , ] )


# ---Selecting Observations by String Search---

# Search for row names that begin with "C".
myCindices <- grep("^C", row.names(mydata), value = FALSE)
print( mydata[myCindices , ] )

# Again, using wildcards.
myCindices <- grep( glob2rx("C*") ,
  row.names(mydata), value = FALSE)
print( mydata[myCindices , ] )


# ---Selecting Observations by subset Function---

subset(mydata, subset=gender == "f")

summary(
  subset( mydata, subset = gender == "m" & q4 == 5 )
)


# ---Generating indices A to Z from Two Row Names---

myMaleA <- which( row.names(mydata) == "Bob" )
print(myMaleA)

myMaleZ <- which( row.names(mydata) == "Rich" )
print(myMaleZ)
print( mydata[myMaleA:myMaleZ , ] )


# ---Creating a New Data Frame of Selected Observations---

# Creating a new data frame of only males (all equivalent).
myMales <- mydata[5:8, ]
print(myMales)

myMales <- mydata[ which( mydata$gender == "m" ) , ]
print(myMales)

myMales <- subset( mydata, subset = gender == "m" )
print(myMales)

# Creating a new data frame of only females (all equivalent).
myFemales <- mydata[1:3, ]
print(myFemales)

myFemales <- mydata[ which( mydata$gender == "f" ) , ]
print(myFemales)

myFemales <- subset( mydata, subset = gender == "f" )
print(myFemales)