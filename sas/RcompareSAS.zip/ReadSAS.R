# R Program to Read a SAS Export File 
# Filename: ReadSAS.R

setwd("c:/myRfolder")

# Reads ssd or sas7bdat if you have SAS installed.
library("foreign")
	 
mydata <- read.ssd("c:/myRfolder", "mydata",
  sascmd = "C:/Program Files/SAS/SASFoundation/9.2/sas.exe")
mydata

# Reads SAS export format without installing SAS
library("foreign")
library("Hmisc")

mydata <- sasxport.get("mydata.xpt") 
mydata