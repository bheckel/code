# Program to Read Excel Files.
# Filename: ReadExcel.R

# Program to Read Excel Files
# Filename: ReadExcel.R

# Do this once:
install.packages("xlsReadWrite")
library("xlsReadWrite")
xls.getshlib()

# Do this each time:
library("xlsReadWrite")
setwd("c:/myRfolder")

mydata <- read.xls("mydata.xls")
mydata

save(mydata, "mydata.RData")