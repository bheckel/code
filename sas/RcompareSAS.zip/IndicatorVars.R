# R Program for Creating Indicator Variables
# Filename: IndicatorVars.R

setwd("c:/myRfolder")
load("mydata100.RData")
attach(mydata100)
head(mydata100)

r     <- as.numeric(workshop == "R"    )
sas   <- as.numeric(workshop == "SAS"  )
spss  <- as.numeric(workshop == "SPSS" )
stata <- as.numeric(workshop == "Stata")
head( data.frame(
  workshop, r, sas, spss, stata) )

lm(posttest ~ pretest + sas + spss + stata)
lm(posttest ~ pretest + workshop)
head(workshop)
table(workshop)

workshop <- relevel(workshop, "SAS")
table(workshop)
coef( lm(posttest ~ pretest + workshop) )

library(nnet)
head( class.ind(workshop) )