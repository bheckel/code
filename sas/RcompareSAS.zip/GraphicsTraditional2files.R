# Traditional Graphics in R with results routed to files.
# Filename: GraphicsTraditional2files.R .

setwd("c:/myRfolder")
load(file="mydata100.Rdata")
attach(mydata100) 
options(width=63)

setwd("C:/Users/Bob/Documents/Books/R for SAS and SPSS Users/R for SAS & SPSS - 2nd Edition/r4sas/chapter15")

# Request it to ask you to click for new graph.
par(ask=FALSE, mfrow=c(1,1) )

par( mar=c(4,2,4,2)+0.1 )

postscript(file="plotFunction.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=7.0)
par( mfrow = c(3, 2) )
plot(workshop,           main="plot(workshop)" )            # Bar plot
plot(posttest,           main="plot(posttest)" )            # Index plot
plot(workshop, gender,   main="plot(workshop, gender)" )    # Split bar plot
plot(workshop, posttest, main="plot(workshop, posttest)" )  # Box plot
plot(posttest, workshop, main="plot(posttest, workshop)" )  # Strip plot
plot(pretest, posttest,  main="plot(pretest, posttest)" )   # Scatter plot
dev.off()
par( mfrow = c(1, 1) )

#---Barplots---

# Barplots of counts via table

postscript(file="barplot4060.eps", 
  horizontal=FALSE, paper="special", width=3.5, height=3.5)
par( mar=c(1,2,1,1)+0.1 ) 
barplot( c(40,60) )
dev.off()
par( mar=c(5,4,4,2)+0.1 ) 

postscript(file="barplot4060.eps", 
  horizontal=FALSE, paper="special")
barplot( c(40,60) )
dev.off()

postscript(file="barplotQ4.eps", 
    horizontal=FALSE, paper="special", width=4.5, height=4.5)
# This is in book: barplot(q4)
# as.vector will strip out the label attribute from Hmisc to get the plot
par( mar=c(1,2,1,1)+0.1 ) 
barplot( as.vector(q4) )
dev.off()
par( mar=c(5,4,4,2)+0.1 )

table(q4)

postscript(file="barplotTableQ4.eps", 
    horizontal=FALSE, paper="special", width=4.5, height=4.5)
par( mar=c(1,2,1,1)+0.1 ) 
barplot( table(q4) )
dev.off()

barplot( workshop )
barplot( table(workshop) )
barplot(gender)

postscript(file="barplotTableGender.eps",
    horizontal=FALSE, paper="special", width=4.5, height=4.5) 
par( mar=c(2,2,1,1)+0.1 )
barplot( table(gender) )
dev.off()

postscript(file="barplotHoriz.eps", 
    horizontal=FALSE, paper="special", width=4.5, height=4.5)
par( mar=c(2,2,1,1)+0.1 )
barplot( table(workshop), horiz=TRUE)
dev.off()

postscript(file="barplotStacked.eps", 
    horizontal=FALSE, paper="special", width=4.5, height=4.5)
par( mar=c(1,2,1,1)+0.1 )
barplot( as.matrix( table(workshop) ),
  beside = FALSE)
dev.off()

# Grouped barplots & mosaic plots

postscript(file="barplotGenderWorkshop.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)
par( mar=c(2,2,1,1)+0.1 )
barplot( table(gender,workshop) )
dev.off()

postscript(file="plotWorkshopGender.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)
par( mar=c(4,4,1,3)+0.1 )
plot( workshop,gender )
dev.off()

postscript(file="mosaicplotWorkshopGender.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)
par( mar=c(2,2,1,2)+0.1 )
mosaicplot( table(workshop,gender) )
dev.off()

postscript(file="mosaicplotTitanic.eps", 
  horizontal=FALSE, paper="special", width=6.0, height=6.0)
par( mar=c(2,2,1,2)+0.1 )
mosaicplot(~ Sex + Age + Survived, 
  data = Titanic, color = TRUE)
dev.off()




# Barplots of means via tapply

myMeans <- tapply(q1, gender, mean, na.rm=TRUE)

postscript(file="barplotMeans.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)
par( mar=c(2,2,1,2)+0.1 )
barplot(myMeans)
dev.off()

myMeans <- tapply(q1, list(workshop,gender), mean,na.rm=TRUE)
postscript(file="barplotMeansWG.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)
par( mar=c(2,2,1,2)+0.1 )
barplot(myMeans, beside=TRUE)
dev.off()


#---Adding main title, color and legend---

postscript(file="barplotLegend.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)

par( mar=c(4,4,4,2)+0.1 )
barplot( table(gender,workshop), 
  beside = TRUE,
  col    = c("gray90","gray60"),
  xlab   = "Workshop",
  ylab   = "Count",
  main   = "Number of males and females \nin each workshop" )
legend( "topright",
  legend = c("Female","Male"), 
  fill   = c("gray90","gray60") )

dev.off()

# A manually positioned legend at 10,15.
legend( 10,15,
  legend = c("Female","Male"), 
  fill   = c("gray90","gray60") )

#---Mulitple Graphs on a Page---

par()
head( par() )

postscript(file="barplotMultiframe.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)

par( mar=c(3,3,1,1)+0.1 ) 
par( mfrow=c(2,2) )

barplot( table(gender,workshop) )
barplot( table(workshop,gender) )
barplot( table(gender,workshop), beside=TRUE )
barplot( table(workshop,gender), beside=TRUE ) 

dev.off()

par( mfrow=c(1,1) ) #Sets back to 1 plot per page.
par( mar=c(5,4,4,2)+0.1 ) 



#---Piecharts---

postscript(file="pieWorkshop.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)

par( mar=c(0,1,2,1)+0.1 ) 
pie( table(workshop), 
  col=c("white","gray90","gray60","black" ) )
par( mar=c(5,4,4,2)+0.1 ) 

dev.off()



#---Dotcharts---

postscript(file="dotchartWG.eps", 
  horizontal=FALSE, paper="special", width=8, height=8)

par( mar=c(2,2,2,2)+0.1 ) 
dotchart( table(workshop,gender),
  pch=19, cex=1.5)

dev.off()

# ---Histograms---

postscript(file="histPosttest.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)
par( mar=c(2,2,2,2)+0.1 ) 
hist(posttest)

dev.off()


# More bins plus density and ticks at values.

postscript(file="histDensity.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)
par( mar=c(2,2,1,2)+0.1 ) 
hist(posttest, breaks=20, probability=TRUE)
lines( density(posttest) )
rug(posttest)

dev.off()

# Histogram of males only.

postscript(file="histMales.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)

par( mar=c(4,4,1,2)+0.1 )
hist( posttest[ which(gender=="Male") ],
  col  = "gray60",
  main = "Histogram for Males Only")

dev.off()

# Plotting above two on one page, 
# matching breakpoints.

postscript(file="histMultiframe.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=6.5)
par(mfrow=c(2,1) )
par( mar=c(4,4,1,2)+0.1 )
hist(posttest, col="gray90", main="Histogram for Both Genders",
  breaks=c(50,55,60,65,70,75,80,85,90,95,100) )
hist(posttest[ which(gender=="Male") ], 
  col="gray60", main="Histogram for Males Only",
  breaks=c(50,55,60,65,70,75,80,85,90,95,100) )
par(mfrow=c(1,1) )

dev.off()

# Could have used either of these:
# breaks=seq(from=50, to=100, by=5) )
# breaks=seq(50,100,5) )

# Histograms overlaid

postscript(file="histOverlaidManual.eps", 
  horizontal=FALSE, paper="special", width=6.5, height=6.5)

par( mar=c(4,4,1,2)+0.1 )
hist( posttest, col="gray90",
  breaks=seq(from=50, to=100, by=5) )
hist(posttest[ which(gender=="Male") ], 
  col="gray60",
  breaks=seq(from=50, to=100, by=5),
  add=TRUE )
legend( "topright", c("Female","Male"), 
  fill=c("gray90","gray60") )

dev.off()

# Same plot but extracting $breaks 
# from previous graph.

postscript(file="histOverlaidAuto.eps", 
  horizontal=FALSE, paper="special", width=6.5, height=6.5)

par( mar=c(4,4,1,2)+0.1 )
myHistogram <- hist(posttest, col="gray90")
names(myHistogram)
myHistogram$breaks
myHistogram$xlim
hist(posttest[ which(gender=="Male") ], 
  col='gray60', 
  add=TRUE, breaks=myHistogram$breaks)
legend( "topright", c("Female","Male"), 
  fill=c("gray90","gray60") )

dev.off()

# What else does myHistogram hold?
class(myHistogram)
myHistogram

#---Q-Q plots---

library("car")
postscript(file="qqplot.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)

par( mar=c(4,4,1,1)+0.1 )
qq.plot(posttest, 
  labels=row.names(mydata100), 
  col="black" )

dev.off()
detach("package:car")

myQQ <- qqnorm(posttest) #Not shown in text.
identify(myQQ)

#---Stripcharts---

postscript(file="stripMultiframe.eps", 
  horizontal=FALSE, paper="special", width=6.0, height=6.0)

par(mfrow=c(2,1) )
par( mar=c(2,1,2,1)+0.1 )
stripchart(posttest, method="jitter",
  main="Stripchart with Jitter")
stripchart(posttest, method="stack",
  main="Stripchart with Stacking")

dev.off()
par( mfrow=c(1,1) )
par( mar=c(5,4,4,2)+0.1 )

postscript(file="stripWorkshop.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)

par( las=2, mar=c(4,4,1,1)+0.1  )
stripchart(posttest~workshop, method="jitter")

dev.off()

par( las=0, mar=c(5,4,4,2)+0.1 )



# --- Scatterplots ---

#postscript(file="scatterPrePost.eps",
#  Must save this one manually after selecting obs 92!
  horizontal=FALSE, paper="special", width=4.5, height=4.5)

par( las=0, mar=c(4,4,1,1)+0.1 )
plot(pretest,posttest) #now use identify below...

#dev.off()

# Find low score interactively.
# Click 2nd mouse button to choose stop.
identify(pretest,posttest)

# Check it manually.
mydata100[pretest<60, ]

# Different types of plots.
postscript(file="scatterMultiframe.eps", 
  horizontal=FALSE, paper="special", width=8, height=8)

par( mar=c(4,4,2,2)+0.1 )
par( mfrow=c(2,2) )
plot( pretest, posttest, type = "p", main = 'type="p"' )
plot( pretest, posttest, type = "l", main = 'type="l"' )
plot( pretest, posttest, type = "b", main = 'type="b"' )
plot( pretest, posttest, type = "h", main = 'type="h"' )
dev.off()

par( mfrow=c(1,1) )

# Scatterplots with Jitter

postscript(file="scatterJitter.eps", 
  horizontal=FALSE, paper="special", width=8.0, height=3.0)

par( mar=c(4,4,2,2)+0.1 )
par( mfrow=c(1,2) )
plot( q1, q4,
  main="Likert Scale Without Jitter")
plot( jitter(q1,3), jitter(q4,3),
  main="Likert Scale With Jitter")

dev.off()



# Scatterplot of large data sets.

# Example with pch="." and jitter.
pretest2   <- round( rnorm( n=5000, mean=80, sd=5) ) 
posttest2  <- 
  round( pretest2 + rnorm( n=5000, mean=3, sd=3) )
pretest2[pretest2>100] <- 100
posttest2[posttest2>100] <- 100

postscript(file="scatter5000.eps", 
  horizontal=FALSE, paper="special", width=8.0, height=3.0)

par( mar=c(4,4,3,2)+0.1 )
par(mfrow=c(1,2) )
plot( pretest2, posttest2,
  main="5,000 Points, Default Character \nNo Jitter")
plot( jitter(pretest2,4), jitter(posttest2,4), pch=".",
  main="5,000 Points Using pch='.' \nand Jitter")

dev.off()

par(mfrow=c(1,1) )



# Hexbin plot
# The hexbin function ignores all par settings and
# will not route to file. Run and use File> Save as...
# then save it as postscript.

library("hexbin")
par( mar=c(2,4,1,2)+0.1 )
plot( hexbin(pretest2, posttest2) )
detach("package:hexbin")

dev.off()

postscript(file="smoothScatter5000.eps", 
  horizontal=FALSE, paper="special", width=4.0, height=4.0)
par( mar=c(2, 4, 1, 2)+0.1 )
smoothScatter( pretest2,posttest2)
  main="5,000 Points Using smoothScatter")

dev.off()

rm(pretest2,posttest2) # Cleaning up.

# Scatterplot with different lines added.

postscript(file="scatterLines.eps", 
  horizontal=FALSE, paper="special", width=6.5, height=6.5)

par( mar=c(4,4,1,2)+0.1 )
plot(posttest~pretest)
abline(h=75,v=75)
abline(a=0, b=1, lty=5)
abline( lm(posttest~pretest),    lty=1 )
lines( lowess(posttest~pretest), lty=3 )
# turned off: legend( 57, 97,
legend("topleft",
  c( "Regression", "Lowess", "Posttest=Pretest" ), 
  lty=c(1,3,5) )

dev.off()
 


# Scatterplot of q1 by q2 separately by gender.

postscript(file="scatterRegGender.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)

par( mar=c(4,4,1,2)+0.1 )
plot(posttest~pretest, 
  pch=as.numeric(gender) )

abline( lm( posttest[ which(gender=="Male") ] 
          ~ pretest[ which(gender=="Male")  ] ),
        lty=1 )

abline( lm( posttest[ which(gender=="Female") ] 
          ~ pretest[ which(gender=="Female")  ] ),
        lty=2 )

legend("topleft", c("Male","Female"), 
         lty=c(1,2), pch=c(2,1) )

dev.off()


# Coplots: conditioned scatterplots

postscript(file="coplotWorkshop.eps", 
  horizontal=FALSE, paper="special", width=6.00, height=6.0)

# coplot ignores all par settings.
coplot( posttest~pretest | workshop)

dev.off()

postscript(file="coplotQ1.eps", 
  horizontal=FALSE, paper="special", width=6.0, height=6.0)
coplot( posttest~pretest | q1)
dev.off()


# Scatterplot with Confidence Ellipse.
library("car")

postscript(file="scatterEllipse.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)

par( mar=c(4,4,1,1)+0.1 )
data.ellipse(pretest, posttest, 
  levels=.95,
  col="black")

dev.off()

detach("package:car")



# Confidence Intervals: A small example
x  <- c(1,2,3,4)
y1 <- c(1,2,3,4)
y2 <- c(2,3,4,5)
y3 <- c(3,4,5,6)
yMatrix <- cbind(y1,y2,y3)
yMatrix

# Just the points
postscript(file="scatterCI1.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)

par( mar=c(4,4,1,1)+0.1 )
plot( x, y2, xlim=c(1,4), ylim=c(1,6), cex=1.5 )

dev.off()

# The points with pseudo-confidence interval
postscript(file="scatterCI2.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)

par( mar=c(4,4,1,1)+0.1 )
plot( x, y2, xlim=c(1,4), ylim=c(1,6), cex=1.5 )
matlines( x, yMatrix, lty=c(2,1,2), col="black" )

dev.off()


rm( x, y1, y2, y3, yMatrix)

# Confidence Intervals: A realistic example
myIntervals <- 
  data.frame(pretest=seq(from=60, to=100, by=5))
myIntervals
myModel <- lm( posttest~pretest )
myIntervals$pp <- predict( myModel, 
  interval="prediction", newdata=myIntervals)
myIntervals$pc <- predict( myModel, 
  interval="confidence", newdata=myIntervals)
myIntervals
class( myIntervals$pp )
myIntervals$pp

postscript(file="scatterCI3.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)

par( mar=c(4,4,2,1)+0.1 )
plot( pretest, posttest,
  ylim=range( myIntervals$pretest, 
    myIntervals$pp, na.rm=TRUE) )
matlines(myIntervals$pretest, myIntervals$pc, 
  lty=c(1,2,2), col="black" )
matlines(myIntervals$pretest, myIntervals$pp, 
  lty=c(1,3,3), col="black" )

dev.off()


# Scatterplot plotting text labels.

postscript(file="scatterLabels.eps", 
  horizontal=FALSE, paper="special", width=6.0, height=6.0)

par( mar=c(4,4,1,1)+0.1 )
plot(pretest, posttest, 
  pch=as.character(gender) )

dev.off()

postscript(file="scatterRowNames.eps", 
  horizontal=FALSE, paper="special", width=6.0, height=6.0)

par( mar=c(4,4,1,1)+0.1 )
plot(pretest, posttest, type="n" )
text(pretest, posttest, 
  label=row.names(mydata100) )

dev.off()


# Scatterplot matrix of whole data frame.
plot(mydata100[3:8]) #Not shown with text.

postscript(file="scatterMatrix.eps", 
  horizontal=FALSE, paper="special", width=6.0, height=6.0)

# plot passes to pairs, which ignores par settings.
par( mar=c(2,2,1,1)+0.1 )
plot(mydata100[3:8], gap=0, cex.labels=0.9)

dev.off()

postscript(file="scatterMatrixSmooth.eps", 
  horizontal=FALSE, paper="special", width=6.0, height=6.0)
pairs(mydata100[3:8], gap=0,
  lower.panel=panel.smooth,
  upper.panel=panel.smooth)
dev.off()



# Dual axes
#Adds room for label on right margin.

postscript(file="scatterDual.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.0)

par( mar = c(5, 5, 4, 5) )
plot(pretest, posttest,
  xlab = "Pretest Score",
  ylab = "Posttest Score")
axis(4)
mtext("Posttest Score", side = 4, line = 3)
grid()

dev.off()




#---Boxplots---

postscript(file="boxWorkshop.eps",
  horizontal=FALSE, paper="special", width=4.5, height=4.5)

par( mar=c(2,2,2,1)+0.1 )
plot(workshop, posttest)
dev.off()


postscript(file="boxMultiframe.eps", 
  horizontal=FALSE, paper="special", width=8.0, height=8.0)

par( mar=c(2,2,1,1)+0.1 )
par( mfrow=c(2,2) )
boxplot(posttest)
boxplot(pretest,posttest,notch=TRUE)
boxplot(posttest~workshop)
par( las=2, mar=c(7,4,1,1)+0.1 )
boxplot(posttest~workshop:gender)

dev.off()



#---Error bar plots---


library("gplots")
par( mfrow=c(1,1) )

postscript(file="errorBar.eps", 
  horizontal=FALSE, paper="special", width=4.5, height=4.5)

par( mar=c(4,4,2,1)+0.1 )
plotmeans(posttest ~ workshop)

dev.off()
detach("package:gplots")


postscript(file="interaction.eps", 
  horizontal=FALSE, paper="special", width=7.0, height=7.0)

par( mar=c(4,4,3,2)+0.1 )
interaction.plot( workshop, gender, posttest)

dev.off()

# ---Adding Labels---

postscript(file="manyMods.eps", 
  horizontal=FALSE, paper="special", width=8, height=8)

# Many annotations at once.
par( mar = c(5, 4, 4, 2) + 0.1 )
par( mfrow = c(1, 1) )
#par(family = "serif")
plot(pretest, posttest,
  main = "My Main Title" ,
  xlab = "My xlab text" ,
  ylab = "My ylab text",
  sub  = "My subtitle ",
  pch  = 2)

text(66, 88, "My Example Formula")
text(65, 85,
  expression( hat(beta) ==
  (X^t * X)^{-1} * X^t * Y) )

text(  80, 65, "My label with arrow", pos = 3)
arrows(80, 65, 58.5, 59, length = 0.1)
abline(h = 75, v = 75)
abline(a = 0,  b = 1, lty = 5)
abline(    lm(posttest ~ pretest), lty = 1 )
lines( lowess(posttest ~ pretest), lty = 3 )
legend( 64, 99,
 legend = c("Regression", "Lowess", "Posttest=Pretest"),
 lty    = c(1, 3, 5) )

mtext("line=0", side=1, line=0, at=57 )
mtext("line=1", side=1, line=1, at=57 )
mtext("line=2", side=1, line=2, at=57 )
mtext("line=3", side=1, line=3, at=57 )
mtext("line=4", side=1, line=4, at=57 )

mtext("line=0", side=2, line=0, at=65 )
mtext("line=1", side=2, line=1, at=65 )
mtext("line=2", side=2, line=2, at=65 )
mtext("line=3", side=2, line=3, at=65 )

mtext("line=0", side=3, line=0, at=65 )
mtext("line=1", side=3, line=1, at=65 )
mtext("line=2", side=3, line=2, at=65 )
mtext("line=3", side=3, line=3, at=65 )

mtext("line=0", side=4, line=0, at=65 )
mtext("line=1", side=4, line=1, at=65 )

dev.off()

# Restore settings.
par( mar=c(5,4,4,2)+0.1 ) 
par(family="sans")

#---Scatterplot with bells & whistles---
#       Not shown in book

plot(pretest,posttest,pch=19,
  main="Scatterplot of Pretest and Postest", 
  xlab="Test score before taking workshop", 
  ylab="Test score after taking workshop" )
myModel <- lm(posttest~pretest)
abline(myModel)
arrows(60,82,63,72.5, length=0.1)
text(60,82,"Linear Fit", pos=3)
arrows(70,62,58.5,59, length=0.1)
text(70,62,"Double check this value", pos=4)
# Use locator() or:
# predict(myModel,data.frame(pretest=75) )

