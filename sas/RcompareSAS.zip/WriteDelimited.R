# R Program to Write a Text File.
# Filename: WriteDelimited.R

setwd("c:/myRfolder")

write.csv(mydata,   "mydataFromR.csv")

write.table(mydata, "mydataFromR.txt")

write.table(mydata,
  file      = "mydataFromR.txt",
  quote     = FALSE,
  sep       = "\t",
  na        = " ",
  row.names = TRUE,
  col.names = TRUE)

# Look at the contents of the last file.
file.show("mydataFromR.txt")