# R Program to Import an SPSS Data File.
# Filename: ReadSPSS.R

setwd("c:/myRfolder")

library(foreign)
mydata <- read.spss("mydata.sav",
  use.value.labels = TRUE,
  to.data.frame    = TRUE)
mydata

mydata[mydata == " "] <- NA

library("Hmisc")
mydata <- spss.get("mydata.por",
  use.value.labels = TRUE)
mydata

save(mydata, "mydata.RData")