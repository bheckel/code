# R Program for Demonstrating the Apply Family of Functions.
# Filename: ApplyingFunctions.R

setwd("c:/myRfolder")
load(file = "mydata.RData")
mydata
attach(mydata)

# Mean of the q variables
mean(mydata[3:6], na.rm = TRUE)

# Create mymatrix.
mymatrix <- as.matrix( mydata[ ,3:6] )
mymatrix

# Get mean of whole matrix.
mean(mymatrix, na.rm = TRUE)

# Get mean of matrix columns
apply(mymatrix, 2, mean, na.rm = TRUE)

# Get mean of matrix rows.
apply(mymatrix, 1, mean, na.rm = TRUE)
rowMeans(mymatrix, na.rm = TRUE)

# Add row means to mydata.
mydata$meanQ <- apply(mymatrix, 1, mean, na.rm = TRUE)
mydata$meanQ <- rowMeans(mymatrix, na.rm = TRUE)
mydata <- transform(mydata,
  meanQ = rowMeans(mymatrix, na.rm = TRUE)
)
mydata

# Means of data frames & their vectors.
lapply(mydata[ ,3:6], mean, na.rm = TRUE)
sapply(mydata[ ,3:6], mean, na.rm = TRUE)

mean(
  sapply(mydata[ ,3:6], mean, na.rm = TRUE)
)

# Length of data frames & their vectors.
length(mydata[ ,"q3"] )
nrow(mydata)
is.na( mydata[ ,"q3"] )
!is.na( mydata[ ,"q3"] )
sum( !is.na( mydata[ ,"q3"] ) )

# Like the SAS/SPSS n from stat procedures.
library("prettyR")
sapply(mydata, valid.n)

apply(myMatrix, 1, valid.n)
mydata$myQn <- apply(myMatrix, 1, valid.n)
mydata

# Applying Z Transformation

myZs    <- apply(mymatrix, 2, scale)
myZs
myRanks <- apply(mymatrix, 2, rank)
myRanks

# Applying Your Own Functions

apply(mymatrix, 2, mean, sd) # No good!

mystats <- function(x) {
  c( mean=mean(x, na.rm = TRUE),
       sd=sd  (x, na.rm = TRUE) )
}
apply(mymatrix, 2, mystats)

apply(mymatrix, 2, function(x){
    c( mean = mean(x, na.rm = TRUE),
	     sd = sd(  x, na.rm = TRUE) )
} )