# R Program for Dates & Times  
# Filename: DateTime.R

setwd("c:/myRfolder")
giants <- read.fwf(
   file        = "giants.txt",
   width       = c(15,11,11),
   col.names   = c("name",      "born",      "died"),
   colClasses  = c("character", "character", "POSIXct"),
   row.names   = "name",
   strip.white = TRUE,
)
giants
class(giants$born)  # A character vector.

library("lubridate")
giants$born <- mdy(giants$born)
giants

class(giants$born)
class(giants$died)

giants  # They display in yyyy-mm-dd by default.
attach(giants)

unclass( born )
as.numeric( born )
as.POSIXct(
  c(-2520460800,-3558556800,-2207952000,
    -1721347200, -2952201600),
  origin="1960-01-01", tz="UTC" )

#---Calculating Durations---

age <- difftime(died, born, units="secs")
age
age <- difftime(died, born)
age # now we have age in days

mode( age )
class( age )  # it's a difftime object

as.period(age)

age/365.2425  # age in years
giants$age <- round(
  as.numeric( age/365.2425 ), 2 )
giants

now()  # Current date-time.
difftime( now(), died ) / 365.2425

# Again, using subtraction 
age <- died - born  # age in days
age

# Most of these commands will create output 
# quite diffent from that shown the 2nd edition:
age / 365.2425   # Age in years, mislabeled.
mode(age)
class( age )     # it's an interval object.
names( age )
sapply( age, unclass )


#---Adding Durations to Date-Times---

age <- as.duration(
         c(2286057600,2495664000,2485382400,
         2685916800,1935705600)
)
class(age)
born + age
died


#---Accessing Date-Time Elements---

year(born)
month(born)
month(born, label = TRUE)
day(born)   # day of month
wday(born)  # day of week
wday(born, label = TRUE, abbr = FALSE)
yday(born)

#---Creating Date-Times from Elements---

myYear  <- year(died)
myMonth <- month(died)
myDay   <- day(died)

myDateString <- paste(myYear, myMonth, myDay, sep="-")
myDateString
died2 <- ymd(myDateString)
died2

#---Logical Comparisons with Date-Times---

giants[ born > mdy("1/1/1900") , ]

#---SAS Picture Format Example---

myDateText <- format(born, "%B %d, %Y is day %j of %Y")
myDateText

myDateText <- format(born,
  "was born on the %jth day of %Y")
for (i in 1:5) cat(rownames(giants)[i],
  myDateText[i],"\n")

# Two-Digit Years

my1969 <- mdy("08/31/69")
my1969
my1968 <- mdy("08/31/68")
my1968
my1968 <- my1968 - as.duration(100 * 365.2425 * 24 * 60 * 60)
my1968

as.POSIXlt("08/31/68", format="%m/%d/%y")
as.POSIXlt("08/31/69", format="%m/%d/%y")

as.POSIXlt("08/31/69", format="%m/%d/%y")