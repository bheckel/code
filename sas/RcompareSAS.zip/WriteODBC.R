# Program to Write to a Database.
# Filename: WriteDatabase.R

setwd("c:/myRfolder")
load("mydata.RData")

library(RODBC)
myConnection <- odbcConnectExcel("mydataFromR.xls", readOnly = FALSE)
sqlSave(myConnection, mydata)
close(myConnection)