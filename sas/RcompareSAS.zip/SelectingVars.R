# R Program for Selecting Variables.
# Filename: SelectingVars.R

# Uses many of the same methods as selecting observations.
setwd("c:/myRfolder")
load(file = "myData.RData")

# This refers to no particular variables,
# so all are printed.
print(mydata)


# ---Selecting Variables by Index Number---

# These also select all variables by default.
print( mydata[ ] )
print( mydata[ , ] )

# Select just the 3rd variable, q1.
print( mydata[ ,3] ) #Passes q3 as a vector.
print( mydata[3] )   #Passes q3 as a data frame.

# These all select the variables q1,q2,q3 and q4 by indices.
print( mydata[ c(3, 4, 5, 6) ] )
print( mydata[ 3:6 ] )

# These exclude variables q1,q2,q3,q4 by indices.
print( mydata[ -c(3, 4, 5, 6) ] )
print( mydata[ -(3:6) ] )

# Using indices in a numeric vector.
myQindices <- c(3, 4, 5, 6)
myQindices
print( mydata[myQindices] )
print( mydata[-myQindices] )

# This displays the indices for all variables.
print( data.frame( names(mydata) ) )

# Using ncol to find the last index.
print( mydata[ 1:ncol(mydata) ] )
print( mydata[ 3:ncol(mydata) ] )


# ---Selecting Variables by Column Name---

# Display all variable names.
names(mydata)

# Select one variable.
print( mydata["q1"] ) #Passes q1 as a data frame.
print( mydata[ ,"q1"] ) #Passes q1 as a vector.

# Selecting several.
print( mydata[ c("q1", "q2", "q3", "q4") ] )

# Save a list of variable names to use.
myQnames <- c("q1", "q2", "q3", "q4")
myQnames
print( mydata[myQnames] )

# Generate a list of variable names.
myQnames <- paste( "q", 1:4, sep = "")
myQnames
print( mydata[myQnames] )


# ---Selecting Variables Using Logic---

# Select q1 by entering TRUE/FALSE values.
print( mydata[ c(FALSE,FALSE,TRUE,FALSE,FALSE,FALSE) ] )

# Manually create a vector to get just q1.
print( mydata[ as.logical( c(0, 0, 1, 0, 0, 0) ) ] )

# Automatically create a logical vector to get just q1.
print( mydata[ names(mydata) == "q1" ] )

# Exclude q1 using NOT operator "!".
print( mydata[ !names(mydata) == "q1" ] )

# Use the OR operator, "|" to select q1 through q4,
# and store the resulting logical vector in myqs.
myQtf <- names(mydata) == "q1" |
         names(mydata) == "q2" |
         names(mydata) == "q3" |
         names(mydata) == "q4"
myQtf
print( mydata[myQtf] )

# Use the %in% operator to select q1 through q4.
myQtf <- names(mydata) %in% c("q1", "q2", "q3", "q4")
myQtf
print( mydata[myQtf] )


# ---Selecting Variables by String Search---

# Use grep to save the q variable indices.
myQindices <- grep("^q", names(mydata), value = FALSE)
myQindices
print( mydata[myQindices] )

# Use grep to save the q variable names (value = TRUE now).
myQnames <- grep("^q", names(mydata), value = TRUE)
myQnames
print( mydata[myQnames] )

# Use %in% to create a logical vector
# to select q variables.
myQtf <- names(mydata) %in% myQnames
myQtf
print( mydata[myQtf] )

# Repeat example above but searching for any
# variable name that begins with q, followed
# by one digit, followed by anything.
myQnames <- grep("^q[[:digit:]]\{1\}",
   names(mydata), value = TRUE)
myQnames
myQtf <- names(mydata) %in% myQnames
myQtf
print( mydata[myQtf] )

# Example of how glob2rx converts q* to ^q.
glob2rx("q*")


# ---Selecting Variables Using $ Notation---

print( mydata$q1 )
print( data.frame(mydata$q1, mydata$q2) )


# ---Selecting Variables by Simple Name---

# Using the "attach" function.
attach(mydata)
print(q1)
print( data.frame(q1, q2, q3, q4) )
detach(mydata)

# Using the "with" function.
with( mydata,
  summary( data.frame(q1, q2, q3, q4) )
)


# ---Selecting Variables with subset Function---

print( subset(mydata, select = q1:q4) )
print( subset(mydata,
  select = c(workshop, q1:q4)
) )


# ---Selecting Variables by List Subscript---

print( mydata[[3]] )


# ---Generating indices A to Z from Two Variables---

myqA <- which( names(mydata) == "q1" )
myqA
myqZ <- which( names(mydata) == "q4" )
myqZ
print( mydata[myqA:myqZ] )


# ---Selecting Numeric or Character Variables---

is.numeric( mydata$workshop )
is.numeric( mydata$q1 )

# Find numeric variables
myNums <- sapply(mydata, is.numeric)
myNums

print( mydata[myNums] )

myA <- which( names(mydata) == "gender" )
myA
myZ <- which( names(mydata) == "q3" )
myZ

myRange <- 1:length(mydata) %in% myA:myZ
myRange

print( mydata[ myNums & myRange ] )

apply(mydata, 2, is.numeric)
apply(mydata, 2, class)

as.matrix(mydata)


# ---Creating a New Data Frame of Selected Variables---

myqs <- mydata[3:6]
myqs
myqs <- mydata[ c("q1", "q2", "q3", "q4") ]
myqs
myqs <- data.frame(mydata$q1, mydata$q2,
                   mydata$q3, mydata$q4)
myqs
myqs <- data.frame(q1 = mydata$q1, q2 = mydata$q2,
                   q3 = mydata$q3, q4 = mydata$q4)
myqs

attach(mydata)
myqs <- data.frame(q1, q2, q3, q4)
myqs
detach(mydata)

myqs <- subset(mydata, select = q1:q4)
myqs