# R Program for Character Strings using R's base built-in functions
# Filename: CharacterStringsBase.R

setwd("c:/myRfolder")
giants <- read.fwf(
   file="giants.txt",
   width=c(15,11,11), #width of 20 for giants2.
   col.names=c("name","born","died"),
   colClasses=c("character"),
   #row.names="name", #turned off
   strip.white=TRUE,
)
attach(giants)
giants

nchar(name)

SAS: upcase, lowcase, propcase

substr(name,1,5)
myNameList <- strsplit(name, split=" ")

myNameVector <- unlist( myNames )
myFirst <- myNameVector[ seq( 1, length(myNameVector), 2) ]
myFirst
myLast <- myNameVector[ seq( 2, length(myNameVector), 2) ]
myLast

myLastFirst <- paste( myLast, myFirst, sep=", ")
myLastFirst

myLast <- sapply(myNames,[2])

paste( myFirst, "Smith", sep=" ")

match(myLast, c("Tukey") )
myLast=="Tukey"
which(myLast=="Tukey")

myTable <- c("Box","Bayes","Fisher","Tukey")

myFound <- myLast %in% myTable
myFound
name[ myFound ]

myMatched <- match( myLast, table=myTable )
myMatched
myFound <- myMatched[ !is.na(myMatched) ]
myTable[ myFound ]

myFound <- unique( myLast[ !is.na(myMatched) ] )
myFound
myIgnored <- unique( myLast[ is.na(myMatched) ] )
myIgnored

myLast
myFirstLetter
letters
LETTERS
LETTERS[1:13]
LETTERS[14:26]

myFirstLetter <- substr(myLast, 1, 1)
myFirstLetter

name[ myFirstLetter %in% LETTERS[1:13] ]
name[ myFirstLetter %in% LETTERS[14:26] ]