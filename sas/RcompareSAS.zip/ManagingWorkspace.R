# R Program for Managing Files and Workspace
# Filename: ManagingWorkspace.R

ls()

setwd("c:/myRfolder")
load("myall.RData")
ls()

# List objects that begin with "my".
ls(pattern = "my")

# Get attributes and structure of mydata.
attributes(mydata)
str(mydata)

# Get structure of the lm function.
str(lm)

# List all objects' structure.
ls.str()

# Use the Hmisc contents function.
install.packages("Hmisc")
library("Hmisc")
contents(mydata)

# ---Understanding Search Paths---

setwd("c:/myRfolder")
load("mydata.RData")
ls()
search()
ls(1)  # This uses position number.
ls(".GlobalEnv")  # This does the same using name.

head( ls(2) )
head( ls("package:stats") )  # Same result.

# See how attaching mydata change the path.
attach(mydata)
search()
ls(2)

# Create a new variable.
q4 <- sqrt(q4)
q4
ls(1)
ls(2)

# Attaching data frames.
detach(mydata)
attach(mydata)
attach(mydata)
search()

# Clean up for next example,
# or restart R with an empty workspace.
detach(mydata)
detach(mydata)
rm( list = ls() )

# Attaching packages
library("prettyR")
describe(mydata)
detach("package:prettyR")

library("Hmisc")
describe(mydata)
detach("package:Hmisc")

library("prettyR")
library("Hmisc")
prettyR::describe(mydata)
Hmisc::describe(mydata)

# Attaching files.
x <- c(1, 2, 3, 4, 5, 6, 7, 8)
attach("myall.RData")
search()
q4 <- q4

ls(1)  # Your workspace.
ls(2)  # The attached file.
detach(2)

# Removing objects.
rm(mydata)
load(file = "myall.RData")
ls()
# Example not run:
# rm(workshop, gender, q1, q2, q3, q4)
myQvars <- ls(pattern = "q")
myQvars

myDeleteItems <- c("workshop","gender",myQvars)
myDeleteItems

myDeleteItems
rm( list = myDeleteItems )

ls()
rm( myQvars, myDeleteItems )
ls()

# Wrong!
rm(myDeleteItems)
rm( c("workshop", "gender", "q1", "q2", "q3", "q4") )

save.image("myFavorites.RData")

# Removing all workspace items.
# The clear approach:

myDeleteItems <- ls()
myDeleteItems
rm(list = myDeleteItems)

# The usual approach:
rm( list = ls() )

# Setting your working directory.

getwd()
setwd("c:/myRfolder")

# Saving your workspace.

load(file = "myall.RData")

# Save everything.
save.image(file = "myPractice1.RData")

# Save some objects.
save(mydata,file = "myPractice2.RData")
save(mydata, mylist, mymatrix, file = "myPractice3.RData")

# Remove all objects and reload myPractice3.
rm( list = ls() )
load("myPractice3.RData")
ls()

# Save and load history.
savehistory(file = "myHistory.Rhistory")
loadhistory(file = "myHistory.Rhistory")