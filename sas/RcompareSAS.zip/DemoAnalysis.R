# R Sample Session (used in workshop, not in book). 

setwd("c:/myRfolder")

mydata <- read.table("mydata.tab")
print(mydata)

mydata$workshop <- factor(mydata$workshop)

summary(mydata)

plot( mydata$q1, mydata$q4 )

myModel <- lm(q4 ~ q1 + q2 + q3, data = mydata)
summary( myModel )
anova( myModel )
plot( myModel )
hist( resid( myModel) )