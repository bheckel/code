# Program to Import and Export Excel Files
# Filename: ReadExportExcel.R

install.packages("xlsReadWrite")
library("xlsReadWrite")
xls.getshlib()

setwd("c:/myRfolder")

mydata <- read.xls("mydata.xls")
mydata

write.xls(mydata, "mydataExported.xls")

library(RODBC)
myConnection <- odbcConnectExcel("mydata.xls")
mydata <- sqlFetch(myConnection, "Sheet1")
close(myConnection)
mydata

library(RODBC)
myConnection <- odbcConnectExcel("mydata.xls", readOnly = FALSE)
sqlSave(myConnection, mydata)
close(myConnection)