# R Program for Generating Data.
# Filename: GenerateData.R

# Simple sequences.
1:10
seq(from = 1,to = 10,by = 1)
seq(from = 5,to = 50,by = 5)
seq(5, 50, 5)

# Generating our ID variable
id <- 1:8
id

# gl function Generates Levels.
gl(n = 2, k = 1, length = 8)
gl(n = 2, k = 4, length = 8)

#Adding labels.
workshop <- gl(n = 2, k = 1, length = 8, 
  label = c("R", "SAS") )
workshop
gender   <- gl(n = 2, k = 4, length = 8, 
  label = c("f", "m") )
gender

# Generating Repetition Patterns (Not Factors)
gender   <- rep(1:2, each = 4, times = 1)
gender
workshop <- rep(1:2, each = 1, times = 4)
workshop
myZeros  <- rep(0, each = 8)
myZeros

# Generating Values for Reading a Fixed-Width File
myPrefixes <- c("x", "y", "z")
mySuffixes <- rep(1:300, each = 3, times = 1)
head(mySuffixes, n = 20)
myVariableNames <- paste(myPrefixes, mySuffixes, sep = "")
head(myVars, n = 20)
myWidthSet <- c(8, 12, 10)
myVariableWidths <- rep(myWidthSet, each = 1, times = 100)
head(myRecord, n = 20)

myVariablenames  <- c("id", myVariableNames)
myVariableWidths <- c( 5  , myVariableWidths)

mydata <- read.fwf(
   file  = myfile,
   width = myVariableWidths,
   col.names  = myVariableNames,
   row.names  = "id")

# Generating uniformly distributed Likert data
myValues <- c(1, 2, 3, 4, 5)
set.seed(1234)
q1 <- sample( myValues, size = 1000, replace = TRUE)
mean(q1)
sd(q1)

# Generating normally distributed Likert data
myValues <- c(1, 2, 2, 3, 3, 3, 4, 4, 5)
set.seed(1234)
q2 <- sample( myValues , size = 1000, replace = TRUE)
mean(q2)
sd(q2)

# Plot details in Traditional Graphics chapter.
par( mar = c(2, 2, 2, 1)+0.1 )
par( mfrow = c(1, 2) )
barplot( table(q1) )
barplot( table(q2) )
# par( mfrow = c(1, 1) ) #Sets back to 1 plot per page.
# par( mar = c(5, 4, 4, 2) + 0.1 )

# Same two barplots routed to a file.
postscript(file = "F:/r4sas/chapter12/GeneratedIntegers.eps",
           width = 4.0, height = 2.0)
par( mar = c(2, 2, 2, 1) + 0.1 )
par( mfrow = c(1, 2) )
barplot( table(q1) )
barplot( table(q2) )
dev.off()

# Two Likert scales with mean difference
set.seed(1234)
q1 <- sample( c(1, 2, 2, 3), size = 8, replace = TRUE)
mean(q1)

set.seed(1234)
q2 <- sample( c(3, 4, 4, 5), size = 8, replace = TRUE)
mean(q2)

# Generating continuous data

# From uniform distribution.
# mean = 0.5
set.seed(1234)
x1 <- runif(n = 1000)
mean(x1)
sd(x1)

# From a uniform distribution
# between 60 and 100
set.seed(1234)
x2 <- runif(n = 1000, min = 60, max = 100)
mean(x2)
sd(x2)

# From a normal distribution.
set.seed(1234)
x3 <- rnorm(n = 1000)
mean(x3)
sd(x3)

set.seed(1234)
x4 <- rnorm(n = 1000, mean = 70, sd = 5)
mean(x4)
sd(x4)

# Plot details are in Traditional Graphics chapter.
par( mar = c(2, 2, 2, 1) + 0.1 )
par( mfrow = c(1, 2) )
hist(x2, main = "")
hist(x4, main = "")
# par( mfrow = c(1, 1) ) #Sets back to 1 plot per page.
# par( mar = c(5, 4, 4, 2) + 0.1 )

# Same pair of plots, this time sent to a file.
postscript(file = "F:/r4sas/chapter12/GeneratedContinuous.eps",
           width = 4.0, height = 2.0)

par( mar = c(2, 2, 2, 1) + 0.1 )
par( mfrow = c(1, 2) )
hist(x2, main = "")
hist(x4, main = "")
dev.off()

# par( mfrow = c(1,1) ) #Sets back to 1 plot per page.
# par( mar = c(5, 4, 4, 2) + 0.1 )

# Generating a Data Frame.
id <- 1:8
workshop <- gl( n = 2, k = 1,
  length = 8, label = c("R","SAS") )
gender <-   gl( n = 2, k = 4,
  length = 8, label = c("f","m")   )
q1 <- sample( c(1, 2, 2, 3), 8, replace = TRUE)
q2 <- sample( c(3, 4, 4, 5), 8, replace = TRUE)
q3 <- sample( c(1, 2, 2, 3), 8, replace = TRUE)
q4 <- sample( c(3, 4, 4, 5), 8, replace = TRUE)
pretest   <- rnorm(n = 8, mean = 70, sd = 5)
posttest  <- rnorm(n = 8, mean = 80, sd = 5)

myGenerated <- data.frame(id, gender, workshop,
  q1, q2, q3, q4, pretest, posttest)
myGenerated