﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim rc As Integer

        'MsgBox("ok")
        rc = Send("http://zebsamoc002/Batch21ws/Aspentech.Batch21.Web.Services.dll?Handler=Default", "<Datasource xmlns='Aspentech.Batch21' name='zeb01'><Area name='SDMAN'><BatchQuery xmlns='Aspentech.Batch21' dataSourceName='' areaName=''><TimeRange start='2009-02-01T17:59:59' end='2009-03-31T18:00:01' /> </BatchQuery></Area></Datasource>", True, "us1_auth", "xuzy74946", "7PanthersUZY", , , True)
        MsgBox(rc)

    End Sub

    Function Send(ByVal Str_WebServiceURL As String, ByVal Str_WebserviceQueryXML As String, ByVal Bln_NTLMorBasic As Boolean, Optional ByVal Str_Domain As String = "", Optional ByVal Str_Username As String = "", Optional ByVal Str_Password As String = "", Optional ByVal Int_Timeout As Integer = 15000, Optional ByVal Str_XMLHeader As String = "", Optional ByVal Bln_Debug As Boolean = False) As Integer
        On Error GoTo ErrorHandler

        ' Dim ResultCode
        ' -1 = Unknown Error
        ' 0 = Unprocessed - Can be used externally to Datalink Integrator to indicate that a query requires processing. Included here for completeness.
        ' 1 = Successful Write
        ' 2 = Remote hostname could not be resolved 
        ' 3 = Timeout 
        ' 4 = Access Denied
        ' 5 = Unexpected return value.  URL Exists, but perhaps incorrect parameter specified e.g. ?Handler=DefaultABC or Web Service unavailable / not functioning.
        ' 6 = Invalid XML Query
        ' 7 = Invalid Batch.21 ADSA Data Source
        ' 8 = Invalid Batch.21 Area
        ' 9 = Object reference not set to an instance of an object, check parameters.

        Const Int_UnknownError As Integer = -1

        ' Dim Temp Return Code
        Dim Int_TempReturnCode As Integer = Int_UnknownError

        'Dim Temp XML Results
        Dim Str_XMLResults As String = String.Empty

        ' Reset WS Object
        Dim Obj_B21WS As New DataLink.AspenTech.Batch21.Adapter.Instance

        ' Declare DataLink Text Obj, RegEx used to interogate the results and determine status.
        Dim Obj_TextAdp As New DataLink.Text.Adapter.Instance

        ' Populate properties
        Obj_B21WS.WebServiceURL = Str_WebServiceURL
        Obj_B21WS.WebServiceQueryXML = Str_WebserviceQueryXML
        Obj_B21WS.Timeout = Int_Timeout
        Obj_B21WS.XMLHeader = Str_XMLHeader

        ' Call execute method specifying credentials - returns XML string if successful.
        Str_XMLResults = Obj_B21WS.Execute(Bln_NTLMorBasic, Str_Domain, Str_Username, Str_Password)
        Debug.Print(Obj_B21WS.ErrorInfo.EventID)
        ' Evaluate Return Code
        Select Case Obj_B21WS.ErrorInfo.EventID
            Case 0
                If Obj_TextAdp.RegEx_StringIsMatch("The xml is improperly formed.", Str_XMLResults, 0) = True Then
                    Int_TempReturnCode = 6
                ElseIf Obj_TextAdp.RegEx_StringIsMatch("<ResultStatus><Module>ApplicationInterface</Module><Number>234</Number>", Str_XMLResults, 0) = True Then
                    Int_TempReturnCode = 7
                ElseIf Obj_TextAdp.RegEx_StringIsMatch("<ResultStatus><Module>ApplicationInterface</Module><Number>235</Number>", Str_XMLResults, 0) = True Then
                    Int_TempReturnCode = 8
                Else
                    ' If no failure code detected return Success
                    Int_TempReturnCode = 1
                End If
            Case 5
                If Obj_TextAdp.RegEx_StringIsMatch("The remote name could not be resolved:", Obj_B21WS.ErrorInfo.Description, 0) = True Then
                    Int_TempReturnCode = 2
                ElseIf Obj_TextAdp.RegEx_StringIsMatch("The operation has timed out", Obj_B21WS.ErrorInfo.Description, 0) = True Then
                    Int_TempReturnCode = 3
                ElseIf Obj_TextAdp.RegEx_StringIsMatch("The request failed with HTTP status 401:", Obj_B21WS.ErrorInfo.Description, 0) = True Then
                    Int_TempReturnCode = 4
                ElseIf Obj_TextAdp.RegEx_StringIsMatch("Client found response content type of '', but expected 'text/xml'.", Obj_B21WS.ErrorInfo.Description, 0) = True Then
                    Int_TempReturnCode = 5
                Else
                    Int_TempReturnCode = -1
                End If
            Case 91
                Int_TempReturnCode = 9
            Case Else
                Int_TempReturnCode = Int_UnknownError
        End Select

        If Bln_Debug = True Then
            Dim Obj_DebugEvent As New DataLink.Library.EventLogEntry
            Dim Obj_DebugAssInfo As New DataLink.Library.AssemblyInfo
            Obj_DebugAssInfo.NewAsmInfo(New DataLink.Static.Factory.AspenTechBatch21Adapter)

            Obj_DebugEvent.LogEntryType = EventLogEntryType.Information
            Obj_DebugEvent.Source = Obj_DebugAssInfo.Title
            Obj_DebugEvent.EventID = Err.Number

            Obj_DebugEvent.Description = Obj_DebugEvent.Description & "Module Information:" & vbCrLf
            Obj_DebugEvent.Description = Obj_DebugEvent.Description & "Title: " & Obj_DebugAssInfo.Title & vbCrLf
            Obj_DebugEvent.Description = Obj_DebugEvent.Description & "Version: " & Obj_DebugAssInfo.Version & vbCrLf & vbCrLf

            Obj_DebugEvent.Description = Obj_DebugEvent.Description & "Subroutine Information: " & vbCrLf
            Obj_DebugEvent.Description = Obj_DebugEvent.Description & "Procedure name: " & System.Reflection.MethodBase.GetCurrentMethod.DeclaringType.Name & "." & System.Reflection.MethodBase.GetCurrentMethod.Name & vbCrLf & vbCrLf

            Obj_DebugEvent.Description = Obj_DebugEvent.Description & "Error Information: " & vbCrLf
            Obj_DebugEvent.Description = Obj_DebugEvent.Description & "Number: " & Err.Number & vbCrLf
            Obj_DebugEvent.Description = Obj_DebugEvent.Description & "Last DLL Error: " & Err.LastDllError & vbCrLf
            Obj_DebugEvent.Description = Obj_DebugEvent.Description & "Line: " & Err.Erl & vbCrLf
            Obj_DebugEvent.Description = Obj_DebugEvent.Description & "Description : " & Err.Description & vbCrLf & vbCrLf

            Obj_DebugEvent.Description = Obj_DebugEvent.Description & "Supplementary Information: " & vbCrLf
            Obj_DebugEvent.Description = Obj_DebugEvent.Description & _
                        "Debug: " & Bln_Debug & vbCrLf & _
                        "Web Service URL: " & Str_WebServiceURL & vbCrLf & _
                        "Query: " & Str_WebserviceQueryXML & vbCrLf & _
                        "NTLM: " & Bln_NTLMorBasic & vbCrLf & _
                        "Domain : " & Str_Domain & vbCrLf & _
                        "Username : " & Str_Username & vbCrLf & _
                        "Timeout : " & Int_Timeout & vbCrLf & _
                        "XML Results : " & Str_XMLResults & vbCrLf & _
                        "Return Code : " & Int_TempReturnCode

            Obj_DebugEvent.Record()

            ' Close open objects
            Obj_DebugAssInfo = Nothing
            Obj_DebugEvent = Nothing
        End If

        'Set Return Code
        Send = Int_TempReturnCode

        Debug.Print(Str_XMLResults)

        'Close objects
        Obj_TextAdp = Nothing
        Obj_B21WS = Nothing
        'MsgBox("reached")

        ' Error Handler
        Exit Function
ErrorHandler:
        Send = Int_UnknownError
        Dim Obj_ErrRaised As New DataLink.Library.EventLogEntry
        Dim Obj_AssInfo As New DataLink.Library.AssemblyInfo
        Obj_AssInfo.NewAsmInfo(New DataLink.Static.Factory.AspenTechBatch21Adapter)

        Obj_ErrRaised.LogEntryType = EventLogEntryType.Error
        Obj_ErrRaised.Source = Obj_AssInfo.Title
        Obj_ErrRaised.EventID = Err.Number

        Obj_ErrRaised.Description = Obj_ErrRaised.Description & "Module Information:" & vbCrLf
        Obj_ErrRaised.Description = Obj_ErrRaised.Description & "Title: " & Obj_AssInfo.Title & vbCrLf
        Obj_ErrRaised.Description = Obj_ErrRaised.Description & "Version: " & Obj_AssInfo.Version & vbCrLf & vbCrLf

        Obj_ErrRaised.Description = Obj_ErrRaised.Description & "Subroutine Information: " & vbCrLf
        Obj_ErrRaised.Description = Obj_ErrRaised.Description & "Procedure name: " & System.Reflection.MethodBase.GetCurrentMethod.DeclaringType.Name & "." & System.Reflection.MethodBase.GetCurrentMethod.Name & vbCrLf & vbCrLf

        Obj_ErrRaised.Description = Obj_ErrRaised.Description & "Error Information: " & vbCrLf
        Obj_ErrRaised.Description = Obj_ErrRaised.Description & "Number: " & Err.Number & vbCrLf
        Obj_ErrRaised.Description = Obj_ErrRaised.Description & "Last DLL Error: " & Err.LastDllError & vbCrLf
        Obj_ErrRaised.Description = Obj_ErrRaised.Description & "Line: " & Err.Erl & vbCrLf
        Obj_ErrRaised.Description = Obj_ErrRaised.Description & "Description : " & Err.Description & vbCrLf & vbCrLf

        Obj_ErrRaised.Description = Obj_ErrRaised.Description & "Supplementary Information: " & vbCrLf

        Obj_ErrRaised.Record()

        ' Close open objects
        Obj_AssInfo = Nothing

        Err.Clear()
        Exit Function
    End Function


End Class
