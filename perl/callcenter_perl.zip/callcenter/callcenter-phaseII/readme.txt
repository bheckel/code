2007-10-23

phaseII is the Lockup mods to get attached data into the html index pages


2007-10-23 

copied from
C:\cygwin\home\bheckel\projects\callcenter\harness\
after debugging and final compile Lockup.pl successfully - should work to just
copy LitHold_Test\ back and run Lockup.pl like this:

rm -rf /home/bheckel/projects/callcenter/harness/LitHold_Test/CAInstall/harness/Lit_Hold_Images/DDProdMedB/ANCEF/ && rm -rf /home/bheckel/projects/callcenter/harness/LitHold_Test/CAInstall/harness/Lit_Hold_Images/ProdMedB/SUMATRIPTAN/ && rm -rf /home/bheckel/projects/callcenter/harness/LitHold_Test/CAInstall/harness/Lit_Hold_Images/Caller_Role/FIELD/ && perl Lockup.pl; #grep -a potentialHeaderFields junkdumpmain
