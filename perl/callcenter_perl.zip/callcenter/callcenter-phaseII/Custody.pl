###############################################################
#
#  Program: Custody
#  Written by Stephen G. Keilholz
#  Purpose: Extract and store data related to contacts in an
#           orderly manner for later archiving to removable
#           media such as CD or DVD.
#
#           Specific types of data envisioned are AVI versions
#           of sessions from Witness and textual data from
#           beacon.
#
#  History of Change:
#  22-Mar-2007 Bob Heckel - New module created to find contacts
#                           based on Caller Role.  New AVI 
#                           file reading (CPAN) module 
#                           integrated.  New Ini reading module
#                           integrated.  All inline SQL 
#                           converted to Oracle packages.
#
###############################################################

use DBI;
use POSIX qw(strftime);
use File::Copy;
use Ini;
use Win32::OLE;

### Use statements required for perl2exe compiled version
use Carp::Heavy;
use DBD::Oracle qw(:ora_types);
use Video::Info;
use Video::Info::RIFF;
use Class::MakeMethods;
use Class::MakeMethods::Template::Hash;
use Class::MakeMethods::Template::Universal;
use Witness;
use WITNESSPRODUCT;
use WITNESSATTACHED_DATA;
###

use archReasons;
use archLogging;
use archActLogging;
use archWitnessUtil;
use archRequests;
use archBeaconUtil;
use archZipUtil;

initializeProgram();
actLog("Normal","Initialization complete");
#
# Data is determined as requiring archiving based on reasons which are
# stored in a database.  Load them into memory for processing, process them
# generating "requests" for data to be archived.  Then process the requests
# creating local copies of data from whatever the source may have been and
# storing them into a specific directory structure for later archival.
#
archReasons::load();
archReasons::process();
if ($dumpMode) {  # debug requested from parm 'dump' on command line
  archRequests::dumpRequests($dumpFile);
  archRequests::dumpRequests($dumpFile);
  actLog("Normal","Request information sent to file $dumpFile");
} else {
  archRequests::process();
}
actLog("Normal","Program ended normally.");

close(STDOUT);close(STDERR);

exit;



sub initializeProgram{
#
# Get program configuration from configuration file
#
  $|=1;select(STDERR);$|=1;select(STDOUT); # unbuffer both STDERR and STDOUT
#
# Set up program name for error logging/reporting purposes and open config file
#
  $PROGNAME="Custody";

  $W2CIni=new Ini;
  unless ($W2CIni->read('W2C.ini')) {
    die 'Error: No W2C.ini file available.';
  }

#
# Get error handling variables from configuration file, specifying defaults
# if they aren't there.
#
  $logLevel=$W2CIni->{ErrorHandling}{LogLevel} || 'None';
  $errorLogDateFmt=$W2CIni->{ErrorHandling}{errorLogDateFmt} || "%y%d%m%H%M%S";
  $errorNotification=$W2CIni->{ErrorHandling}{ErrorNotification} || 'None';
  $logdatefmt=$W2CIni->{ErrorHandling}{LogDateFmt} || "%y%d%m%H%M%S";
  @addresses=split /,/, $W2CIni->{ErrorHandling}{'Notify_'.$errorNotification} unless $errorNotification eq 'None';
  $mailHost=$W2CIni->{ErrorHandling}{MailHost} unless $errorNotification eq 'None';
  $mailOriginator=$W2CIni->{ErrorHandling}{MailOriginator} unless $errorNotification eq 'None';
  $witEarliestDtOverride=$W2CIni->{Debugging}{WitEarliestDtOverride} || 'None';
  $testAVIfile=$W2CIni->{Debugging}{TestAVIfile} || 0;
  $existCheckDelay=$W2CIni->{Debugging}{ExistCheckDelay} || 0;
  $existCheckTries=$W2CIni->{Debugging}{ExistCheckTries} || 0;
  $sizeCheckDelay=$W2CIni->{Debugging}{SizeCheckDelay} || 0;
  $exportRetryDelay=$W2CIni->{Debugging}{ExportRetryDelay} || 0;
#
# Initialize ActivityLogging
#
  actLogInit($logLevel,$errorNotification,$PROGNAME,$mailHost,$mailOriginator,$errorLogDateFmt,@addresses);
  actLog("Normal","Program started");
#
# Get base of directory structure into which data is to be stored and source remove flag
#
  $base=$W2CIni->{DirStructure}{Base};
  $removeSource=$W2CIni->{DirStructure}{removeSource};
#
# Get information about database
#
  $logActivityDB=$W2CIni->{Databases}{LogActivity};
#
# Get all compression-related variables
#
  $AVIcompression=$W2CIni->{Compression}{AVIcompression};
  $rate=$W2CIni->{Compression}{rate};
  $zipProg=$W2CIni->{Compression}{zipProg};
  $zipSEProg=$W2CIni->{Compression}{zipSEProg};
  $batchfile=$W2CIni->{Compression}{batchfile};
  $semsgfile=$W2CIni->{Compression}{semsgfile};
  $logofile=$W2CIni->{Compression}{logofile};
  $stubmode=$W2CIni->{Compression}{stubmode};
#
# Get Witness URL (Server)
#
  $WitnessURL=$W2CIni->{Servers}{Witness};

#
# Process Argument List, if any
#
  $dumpMode=$dumpFile="";
  if ("\U$ARGV[0]" eq "DUMP") {
    shift @ARGV;
    $dumpMode=1;
    $dumpFile=shift @ARGV;
#    delete $ARGV[1];
#    delete $ARGV[0];
    actLog("Normal","Operating in request dump mode, no requests will be processed");
  }
#
# Initialize each module with local copies of configuration variables
#
  archWitnessUtil::init($logActivityDB,$AVIcompression,$WitnessURL,$removeSource,$stubmode,$witEarliestDtOverride,$testAVIfile,$existCheckDelay,$existCheckTries,$sizeCheckDelay,$exportRetryDelay);
  archReasons::init($logActivityDB,@ARGV); # list of reasons on command line 1 2 4-6 9
  archLogging::init($logActivityDB);
  archBeaconUtil::init($logActivityDB);
  archRequests::init($base,$logdatefmt);
  archZipUtil::init($rate,$zipProg,$zipSEProg,$batchfile,$semsgfile,$logofile,$removeSource);
}
