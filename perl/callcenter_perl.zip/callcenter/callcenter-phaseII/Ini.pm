###############################################################
#
#  Program: Ini.pm
#  Written by Bob Heckel
#  Purpose: Read and and parse .ini files                             
#
###############################################################
package Ini;

use strict;
use warnings;


sub new {
  my $class = shift;

  my $self = {
    __inifile => undef,
    @_
  };

  bless $self, $class;

  return $self;
}


sub read {
  my ($self, $file) = @_;

  my $section;
  my $inidata = {};

  return unless -e $file;

  $self->{__inifile} = $file;

  open FILE, $file;
  chomp(my @lines = <FILE>);
  close FILE;

  foreach my $line ( @lines ) {
    # chomp
    $line =~ s/[\r\n]+$//;

    # Found section header
    if ( $line =~ /\s*\[(.*?)\]\s*/ ) {
      $section = $1;
      next;
    }

    next if length $line == 0;

    # Skip comments
    next if $line =~ /^\s*\;|^\s*#/;

    # Found key=value pair
    my ($key, $val) = split '=', $line, 2;

    # Compress leading and trailing spaces
    $key =~ s/^\s*|\s*$//g;
    $val =~ s/^\s*|\s*$//g;

    $inidata->{$section}->{$key} = $val;
  }

  foreach my $section (keys %{ $inidata }) {
    $self->{$section} = $inidata->{$section};
  }

  return 1;
}


1;
