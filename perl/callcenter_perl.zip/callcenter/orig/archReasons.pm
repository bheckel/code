###################################################################
#
#  archReasons.pm
#
#  Provide access/processing for archive reasons
#
#  Always used as class, never instantiated
#
###################################################################

package archReasons;

use DBI;
use archDB;
use archActLogging;
use Exporter ();
@ISA=qw(Exporter);

@EXPORT=qw(%areaForReason);

sub init{
#
# Provide package-local copy of log activity database definintion
#
local($reason,$range,@reasons);
$logActivityDB=shift @_;
if (@_) {
  foreach $reason (@_) {
    if ($reason=~/(.*)-(.*)/) { # handle reason ranges
      for ($range=$1;$range<=$2;$range++) {
        push @reasons,$range;
      }
    } else {
      push @reasons,$reason;
    }
  }
  $reasonlimit="and reason_id in (".join(", ",@reasons).")";
} else {
  $reasonlimit="";
}
}

sub load{
#
# Load reasons, returning count of reasons or undef if initialization hasn't
# been performed.
#
return undef unless defined $logActivityDB;
my ($dbh,$sql,$qh,@row,$p);
$dbh=openDB($logActivityDB);
#
# Define and prepare SQL -- since done only once per program execution, don't
# try to save prepared statement.
#
$sql=<<END;
select reason_id, group_dir_name, area_dir_name, value, search_type_name, source_name
from crc_arch_reasons r, crc_arch_grp g, crc_arch_area a,
     crc_arch_search_type t, crc_arch_source s
where end_date > sysdate
and r.group_id=g.group_id
and r.area_id=a.area_id
and r.search_type_id=t.search_type_id
and r.source_id=s.source_id $reasonlimit
order by search_type_name, group_dir_name, area_dir_name, reason_id
END
$qh=$dbh->prepare($sql);
$qh->execute();
$p=0;
#
# Fetch entire row into array of reason arrays, also define hash to map area to
# reason number
#
while (@row = $qh->fetchrow_array()) {
  @{ $reasonList[$p++] }=@row;
  $areaForReason{$row[0]}="$row[1]\\$row[2]";
}
actLog("Normal","$p Reasons loaded");
return $p
}

sub process{
#
#  Process each reason
#
my($r,$reasonNo,$group,$area,$value,$type,$source,$object);
for ($r=0;$r<=$#reasonList;$r++) {
#
# For each reason, breake into fields
#
## ($reasonNo,$area,$value,$type,$source)=@{ $reasonList[$r] };
 ($reasonNo,$group,$area,$value,$type,$source)=@{ $reasonList[$r] };
#
# Build "object" reference based on data source and type.  This is used to call
# process routine in module specific to processing data of the specified type
# from the specified source.
#
 $object="\U$source$type"; # Convert to upper case
 actLog("Normal","Object is $object, area is $area, reason is $reasonNo");
#
# Dynamically require the module unless it's already been loaded.  This
# technique allows this code to call "new" routines based on data in the
# database without changing this routine's code.  Of course, the modules will
# have to be coded and installed but no change will be required here.
#
 require $object.".pm" unless defined($objloaded{$object}); # load at run-time
 $objloaded{$object}=1;
 $subroutine="$object"."::process"; # Define name of subroutine so as not to call it when testing for existance
 if (exists &$subroutine) {
   $object->process($reasonNo,$group,$area,$value);
 } else {
#
# If problem with required module, log it as an error but allow continuation
# of processing for other reasons.
#
   actLog("Error","Unable to process reason $reasonNo for $object");
 }
}
}

sub dump{
#
# Diagnostic routine to dump the contents of the reason list.
#
my($r,$reasonNo,$group,$area,$value,$type,$source,$f);
print "Num\t\tGroup\t\tArea\t\tVal\t\tType\t\tSrc\n";
for ($r=0;$r<=$#reasonList;$r++) {
  foreach $f (@{ $reasonList[$r] }) {
    print "$f\t";
    print "\t" if length($f)<8;
  }
  print "\n";
}
}

1;
