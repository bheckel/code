###################################################################
#
#  archLogging.pm
#
#  Provide access/processing for archive logging
#
#  Always used as class, never instantiated
#
###################################################################

package archLogging;

use DBI;
use archDB;
use archCache;
use archReasons; # Need areaForReason hash
use archActLogging;
use POSIX qw(strftime);
use Exporter ();
@ISA=qw(Exporter);

@EXPORT=qw(addLogRecordDup addLogRecord cacheLogTable isLogged);

sub init{
#
# Store package local reference to log activity database
#
($logActivityDB)=@_;
}

###################################################################
#
# Routines for dealing with log table
#
###################################################################

sub addLogRecordDup{
#
#  Add log record for duplicate (called when we know it is a duplicate)
#
local($reason,$newreason,$area,$guid)=@_;

$dbh=openDB($logActivityDB);
#
# Define and prepare query to find session id of existing duplicate.
# Do this only once during first invocation.  This speeds execution noticably
# versus preparing query each time.
#

if (!defined($getLogRecord_h)) {
#$sql=<<END;
#SELECT Sess,Guid,Reason_Id,Area
#FROM   crcors.wa_log
#WHERE  Guid = ?
#AND    Reason_ID= ?
#AND    Status != 'DUP'
#END
$sql=<<END;
SELECT l.sess,l.guid,l.reason_id,r.area_id
FROM   crc_arch_log l,crc_arch_reasons r
WHERE  l.guid = ?
AND    l.reason_id= ?
AND    l.tatus != 'DUP'
END
$getLogRecord_h=$dbh->prepare($sql);
}
#
# Execute query, get and parse data from results.
#
$getLogRecord_h->execute($guid,$reason);
@row=$getLogRecord_h->fetchrow_array();
($sess,$guid1,$reason1,$area1)=@row;
#
# Check results to see if we have a sessionid (should have it because we came
# here knowing that the reason/area was a duplicate session for new reason
#
if ($sess) {
  addLogRecord($sess,$guid,$newreason,$area,"DUP of $reason");
} else {
  actLog("Error","No duplicate record found for ($reason,$area,$guid) while logging dup for $newreason.");
}
}

sub addLogRecord{
#
# Add a log record -- either long with all variables or short with only up to
# the date.  Short is used when contact data from Beacon is not available.
#
local($sess,$guid,$reason,$area,$status,$fn,$ln,$st,$cd,$aef)=@_;
### NO Need for area any more
#
#  Prepare statements first time only for speed
#
$dbh=openDB($logActivityDB);
if (!defined $addLogRecordShort_h) {
  $sql=<<END;
insert into crc_arch_log
fields (sess,reason_id,guid,contact_date,status,match_date,media_id)
values (?,   ?,        ?,   ?,           ?,     to_date(?,'YYYYMMDDHH24MISS'),0)
END

  $addLogRecordShort_h=$dbh->prepare($sql);
  $sql=<<END;
insert into crc_arch_log
fields (sess,reason_id,guid,first_name,last_name,state,contact_date,status,match_date,ae_flag,media_id)
values (?,   ?,        ?,   ?,         ?,        ?,    to_date(?,'YYYYMMDDHH24MISS'),?,to_date(?,'YYYYMMDDHH24MISS'),?,0)
END
  $addLogRecordLong_h=$dbh->prepare($sql);
}
#
# Define match date
#
$md=strftime('%Y%m%d%H%M%S',localtime(time));
#
# If values in any of the beacon data fields, execute the long record add SQL,
# error out if unable to add record. Otherwise, do likewise for the short SQL.
#
if ("$fn$ln$st$cd$aef" ne "") { # should use long form
  $addLogRecordLong_h->execute($sess,$reason,$guid,$fn,$ln,$st,$cd,$status,$md,$aef);
  if ($dbh->errstr) {
    actLog("Error","Error on Long logging of ($sess,$reason,$guid,$fn,$ln,$st,$cd,$status,$md,$aef)\n");
    exit;
  }
} else {
  $addLogRecordShort_h->execute($sess,$reason,$guid,$cd,$status,$md);
  if ($dbh->errstr) {
    actLog("Error","Error on Short logging of ($sess,$reason,$guid,$cd,$status,$md)\n");
    exit;
  }
}
return;
}

sub cacheLogTable{
#
# Create an in-memory cache of entries in log table
#
local($date)=@_;

local($sql,$dbh,$qh,$whereClause,$nc,$nb);
#
# Log activity and open database, then build SQL, including start date if
# passed.  Since this is called only once ususally, no need to prepare only
# once as is done in other log routines.
#
actLog("Normal","Caching Logged records since $date");
$dbh=openDB($logActivityDB);
$whereClause="";
$whereClause="WHERE contact_date > to_date('$date','YYYYMMDDHH24MISS')" if $date;
$sql=<<END;
SELECT Sess,Guid,Reason_Id,to_char(Match_Date,'YYYYMMDDHH24MISS')
FROM   crc_arch_log
$whereClause
END
#
# Prepare and execute SQL; Build hashes to look up based on session/reason,
# guid/reason, guid/area, and session specific data for the log entry (date or
# reason).  If found, this also indicates that there was at least one matching
# log record.
#
$qh=$dbh->prepare($sql);
$qh->execute();
$nc=$nb=0;
while (@row=$qh->fetchrow_array()) {
  $sr="$row[0].$row[2]";$gr="$row[1].$row[2]";;$ga="$row[1].$areaForReason{$row[3]}";
  $loggedsr{$sr}=$row[3]; # Beacon Session/Reason (date)
  $loggedgr{$gr}=$row[3]; # Guid/Reason (date)
  $loggedga{$ga}=$row[2]; # Guid/(Group/Area) (reason)
  $loggeds{$row[0]}=$row[3]; # Session (date)
  $nc++;
}
#
# Set flag that log has been cached.
#
setCached('log');
actLog("Normal","$nc log records cached.");
}

sub isLogged{
#
# Simple boolean subroutine to return results of whether a record was logged
# based on the passed variables (passed as hash with key combinations providing
# the determining factor for which hash contains the information.
#
  my %need,$reason,$guid,$session,$area;
  %need=@_;
  if (defined($need{"Reason"})) { # Need reason, could be Guid or Session
    $reason=$need{"Reason"};
    if (defined($need{"GUID"})) { # Ok, need reason and GUID -- in loggedgr
      $guid=$need{"GUID"};
      return $loggedgr{$guid.".".$reason};
    } elsif (defined($need{"Session"})) { # Need reason & session -- in loggedsr
      $session=$need{"Session"};
      return $loggedsr{$session.".".$reason};
    } else {
      return ""; # have reason but not session or guid
    }
  } elsif (defined($need{"Session"})) { # Don't need reason but need sesson - in loggeds
    return $loggeds{$need{"Session"}};
#
# Only remaining valid pair is GUID and Area -- if need both, value in loggedga
#
  } elsif (defined($need{"GUID"}) & defined($need{"Area"})) {
      $guid=$need{"GUID"};
      $area=$need{"Area"};
      return $loggedga{$guid.".".$area};
  } else {
    return ""; # don't have either session or reason (or GUID/AREA)
  }
}
1;
