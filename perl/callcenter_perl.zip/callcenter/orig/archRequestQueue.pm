###################################################################
#   DEFUNCT CODE
#  archRequestQueue.pm
#
#  Provide request queue functions/data
#
#  Always used as class, never instantiated
#
###################################################################

package archRequestQueue;

use Exporter ();
@ISA=qw(Exporter);

@EXPORT=qw(queueRequest);

use archActLogging;

sub queueRequest{
my($type,$metaType,$area,$reason,%metaData)=@_;
my(%request);
%request=(
'type'=>$type,
'metatype'=>$metaType,
'area'=>$area,
'reason'=>$reason
);
%{ $request{'meta'} }=%metaData;
push @requests,{ %request };
}

sub dumpRequests{
my $i;
for ($i=0;$i<=$#requests;$i++) {
  print STDERR "$i $requests[$i]{'type'} $requests[$i]{'metatype'} $requests[$i]{'area'} $requests[$i]{'reason'} $requests[$i]{'meta'}{'GUID'}\n";
}
}
