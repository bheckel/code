###################################################################
#
#  archActLogging.pm
#
#  Provide activity logging
#
#  Always used as class, never instantiated
#
###################################################################

package archActLogging;

use POSIX qw(strftime);
use Exporter ();
@ISA=qw(Exporter);

@EXPORT=qw(actLog actLogInit);

use Net::SMTP;

sub actLogInit{
#
# Set package local variables for internal use passed by caller
#
  ($logLevel,$errorNotification,$PROGNAME, $mailHost,$mailOriginator,
   $errorLogDateFmt,@addresses)=@_;
#
#  Set interactive flag if logLevel indicates that logging is to be Interactive
#  Note that logLevel is overloaded and thus Interactive is removed if present
#
  $interactive=1,$logLevel=~s/Interactive// if ($logLevel=~/Interactive/);

  open ACTLOG,">&STDERR"; # incase STDERR is closed later
  select ACTLOG;$|=1;select STDOUT;
#
#  Set initialized so that closure (and other functions) won't fail when
#  this package is required but not really used.
#
  $initialized=1;
}

sub actLog{
#
#  Log activity type (Normal, Warning, Error), appending time and message
#  to string (activityLog) and storing warnings/errors in an array for
#  later reporting; allow for interactive activity monitoring on STDERR
#  based on logLevel containint "Interactive" during initialization
#
  return unless $initialized; # if initialization is not done, don't do anything
  local($type,$message)=@_;
  local($now);
#
#  Generate timestamp and save it as the beggining of activity if beginning not
#  already set.
#
  $now=strftime($errorLogDateFmt,localtime(time));
  $LOGStart=$now unless $LOGStart;
#
# Put timestamp and message onto end of log string, display it if interactive
# and put into warnings/errors array depending on type of message
#
  $activityLog.="$now $message\n";
  print ACTLOG "$type $now $message\n" if $interactive;
  push @LOGWarnings,"$now $message" if $type eq "Warning";
  push @LOGErrors,"$now $message" if $type eq "Error";
}

END {
#
#  When program ends, determine if notification should be sent and, if so, what
#  the content should be including priority (high if errors, medium if only
#  warnings and low if none but notification)
#
  return unless $initialized; # if initialization is not done, don't do anything
  close ACTLOG;
#
#  Don't need to proceed if no Warnings or errors and logLevel is none
#  Also, don't need to proceed unless error notification has been requested or
#  logLevel is higher than None
#
  return if ((($#LOGWarnings + $#LOGErrors) == -2) & ($logLevel eq "None"));
  return unless ($errorNotification | $logLevel ne "None");
#
# Set priority of message, none (3) is default, high (1) if errors, low if no
# errors or warnings.
#
  $priority=3;
  $priority=1 if $#LOGErrors >= 0; # set priority high if errors
  $priority=5 if ($#LOGWarnings + $#LOGErrors) == -2; # set low if no errors/warnings
#
#  Set mail message body (top) and subject (beginning)
#
  $message="$PROGNAME started $LOGStart\n";
  $subject="$PROGNAME ";
#
#  Set up warning list, error list, message body (rest), and subject (rest)
#
  if ($errorNotification) {
    if ($#LOGWarnings < 0) {
      $warnlist="No Warnings\n";
    } else {
      $warnlist="Warnings: \n  ".join("\n  ",@LOGWarnings)."\n";
    }
    if ($#LOGErrors < 0) {
      $errorlist="No Errors\n";
    } else {
      $errorlist="\nErrors: \n  ".join("\n  ",@LOGErrors)."\n";
    }
    $message.="$errorlist\n$warnlist\n";
    $subject.="Warnings/Errors ";
  }
#
# If interested activity activity detail, add to message/subject
#
  if ($logLevel ne "None") {
    $message.="Activity Log:\n$activityLog";
    $subject.="& Log";
  }
#
# Send it
#
  mailMessage($priority,$subject,$message,@addresses);
}

sub mailMessage{
#
# Send message with subject and message body with specified priority
# (1-high, 3-normal, 5-low) using package local variables for mailHost
# and mailOriginator
#
  return unless $initialized; # if initialization is not done, don't do anything
  local($pri,$subject,$message,@users)=@_;
  local($smtp,$userlist);

  $userlist=join(",",@users);
  $smtp = Net::SMTP->new($mailHost);
  $smtp->mail($mailOriginator); # sender address
  $smtp->to(@users,{ SkipBad => 1}); # address to userlist
  $smtp->data(); # Begin data section
  $smtp->datasend("To: $userlist\n"); # human to section
  $smtp->datasend("Subject: $subject\n"); # subject
  $smtp->datasend("X-Priority: $pri\n"); # Priority (translates to importance)
  $smtp->datasend("\n"); # end Header
  $smtp->datasend("$message\n");
  $smtp->dataend();
  $smtp->quit();
}
1;
