###############################################################
#
#  Program Lockup
#  Written by Stephen G. Keilholz
#  Purpose: Identify directories of contact data that exceed
#           a configured threshold and generate requests to
#           copy this data, up to that threshold, to the
#           specified media
#
###############################################################

use DBI;
use POSIX qw(strftime);
use File::Copy;
use File::Path;
use archDB;
use Config::ini;
use archLogging;
use archActLogging;

### Use statements required for compiled version
use Carp::Heavy;
use DBD::Oracle;

initializeProgram();
scanForThresholds();
if ($dumpMode) {
  dumpQueue($dumpFile);
  actLog("Normal","Queue information sent to file $dumpFile");
} else {
  processQueue();
}
actLog("Normal","Program ended normally.");
close(STDOUT);close(STDERR);
exit;

sub initializeProgram{
#
# Get program configuration from configuration file
#
  $|=1;select(STDERR);$|=1;select(STDOUT); # unbuffer both STDERR and STDOUT

  $PROGNAME="Lockup";
  $W2LIni=new Config::Ini('W2L.ini');
#
# Get error handling variables from configuration file, specifying defaults
# if they aren't there.
#
  $logLevel=$W2LIni->get(['ErrorHandling','LogLevel']) || "None";
  $errorLogDateFmt=$W2LIni->get(['ErrorHandling','errorLogDateFmt']) || "%y%d%m%H%M%S";
  $progLogFile=$W2LIni->get(['ErrorHandling','progLogFile']) || "ProgLog.txt";
  $errorNotification=$W2LIni->get(['ErrorHandling','ErrorNotification']) || "None";
  $logdatefmt=$W2LIni->get(['ErrorHandling','LogDateFmt']) || "%y%d%m%H%M%S";
  @addresses=$W2LIni->get(['ErrorHandling','Notify_'.$errorNotification]) unless $errorNotification eq "None";
  $mailHost=$W2LIni->get(['ErrorHandling','MailHost']) unless $errorNotification eq "None";
  $mailOriginator=$W2LIni->get(['ErrorHandling','MailOriginator']) unless $errorNotification eq "None";
  $activityLog="";
  actLog("Program started");
#
# Get base of directory structure into which data is to be stored
#
  $base=$W2LIni->get(['DirStructure','Base']);
  $templateDir=$W2LIni->get(['DirStructure','templateDir']);
  $sourceBase=$W2LIni->get(['DirStructure','Base']);
  $tempBase=$W2LIni->get(['DirStructure','tempBase']);
  $remoteLoc=$W2LIni->get(['DirStructure','remoteLoc']);
  $remoteSourceBase=$W2LIni->get(['DirStructure','remoteSourceBase']);
#
# Get information about databases
#
  $sessionInfoDB=$W2LIni->get(['Databases','SessionInfo']);
  $witnessDB=$W2LIni->get(['Databases','Witness']);
  $logActivityDB=$W2LIni->get(['Databases','LogActivity']);
#
# Get recording media-specific variables
#
  $discSize=$W2LIni->get(['Recording','mediaSize']);
  $mediaType=$W2LIni->get(['Recording','mediaType']);
  $discDirSizeLimit=$W2LIni->get(['Recording','discDirSizeLimit']);
  $imageType=$W2LIni->get(['Recording','imageType']);
  $fixate=$W2LIni->get(['Recording','fixate']);
  $numCopies=$W2LIni->get(['Recording','copies']);
  $priority=$W2LIni->get(['Recording','priority']);
  $templateFileName=$W2LIni->get(['Recording','templateFile']);
  $orderDateFormat=$W2LIni->get(['Recording','orderDateFormat']);
  $labelPath=$W2LIni->get(['Recording','labelPath']);
#
#
#
  $buildDisc="1"; # Generate and send order (blank to not send, 1 to send)
  $keepSource=""; # keep source files (blank to remove, 1 to keep)
  $buildDisc=$W2LIni->get(['Debugging','buildDisc']) if
             defined $W2LIni->get(['Debugging','buildDisc']);
  $keepSource=$W2LIni->get(['Debugging','keepSource']) if
              defined $W2LIni->get(['Debugging','keepSource']);
#
# Get list of valid types of files to archive
#
  @filetypes=$W2LIni->get(['FileTypes','Types']);
#
# Initialize each module with local copies of configuration variables
#
  archLogging::init($logActivityDB);
  actLogInit($logLevel,$errorNotification,$PROGNAME,$mailHost,$mailOriginator,
             $errorLogDateFmt,@addresses);
#
#  Allow for dump mode where activity information is dumped to file rather than
#  performed
#
  $dumpMode=$dumpFile="";
  if ("\U$ARGV[0]" eq "DUMP") {
    shift @ARGV;
    $dumpMode=1;
    $dumpFile=shift @ARGV;
#    delete $ARGV[1];
#    delete $ARGV[0];
    actLog("Normal","Operating in request dump mode, no requests will be processed");
  } else {
  print "[$buildDisc] [$keepSource]\n";
    if ($buildDisc) {
      actLog("Normal","Will build discs");
    } else {
      actLog("Normal","Will not build discs");
    }
    if ($keepSource) {
      actLog("Normal","Will keep source files");
    } else {
      actLog("Normal","Will not keep source files");
    }
  }
#
# Set up onlyProcess pattern if arguments exist
  $onlyProcess="";
  foreach $pat (@ARGV) {
    next unless $pat; # skip blank values
    $onlyProcess.="$pat|";
  }
  chop($onlyProcess) if $onlyProcess;
  actLog("Normal","Limiting to directories matching $onlyProcess") if $onlyProcess;
}

sub scanForThresholds{
#
# Scan all directories in structure for those that exceed threshold; queue
# file list (and start/end date of list) for each directory found
#
  actLog("Normal","Scanning for directories exceeding threshold of $discSize Meg");
#
# Initialize count of archives needed and open the base directory containing
# the subdirectories for each potential disc to create.
#
  $archive{'COUNT'}=0;
  opendir(DIR,$sourceBase);
  while ( defined ($groupdir = readdir DIR) ) {
    next if $groupdir =~ /^\.\.?$/;     # skip . and ..
    next unless -d "$sourceBase\\$groupdir"; # Skip non-directories
    opendir(GDIR,"$sourceBase\\$groupdir");
    while ( defined ($file = readdir GDIR) ) {
      next if $file =~ /^\.\.?$/;     # skip . and ..
      next unless -d "$sourceBase\\$groupdir\\$file"; # Skip non-directories
      next if $onlyProcess && !("$groupDir\\$file"=~/$onlyProcess/i); # Skip if limited
      $groupfile="$groupdir\\$file";
      if (&haveDiscFull("$groupfile")) {
#
# If we need to archive, increment the count and put into hash the information
# about the data to archive including the start and end date as well as the
# list of files to copy.
#
        $archive{$groupfile}=$archive{'COUNT'}++;
        $x=@copyfiles;
        actLog("Normal","Queueing $x files for group $groupdir area $file");
        $archive{$groupfile}{'LIST'}=[ @copyfiles ];
        $archive{$groupfile}{'STARTDATE'}=$startdate;
        $archive{$groupfile}{'ENDDATE'}=$enddate;
      }
    }
    closedir(GDIR);
  }
  closedir(DIR);
}

sub haveDiscFull{
#
# Determine if the amount of data in the passed directory would exceed the
# amount that would fit on the media.  As an optomization, maintain a list
# of the files that would fit in an array.  Return boolean as to whether or not
# this list is full and requires archiving.
#
  local($dirname)=@_;
  local($file,$size,$lsize,$overLimit,$record);
  local($rectime,$fname,$reason,$sesdate,$dur,$callerfn,$callerln,$state,$AE,$fileSize,%seenFile);
#
# Undefine values of startdate, enddate, curfile, and copyfiles
#
  undef $startdate,$enddate,$curfile;
  undef @copyfiles; # For some reason, doesn't work if array appended to previous line
  undef %seenFile;
#
# Log activity, initialize variables to keep track of total size of files, and
# open the log file.
#
  actLog("Normal","Getting dir size for $dirname from $sourceBase\\$dirname\\logfile.txt");
  $size=0;
  $lsize=0;
  $overLlimit='';
#
#  Sort contents before processing to make sure that date range includes all available
#  files in that range when disc is created -- files with earlier dates may be added to
#  file for various reasons
#
  open(FILELIST,"<$sourceBase\\$dirname\\logfile.txt");
  chomp(@recordList = <FILELIST>);
  close(FILELIST);

  foreach $record (sort byDate @recordList) {
#
# Parse the record and skip it if the file is the same as the current one to
# prevent possibility of multiple copies of files from being put on disc.  This
# shouldn't happen since data shouldn't have been created that way.
#

      ($rectime,$fname,$reason,$sesdate,$dur,$product,$callerfn,$callerln,$state,$AE,$fileSize)=split(/,/,$record);
      next if defined($seenFile{$fname});  # skip multiple reason records for same file
      $fileSize=(int($fileSize/1024)+1)/1024; # get next highest whole number value of K converted to Megs
      
      $size+=$fileSize; # size after adding this file
      $curfile=$fname;
#
# If we're not over the limit and adding this file wouldn't exceed the discsize,
# add the record to the list of those to copy and increment the size of the
# files "in queue".  Otherwise, set the overlimit flag and leave loop.
#
# overlimit flag is holdover and possibly could be removed since loop is
# exited the first thie that a file would exceed the limit.
#
      if (!$overLimit && ($size <= $discSize)) {
        $startdate=$sesdate unless $startdate; # set startdate first time only
        $enddate=$sesdate;
        push @copyfiles,$record;
        $lsize+=$fileSize;
      } else {
        $overLimit = 1; # set over limit indicator
        last;
      }
  }
#
# Close the log file; log result and return value indicating whether or not
# we are over the limit.  Array copyfiles is used if over the limit.
#
  if ($overLimit) {
    actLog("Normal","Have full directory of size $lsize Meg");
  } else {
    actLog("Normal","Directory isn't full, only $size Meg");
  }
  return $overLimit;
}

sub analyzeLogRecords{
#
# For given area, check log to see what fields are available and thus what
# columns will be necessary in the output file.  Return array of boolean
# values with one element per (defined) field.
#
  local($area)=@_;
  local(@fieldsWithValues,@fields,$record,$filetype,$fileExt);
#
# Undefine haveFileTypes because we set the value for use elsewhere but we are
# called multiple times in a given run.
#
  undef %haveFileTypes;
#
# For each record in the list for this area, split it and determine which fields
# have values.  Then check field 1 for each of the defined filetypes, setting
# the haveFileTypes flag if the specified type of file is found.
#
  foreach $record (@{ $archive{$area}{'LIST'} }) {
    @fields=split(/,/,$record);
    for ($i=0;$i<=$#fields;$i++) {
      $fieldsWithValues[$i]=1 if $fields[$i] ne "";
    }
    foreach $filetype (@filetypes) {
      $fileExt="\\.$filetype";
      $haveFileTypes{$filetype}=1 if $fields[1]=~/$fileExt/;
    }
  }
  return @fieldsWithValues
}

sub getGroupName{
#
# Get and locally cache group name from database as needed
#
local($group)=@_;
local($sql,@row,$dbh);
$dbh=openDB($logActivityDB);
if (!defined $getGroup_h) {
$sql=<<END;
select group_name from crc_arch_grp where group_dir_name = ?
END
$getGroup_h=$dbh->prepare($sql);
}
$getGroup_h->execute($group);
@row = $getGroup_h->fetchrow_array();
$groupName{$group}=$row[0];
return $row[0];
}

sub getAreaName{
#
# Get and locally cache area name from database as needed
#
local($area)=@_;
local($sql,@row,$dbh);
$dbh=openDB($logActivityDB);
if (!defined $getArea_h) {
$sql=<<END;
select area_name from crc_arch_area where area_dir_name = ?
END
$getArea_h=$dbh->prepare($sql);
}
$getArea_h->execute($area);
@row = $getArea_h->fetchrow_array();
$areaName{$area}=$row[0];
return $row[0];
}

sub generateHeaders{
#
# Generate html top of file, text top of file
#
# include jscript for filetypes present
# include headings for filetypes present
#
# build basic header for all files
  local($area,@fieldsWithValues)=@_;
  local($htmlTop,$line,@potentialHeaderFields,$potHdrFld,$colspan);
  $htmlTop="";
  ($group,$area)=split(/\\/,$area);
  $groupshort=$group;
  $group=$groupName{$group} ne "" ? $groupName{$group} : &getGroupName($group);
#TESTING for product only
  $groupt="$group<br>";
  open(INP,"<$templateDir\\indexTop.txt");
  while ($line=<INP>) { next if $line=~/^\s*;/; $line=~s/%(.*?)%/$$1/g; $htmlTop .= $line; }
  close(INP);
  $htmlTop.="\n<!- END indexTop ->\n"; ###DEBUG###
  foreach $filetype (keys %haveFileTypes) {
  # copy template from templatedir with name based on filetype into header
    if (-e "$templateDir\\$filetype".".txt") {
      open(INP,"<$templateDir\\$filetype".".txt");
      while ($line=<INP>) { next if $line=~/^\s*;/; $line=~s/%(.*?)%/$$1/g; $htmlTop .= $line; }
      close(INP);
    }
  }
  $htmlTop.="\n<!- END file-type specific  ->\n"; ###DEBUG###

  open(INP,"<$templateDir\\rowHeaders.txt");
  chomp($line=<INP>);
  @potentialHeaderFields=split(/,/,$line);
  chomp($line=<INP>);
  %fileNames4Nums=split(/,/,$line);
  chomp($line=<INP>);
  %sortSubs=split(/,/,$line);
###DEBUG ###  foreach $key (keys %fileNames4Nums) {print "\$fileNames4Nums{$key}=$fileNames4Nums{$key}\n";}
###DEBUG ###  foreach $key (keys %sortSubs) {print "\$sortSubs{$key}=$sortSubs{$key}\n";}
  $colspan=0;
  foreach $potHdrFld (@potentialHeaderFields) {
    $colspan++ if $fieldsWithValues[$potHdrFld];
  }
  while ($line=<INP>) {
    next if $line=~/^\s*;/; # skip any line beginning with ";"
    ($field,$line)=split(/:/,$line,2);
    if ($field eq "*" || $fieldsWithValues[$field]) {
      $line=~s/%(.*?)%/$$1/g;
      $htmlTop .= $line;
    }
  }
  close(INP);
  $htmlTop.="\n<!- END field-specific  ->\n"; ###DEBUG###
  return $htmlTop;
}


sub moveFilesAndGenerateIndices{
  local($htmlTop,$area,@fieldsWithValues)=@_;
  local();

  open(TINDEX,">$tempBase\\$area\\files\\index.txt");
  print TINDEX "Session,File,Date,Duration,Product,CallerFN,CallerLN,State,Adverse Event\n";
  $dirnum=1;
  $filesindir=0;
  $recnum=0;
  undef @order;
  undef @sessionlist;
  undef @reasonlist;
  $x=@{ $archive{$area}{LIST} };
#  actLog("Normal","For $area, archiving $x files");
  foreach $record (@{ $archive{$area}{LIST} }) {
    ($rectime,$fname,$reason,$sesdate,$dur,$product,$callerfn,$callerln,$state,$AE,$fileSize)=split(/,/,$record);
    @fields=split(/,/,$record);
#
# Process individual field changes necessary
#
    $sname=$fname;
    $sname=~s/(.*?)\..*/$1/i; # change file name to session name (remove anything after first "."
    push @sessionlist,$sname;
    push @reasonlist,$reason;
    $sesdate=~s/(....)(..)(..)(..)(..).*/$1-$2-$3 $4:$5/;
    $posn=substr("0000000$recnum",-8,8);

    mkpath("$tempBase\\$area\\files\\$dirnum") unless -d "$tempBase\\$area\\files\\$dirnum";

# Above replaced simple mkdir "$tempBase\\$area\\files\\$dirnum" unless -d "$tempBase\\$area\\files\\$dirnum";

# href to different jscript based on filetype, change va to view, parameter is type
    $snamel="<a href='$dirnum\\$fname' onMouseOver=\"return va()\" onMouseOut=\"return clr()\">$sname</a>";
    $html[$recnum]="<TR><TD>$snamel</TD><TD>$sesdate</TD>";
    $order[1]{"$sname.$posn"}=$recnum; # for field file (session)

#
# Process field-specific translations for view and sorting in left-to-right order
#
    if ($fieldsWithValues[4]) { # Duration
      if ($dur eq "x.xx") {
        $ndur=0;
      } else {
        ($m,$s)=split(/:/,$dur);
        $ndur=$m*60+$s;
      }
      $html[$recnum].="<TD align=right>$dur</TD>";
      $order[4]{"$ndur.$posn"}=$recnum;
    }

    if ($fieldsWithValues[5]) { # Product
      $html[$recnum].="<TD>$product</TD>";
      $order[5]{"$product.$posn"}=$recnum;
    }

    if ($fieldsWithValues[6] | $fieldsWithValues[7]) { # name
      $html[$recnum].="<TD>$callerfn $callerln</TD>";
      $order[6]{"$callerfn.$posn"}=$recnum;
      $order[7]{"$callerln.$posn"}=$recnum;
    }
    if ($fieldsWithValues[8]) { # State
      $stateh=($state) ? $state : "&nbsp;";
      $html[$recnum].="<TD>$stateh</TD>";
      $order[8]{"$state.$posn"}=$recnum;
    }
    if ($fieldsWithValues[9]) { # Adverse Event
      $AEh=($AE eq "F") ? "&nbsp;" : "Yes";
      $AEt=($AE eq "F") ? "" : "Yes";
      $AEr=($AE eq "F") ? "No" : ""; # needed for "reverse" sorting when creating html files
      $html[$recnum].="<TD>$AEh</TD>";
      $order[9]{"$AEr.$posn"}=$recnum;
    }
    $html[$recnum].="</TR>\n";
    $recnum++;
#
# Put record into text index
#
    print TINDEX  "$sname,$dirnum\\$fname,$sesdate,$dur,$product,$callerfn,$callerln,$state,$AEt\n";
    $renameOk="";
#
    if (-e "$sourceBase\\$area\\$fname") { # file might not exist if it's already been moved because associated with another product
      if (!$keepSource) {
        $renameOk=move("$sourceBase\\$area\\$fname","$tempBase\\$area\\files\\$dirnum\\$fname");
        if (!$renameOk) {
          $copyOk=copy("$sourceBase\\$area\\$fname","$tempBase\\$area\\files\\$dirnum\\$fname");
          if ($copyOk) {
            unlink "$sourceBase\\$area\\$fname";
            $renameOk=$copyOk;
          } else {
            actLog("Error","Unable to move file $sourceBase\\$area\\$fname to $tempBase\\$area\\files\\$dirnum\\: [$!]");
            exit;
          }
        }
      } else {
        $copyOk=copy("$sourceBase\\$area\\$fname","$tempBase\\$area\\files\\$dirnum\\$fname");
        actLog("Warning","Unable to copy file $sourceBase\\$area\\$fname to $tempBase\\$area\\files\\$dirnum\\: [$!]") unless $copyOk;
      }
      if (++$filesindir >= $discDirSizeLimit) {
        $dirnum++;
        $filesindir=0;
      }
    } # end of if file exists
  }
  close(TINDEX);
#
# Build required html files
#
  for ($i=0;$i<=$#fieldsWithValues;$i++) {
    if ($fieldsWithValues[$i]) {
      buildHtmlFileFor($i);
    }
  }
  actLog("Debug","Copying $templateDir\\infofile.htm to $tempBase\\$area\\files\\index.htm");
  $copyOk=copy("$templateDir\\infofile.htm","$tempBase\\$area\\files\\index.htm");
  actLog("Debug","Result is $copyOk");
}

sub buildHtmlFileFor{
  local($fieldNo)=@_;
  local($filename);
  $filename=$fileNames4Nums{$fieldNo};
  return unless $filename ne "";
###DEBUG ###  print "$filename\n";
  open(HTML,">$tempBase\\$area\\files\\$filename".".htm");
  print HTML $htmlTop;
  if (!defined $sortSubs{$fieldNo}) {
    foreach $ptrkey (sort keys %{ $order[$fieldNo] }) {
      print HTML $html[$order[$fieldNo]{$ptrkey}];
    }
  } else {
    $subName=$sortSubs{$fieldNo};
###DEBUG ###    print "Using $subName for sorting\n";
    foreach $ptrkey (sort $subName keys %{ $order[$fieldNo] }) {
      print HTML $html[$order[$fieldNo]{$ptrkey}];
    }
  }
  print HTML "</TBODY>\n</TABLE>\n</BODY>\n</HTML>\n";
  close HTML;
}

sub generateStandardFiles{
    actLog("Normal","Copying shelexec, autorun.inf and logo and creating label data file");

# Copy ShelExec to allow autorun.inf to run non-executables on NT4 and older platforms
    copy("$templateDir\\ShelExec.exe","$tempBase\\$area\\files\\ShelExec.exe");

# Copy standard background image
    copy("$templateDir\\crcbgimage.jpg","$tempBase\\$area\\files\\crcbgimage.jpg");
    
# Copy autorun.inf substituting program variables where needed
    open(INP,"<$templateDir\\autorun.inf");
    open(OUT,">$tempBase\\$area\\files\\autorun.inf");
    while ($line=<INP>) { $line=~s/%(.*?)%/$$1/g; print OUT $line; }
    close(IN);
    close(OUT);

# copy logo icon file
    copy("$templateDir\\logo.ico","$tempBase\\$area\\files\\logo.ico");

# Create data file for field-based text on CD/DVD label
# split "area" into group/area
    ($g,$a)=split(/\\/,$area);
    $g=$groupName{$g} ne "" ? $groupName{$g} : &getGroupName($g);
    $a=$areaName{$a}  ne "" ? $areaName{$a}  : &getAreaName($a);
    open(DATA,">$tempBase\\$area\\labelData.txt");
    print DATA "$g,$a,Start Date: $startdate,End Date: $enddate\n";
    close(DATA);
}

sub generateOrder{
  local($area)=@_;
  ($g,$a)=split(/\\/,$area);
  $orderId=$a;
  $orderId=~s/ //g;
  $volumeNo=substr($orderId,0,18);
  $orderId=substr("$orderId",0,8);
  $orderId.=strftime($orderDateFormat,localtime(time));
  $volumeNo.="-".strftime($orderDateFormat,localtime(time));
  $sourcePath="$remoteSourceBase\\$area\\files";
  $labelTextPath="$remoteSourceBase\\$area\\labelData.txt";
  open(INP,"<$templateDir\\$templateFileName");
  open(OUT,">$tempBase\\$area\\orderfile.nwp");
  while ($line=<INP>) { $line=~s/%(.*?)%/$$1/g; print OUT $line; }
  close(IN);
  close(OUT);
  actLog("Normal","Updating media information");
  newMediaAssociation($volumeNo,$orderId);
  if ($buildDisc) {
    copy("$tempBase\\$area\\orderfile.nwp","$remoteLoc\\$orderId".".nwp");
    actLog("Normal","Sent request $orderId to disc creation server");
    resetTextIndex("$sourceBase\\$area");
# send request to recorder
  } else {
    actLog("Warning","Skipped sending of request $orderId to server");
  }
}

sub resetTextIndex{
local($basedir)=@_;
local($now,$record,$file,$dummy);
$now=strftime($orderDateFormat,localtime(time));
open(LOG,"<$basedir\\logfile.txt");
open(GONE,">>$basedir\\queuedlogfile.txt");
open(TEMP,">$basedir\\templogfile.txt");
while ($record=<LOG>) {
  ($dummy,$file,$dummy)=split(/,/,$record);
  if (-e "$basedir\\$file") {
    print TEMP $record;
  } else {
    print GONE "$now,$record";
  }
}
close(LOG);close(GONE);close(TEMP);
move("$basedir\\logfile.txt","$basedir\\oldlogfile.txt");
move("$basedir\\templogfile.txt","$basedir\\logfile.txt");
unlink("$basedir\\oldlogfile.txt")
}

sub newMediaAssociation{
###Create crc_arc_media record
###Associate CRC_ARCH_LOG records (id by sess/reason_id) to media and update status
local($volumeNo,$orderId)=@_;
local($dbh,$sess,$reson,$i,$status);

$dbh=openDB($logActivityDB);

# Get next media id
#
$mediaId=newMediaId($dbh,$volumeNo,$orderId);

# Define sql to update log records with media status
#
if (!defined $updateLogMediaStatus_h) {
  $sql=<<END;
update crc_arch_log
set status=?, media_id=?
where sess=? and reason_id=?
END
  $updateLogMediaStatus_h=$dbh->prepare($sql);
}

# Update all records in list
#
$status="WRITING DISC";
for ($i=0;$i<=$#sessionlist;$i++) {
  $sess=$sessionlist[$i];
  $reason=$reasonlist[$i];
  $updateLogMediaStatus_h->execute($status,$mediaId,$sess,$reason);
}
}

sub newMediaId{
local($dbh,$volumeNo,$orderId)=@_;
if (!defined $newMediaId_h) {
  $sql=<<END;
insert into crc_arch_media
fields (media_id, create_date, volume_label, order_id, status, status_date)
values (media_id_seq.nextval,to_date('99991231','YYYYMMDD'),?,?,'REQUESTED',sysdate)
END
  $newMediaId_h=$dbh->prepare($sql);
  $sql=<<END;
select media_id_seq.currval from dual
END
  $lastMediaId_h=$dbh->prepare($sql);
}
$newMediaId_h->execute($volumeNo,$orderId);
$lastMediaId_h->execute();
@row=$lastMediaId_h->fetchrow_array();
return $row[0];
}

sub dumpQueue{
my $disc,$area,$startdate,$enddate,$group,$rarea,$record;
if ($_[0]) {
  open(DUMP,">$_[0]");
} else {
  open(DUMP,">&STDERR");
}

print DUMP "disc,group,area,rectime,fname,reason,sesdate,dur,product,callerfn,callerln,state,AE,fileSize\n";
$disc=0;
foreach $area (sort keys %archive) {
  next if $area eq "COUNT";
  next if -d "$tempBase\\$area";
  $startdate=$archive{$area}{STARTDATE};
  $startdate=~s/(....)(..)(..)(..)(..).*/$1-$2-$3 $4:$5/;
  $enddate=$archive{$area}{ENDDATE};
  $enddate=~s/(....)(..)(..)(..)(..).*/$1-$2-$3 $4:$5/;
  ($group,$rarea)=split(/\\/,$area);
  foreach $record (@{ $archive{$area}{LIST} }) {
    print DUMP "$disc,$group,$rarea,$record\n";
  }
  $disc++;
}
close(DUMP);
}

sub processQueue{
  actLog("Normal","Queueing disc creation for $archive{COUNT} discs");
  foreach $area (sort keys %archive) {
    next if $area eq "COUNT";
    if (-d "$tempBase\\$area") {
      actLog("Warning","Directory already exists for $tempBase\\$area!");
      next;
    }
    #Create temp dir (path);Copy autoload template & icon;Create list of files
    if (!(mkpath "$tempBase\\$area")) {
      actLog("Error","Unable to create $tempBase\\$area");
      exit;
    }

    if (!(mkdir "$tempBase\\$area\\files")) {
      actLog("Error","Unable to create $tempBase\\$area\\files");
      exit;
    }
    
    $startdate=$archive{$area}{STARTDATE};
    $startdate=~s/(....)(..)(..)(..)(..).*/$1-$2-$3 $4:$5/;
    $enddate=$archive{$area}{ENDDATE};
    $enddate=~s/(....)(..)(..)(..)(..).*/$1-$2-$3 $4:$5/;
    
    @fieldsWithValues=analyzeLogRecords($area);
    $htmlTop=generateHeaders($area,@fieldsWithValues);
    moveFilesAndGenerateIndices($htmlTop,$area,@fieldsWithValues);
    generateStandardFiles($area);
    generateOrder($area);
  }
}

sub byNum{
#
# For numeric sort
#
return $a <=> $b;
}

sub noCase{
#
# For sort regardless of case
#
return lc($a) cmp lc($b)
}

sub byDate{
#
# For record sort by date field
#
return (split(/,/,$a))[3] <=> (split(/,/,$b))[3];
}

