###################################################################
#
#  archBeaconUtil.pm
#
#  Provide access/caching for Beacon data
#
#  Always used as class, never instantiated
#
###################################################################

package archBeaconUtil;

use Exporter ();
@ISA=qw(Exporter);

@EXPORT=qw(cacheBeaconSessionProductInfo @beaconSessions);

use DBI;
use archDB;
use archCache;
use archActLogging;
use archWitnessUtil;

sub init{
#
# Initialize, creating local copy of session information database information
#
($sessionInfoDB,$adverseEventList)=@_;
}

sub cacheBeaconSessionProductInfo{
#
# Cache session information about Beacon related to products
#
my($date)=@_;

my($sql,$dbh,$qh,$dateRestriction,$aeFlag,$withessOptomization,$productOptomization);
my($includecomments,$sp);

if ($date) {
  actLog("Normal","Caching Beacon Sessions for products since $date");
} else {
  actLog("Normal","Caching Beacon Sessions for products");
}
#
# Open the database and define optomizations/options for inclusion
#
$dbh=openDB($sessionInfoDB);
$witnessOptimization="\nAND    W.WITNESS_GUID NOT IN ('-99','Stubbed Contact Id','{00000000-0000-0000-0000-000000000000}')";
$productOptimization="\nAND    P.NAME IS NOT NULL";
$dateRestriction="";
$dateRestriction="\nAND    S.START_TIME > to_date('$date','YYYYMMDDHH24MISS')" if $date;
$includecomments=", upper(S.COMMENTS)";
$includecomments="";

#
# Build SQL statment (outer join on NC Node id because not all nodes have content
# but we only need to identify as different those that do and are AEs
#
$sql=<<END;
SELECT P.NAME, S.SESS_ID, W.WITNESS_GUID, to_char(S.START_TIME,'YYYYMMDDHH24MISS'),
       C.FIRST_NAME, C.LAST_NAME, A.STATE, NC.CONTENT_ID$includecomments
FROM   SESS S, SESS_REASONS R, SESS_WITNESS W, BD_PRODUCT P, CALLER C, ADDRESS A, BD_NODE N,
       BD_NODE_CONTENT NC
WHERE  S.SESS_ID=R.SESS_ID
AND    S.SESS_ID=W.SESS_ID
AND    R.PROD_ID=P.PRODUCT_ID
AND    S.CALLER_ID=C.CALLER_ID
AND    S.CALLER_ID=A.CALLER_ID
AND    N.NODE_ID=R.NODE_ID
AND    P.NAME IS NOT NULL
AND    N.NODE_ID=NC.NODE_ID(+)$dateRestriction$witnessOptimization$productOptimization
ORDER BY P.NAME, S.SESS_ID, NC.CONTENT_ID
END

#
# Prepare statement against database and execute it
#
$qh=$dbh->prepare($sql);
$qh->execute();
#
# Initialize and cache rows into array of hash entries but don't cache unless
# GUID from Beacon is listed in witnessSessions hash. May need to change when
# archiving of non-witness interaction information based on this data
#
$sp=0; # session position
while (@row=$qh->fetchrow_array()) {
  next unless defined $witnessSessions{$row[2]}; # don't cache unless matching witness session (for now)
  $beaconSessions[$sp]{'PRODUCT'}=$row[0];
  $beaconSessions[$sp]{'SESSIONID'}=$row[1];
  $beaconSessions[$sp]{'GUID'}=$row[2];
  $beaconSessions[$sp]{'STARTTIME'}=$row[3];
  $beaconSessions[$sp]{'FIRSTNAME'}=$row[4];
  $beaconSessions[$sp]{'LASTNAME'}=$row[5];
  $beaconSessions[$sp]{'STATE'}=$row[6];
  $beaconSessions[$sp]{'CONTENTID'}=$row[7];
  $beaconSessions[$sp]{'COMMENTS'}=$row[8] if $includecomments;
  $beaconSessions[$sp]{'AE'}= ($beaconSessions[$sp]{'CONTENTID'}=~m/^($adverseEventList)$/) ? 'T' : 'F';
  $sp++;
}
#
# Set flag that "product" information has been cached
#
setCached('product');
actLog("Normal","$sp Beacon sessions cached");
}

1;
