###################################################################
#
#  archWitnessUtil.pm
#
#  Provide access/processing for processing witness sessions
#
#  Always used as class, never instantiated
#
###################################################################

package archWitnessUtil;

use Exporter ();
@ISA=qw(Exporter);

@EXPORT=qw(convertSession sessionFileSize sessionFileName cacheWitnessSessions %witnessSessions);

use DBI;
use archDB;
use archCache;
use RIFF::Info;
use Win32::OLE;
use File::Copy;
use File::Path;

use archActLogging;
use archZipUtil;

sub init{
#
# Initialize module, creating local copies of witnessDB and AVICompression flag
#
  my($x,$location,$result);
  ($witnessDB,$AVIcompression,$WitnessURL,$removeSource,$stubmode)=@_; # localize parameters
#
# Connect to the eQuality system and error out if can't connect.
#

  $eqobj = Win32::OLE->new('EQualityConnectClient.ConnectManager');
  $x=Win32::OLE->LastError;
  if ($x) {
    actLog("Error","Error establishing connection to COM object [$x]");
    exit;
  }
#
# Configure with correct URL
#
  $x=$eqobj->Configure("Adapter URL",$WitnessURL);
#
# Test connection to verify that it is functioning, exit if it isn't
#
  $location=$eqobj->QueryURLStates();
  $result=$eqobj->isValidContact("TestingConnection");
  if (!($result eq "ContactNotFound") && !($result eq "ContactError")) {
    actLog("Error","Error establishing connection to eQuality server at $location ($result)");
    exit;
  }
#
# Log that connection to eQuality has been successful, and what compression
# level is being used if any.
#
  actLog("Normal","Established eQuality connection to $WitnessURL");
  $initialized=1;
  
  actLog("Warning","Witness Stub Mode active!") if $stubmode;
  actLog("Normal","Using compression level $AVIcompression") if $AVIcompression;
  $x="Variable removeSource is ";$x.="not " if $removeSource !=1;$x.="set.";
  actLog("Normal",$x);
}

sub convertSession{
#
# Convert a Witness session into AVI file and, if compressing, zip it
#
  local($guid,$destDir,$destFileNameBase)=@_;
  my($result,$duration,$path,$subdir,@subdirs,$i,$dqresult);

  local($video,$fps,$vframes);

  mkpath($destDir) unless -d "$destDir";
# Above replaced simple mkdir "$destDir" unless -d "$destDir";

  $outfile="$destDir\\$destFileNameBase";
#
# Don't add avi to filename if compressing to avoid xxx.avi.zip filename which
# Internet Explorer interprets as a DNS name in relative url.
#
  $outfile.=".avi" unless $AVIcompression;
#
# This guid could already have been converted in this session, don't do it again
#
  if ($converted{$guid}) {
    $outfile.=".exe" if $converted{$guid} =~ /\.exe$/ & $AVIcompression;
    if ($converted{$guid} ne $outfile) {
      actLog("Normal","File for $guid has already been converted as $converted{$guid}, copying to $outfile");
      copy($converted{$guid},$outfile);
    }
    $duration=$durationFor{$guid};
  } else {
#
# For diagnostic purposes only, stubmode bypasses conversion of Witness data
# to AVI, substituting pre-defined avi file instead.
#
    if ($stubmode) {
      $result="\\\\us0075918\\lockup\\temp.avi";
    } else {
      $three=3;
      $result=$eqobj->ExportContact($guid,$three);
    }
#
# Result could contain error message but doesn't if it begins with two slashes
# indicating a path to the resulting file.
#
    if ($result =~ /^\\\\/) {
#
# If an AVI has been created, get the duration.  Then, if compressing, zip it
# and capture/bubble up any error messages.
#
      $duration=getDuration($result);
      $durationFor{$guid}=$duration;
      if ($AVIcompression > 0) {
        $errorcode=zipIt($result,$outfile);
        if ($errorcode ne "") {
          $@="error message";
          return undef;
        } else {
          $outfile.=".exe";
          if ($removeSource) {
            unlink $result; # remove
            actLog("Warning","File $result not removed: $msg") if -e $result;
            actLog("Warning","For source file $result, output file $outfile doesn't exist") unless -e $outfile;
          }
        }
      } else {
        if ($removeSource) {
          move($result,$outfile);
          unlink $result if -e $result; # remove it if move didn't
        } else {
          copy($result,$outfile);
        }
      }
    } else { # allow caller to process error condition from Witness conversion
      $@=$result;
      chomp ($@);
      return undef;
    }
  }
#
# Remember that we've converted this so we don't have to do it again if there
# is a match for the same guid for another reason.
#
  $converted{$guid}=$outfile;
#
# Remember the size
#
  actLog("Warning","Output file $outfile doesn't exist") unless -e $outfile;
  $fsize=(stat($outfile))[7];
  return $duration;
}

sub sessionFileSize{
#
# Expose the value of the sessionFileSize by this call
#
  return $fsize;
}

sub sessionFileName{
#
# Expose the value of the output file name by this call
#
  return $outfile;
}

sub _videoWarningHandler{
#
# Third-party routine to determine video information can raise a warning signal
# when there are error conditions.  We want this to be handled with a "die"
# which doesn't actually die (since the routine raising the signal was started
# in an eval) but returns the error message for further processing.
#
  local($msg)="@_";
#
# If message has "... at line ..." only keep the part before the word at.
#
  $msg=$1 if $msg=~/(.*) at /;
  die "$msg\n"; # set error message to warning message
}

sub getDuration{
#
# Get duration of video and size of file (in k) rounded to highest 16k
#
  local($videoFile)=@_;
  my($video,$SAVEWARN,$fps,$vframes,$time,$min,$sec,$duration);
#
# Undefine values to ensure that definitions from previous invodations don't
# affect this one.
#
  undef $video,$@;
  if (-e $videoFile) {
#
# Instantiate an RIFF Info object for the video file
#
    $video = RIFF::Info->new(-file=>$videoFile);
    $SAVEWARN=$SIG{__WARN__}; # trap warnings from probe as if they were errors
#
# Set up warning handler so that a carp in the probe routine can be captured and
# handled as if it happened here as a die (in the eval)
#
    $SIG{__WARN__}=\&_videoWarningHandler;
#
# Eval the call to probe to trap any otherwise deadly errors; restore warning
# signal handler afterwards.
#
    eval {$video->probe } if defined $video;
    $SIG{__WARN__}=$SAVEWARN;
  } else {
    $@="File $videoFile does not exist";
    return undef;
  }
   if (!defined $video || $@) { # There is some kind of error, warn but continue
    chomp($@) if $@;
    $@="[$@]" if $@; # put brackets around error message only if it exists.
    actLog("Warning","Unable to determine length of AVI for $guid $@");
    $duration="x:xx";
  } else {
#
# Determine the duration buy inspecting the info returned by the probe and
# calculating the time as frames per second times number of seconds -- then
# convert to number of minutes and seconds in form min:ss.
#
    $fps=$video->fps();
    $vframes=$video->vframes();
    $time=($fps==0)? 0 : int($vframes/$fps+.5);
    $min=int($time/60);
    $min=($min == 0) ? "0" : $min;
    $sec=$time-($min*60);
    $sec= "0$sec" if $sec < 10;
    $duration="$min:$sec";
  }
  close($video->handle); # close the open handle, object doesn't destroy when out of scope!
  return $duration;
}

sub cacheWitnessSessions{
#
# Cache witness session information
#
my ($sql,$dbh,$qh,@row,$nc);
actLog("Normal","Caching Witness Sessions");
$dbh=openDB($witnessDB);
#
# Build SQL statement to pull date of earliest start time of any contact in
# Witness; then prepare/execute/fetch result
#
$sql=<<END;
select to_char(min(c.begin_time),'YYYYMMDDHH24MISS')
from cust_cont c, cont_fold_ass a, cont_cat_fold f
where c.cust_cont_pk=a.cust_cont_pk
and a.cont_cat_fold_pk=f.cont_cat_fold_pk
and f.cont_cat_type_pk = 3
END
$qh=$dbh->prepare($sql);
$qh->execute;
@row = $qh->fetchrow_array();
$witnessSessions{'earliest'}=$row[0];
#
# Build SQL statement to pull data from witness for each contact then prepare,
# and execute it.
#
$sql=<<END;
select cont_guid, character1, to_char(c.begin_time,'YYYYMMDDHH24MISS')
from cust_cont c, cont_fold_ass fa, cont_cat_fold cf, agent a, person p
where cf.cont_cat_type_pk=3
and   cf.cont_cat_fold_pk=fa.cont_cat_fold_pk
and   c.cust_cont_pk=fa.cust_cont_pk
and   a.cust_cont_pk=c.cust_cont_pk
and   p.person_pk=a.person_pk
END
$qh=$dbh->prepare($sql);
$qh->execute();
$nc=0;
#
# Fetch results and cache into hash of hashes with first hash indexed by GUID
# and second hash indexed by type of data.
#
while (@row=$qh->fetchrow_array()) {
  $row[1]="NS" if $row[1] eq "";
  $nc++ unless defined $witnessSessions{$row[0]};
  $witnessSessions{$row[0]}{'AGENTTYPE'}=$row[1];
  $witnessSessions{$row[0]}{'STARTTIME'}=$row[2];

}
#
# Set flag indicating that witness data has been cached
#
actLog("Normal","$nc Witness sessions cached");
setCached('witness');
}
