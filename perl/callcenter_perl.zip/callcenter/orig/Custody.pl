###############################################################
#
#  Program: Custody
#  Written by Stephen G. Keilholz
#  Purpose: Extract and store data related to contacts in an
#           orderly manner for later archiving to removable
#           media such as CD or DVD.
#
#           Specific types of data envisioned are AVI versions
#           of sessions from Witness and textual data from
#           beacon.
#
###############################################################

use DBI;
use POSIX qw(strftime);
use File::Copy;
use Config::ini;
use RIFF::Info;
use Win32::OLE;

### Use statements required for compiled version
use Carp::Heavy;
use DBD::Oracle;
use Witness;
use WITNESSPRODUCT;
###

use archReasons;
use archLogging;
use archActLogging;
use archWitnessUtil;
use archRequests;
use archBeaconUtil;
use archZipUtil;

initializeProgram();
#
# Data is determined as requiring archiving based on reasons which are
# stored in a database.  Load them into memory for processing, process them
# generating "requests" for data to be archived.  Then process the requests
# creating local copies of data from whatever the source may have been and
# storing them into a specific directory structure for later archival.
#
actLog("Normal","Initialization complete");
archReasons::load();
archReasons::process();
if ($dumpMode) {
  archRequests::dumpRequests($dumpFile);
  actLog("Normal","Request information sent to file $dumpFile");
} else {
  archRequests::process();
}
actLog("Normal","Program ended normally.");
close(STDOUT);close(STDERR);
exit;

sub initializeProgram{
#
# Get program configuration from configuration file
#
  $|=1;select(STDERR);$|=1;select(STDOUT); # unbuffer both STDERR and STDOUT
#
# Set up program namd for error logging/reporting purposes and open config file
#
  $PROGNAME="Custody";
  $W2CIni=new Config::Ini('W2C.ini');
#
# Get error handling variables from configuration file, specifying defaults
# if they aren't there.
#
  $logLevel=$W2CIni->get(['ErrorHandling','LogLevel']) || "None";
  $errorLogDateFmt=$W2CIni->get(['ErrorHandling','errorLogDateFmt']) || "%y%d%m%H%M%S";
  $errorNotification=$W2CIni->get(['ErrorHandling','ErrorNotification']) || "None";
  $logdatefmt=$W2CIni->get(['ErrorHandling','LogDateFmt']) || "%y%d%m%H%M%S";
  @addresses=$W2CIni->get(['ErrorHandling','Notify_'.$errorNotification]) unless $errorNotification eq "None";
  $mailHost=$W2CIni->get(['ErrorHandling','MailHost']) unless $errorNotification eq "None";
  $mailOriginator=$W2CIni->get(['ErrorHandling','MailOriginator']) unless $errorNotification eq "None";
#
# Initialize ActivityLogging
#
  actLogInit($logLevel,$errorNotification,$PROGNAME,$mailHost,$mailOriginator,$errorLogDateFmt,@addresses);
  actLog("Normal","Program started");
#
# Get base of directory structure into which data is to be stored and source remove flag
#
  $base=$W2CIni->get(['DirStructure','Base']);
  $removeSource=$W2CIni->get(['DirStructure','removeSource']);
#
# Get information about databases
#
  $sessionInfoDB=$W2CIni->get(['Databases','SessionInfo']);
  $witnessDB=$W2CIni->get(['Databases','Witness']);
  $logActivityDB=$W2CIni->get(['Databases','LogActivity']);
#
# Get list of content nodes from beacon which indicate an adverse event
#
  $AEContentNodeIDs=$W2CIni->get(['Data','AEContentNodeIDs']);
#
# Get all compression-related variables
#
  $AVIcompression=$W2CIni->get(['Compression','AVIcompression']);
  $rate=$W2CIni->get(['Compression','rate']);
  $zipProg=$W2CIni->get(['Compression','zipProg']);
  $zipSEProg=$W2CIni->get(['Compression','zipSEProg']);
  $batchfile=$W2CIni->get(['Compression','batchfile']);
  $semsgfile=$W2CIni->get(['Compression','semsgfile']);
  $logofile=$W2CIni->get(['Compression','logofile']);
  $stubmode=$W2CIni->get(['Compression','stubmode']);
#
# Get Witness URL (Server)
#
  $WitnessURL=$W2CIni->get(['Servers','Witness']);
#
# Process Argument List, if any
#
  $dumpMode=$dumpFile="";
  if ("\U$ARGV[0]" eq "DUMP") {
    shift @ARGV;
    $dumpMode=1;
    $dumpFile=shift @ARGV;
#    delete $ARGV[1];
#    delete $ARGV[0];
    actLog("Normal","Operating in request dump mode, no requests will be processed");
  }
#
# Initialize each module with local copies of configuration variables
#
  archWitnessUtil::init($witnessDB,$AVIcompression,$WitnessURL,$removeSource,$stubmode);
  archReasons::init($logActivityDB,@ARGV); # list of reasons on command line 1 2 4-6 9
  archLogging::init($logActivityDB);
  archBeaconUtil::init($sessionInfoDB,,$AEContentNodeIDs);
  archRequests::init($base,$logdatefmt);
  archZipUtil::init($rate,$zipProg,$zipSEProg,$batchfile,$semsgfile,$logofile,$removeSource);
}
