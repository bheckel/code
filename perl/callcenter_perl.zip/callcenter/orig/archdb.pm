###################################################################
#
#  archDB.pm
#
#  Provide database open processing caching databases to prevent
#  multpile opens, expecially when multiple "databases" are really
#  the same database.
#
#  Always used as class, never instantiated
#
###################################################################

package archDB;

use DBI;
use Exporter ();
@ISA=qw(Exporter);

@EXPORT=qw(openDB);

use archActLogging;

sub openDB{
#
# Return database handle of existing open database or open one if not open.
#
  my($dbid)=@_;
#
# Return open handle if already open
#
  return $openDBS{$dbid} if $openDBS{$dbid};
#
# Extract from database identifier fields for opening and open database; exit
# with error message if unable to open, otherwise return opened database handle
#
  ($tnsname,$user,$pw)=split(/,/,$dbid);
  if (!defined($openDBS{$dbid}=DBI->connect('dbi:Oracle:',"$user\@$tnsname",$pw))) {
    actLog("Error","Unable to open $tnsname ($DBI::errstr)\n");
    exit;
  }
  return $openDBS{$dbid};
}
