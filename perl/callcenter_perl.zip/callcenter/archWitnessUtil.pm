###################################################################
#
#  archWitnessUtil.pm
#
#  Provide access/processing for processing witness sessions
#
#  Always used as class, never instantiated
#
###################################################################

package archWitnessUtil;

use Exporter ();
@ISA=qw(Exporter);

@EXPORT=qw(convertSession sessionFileSize sessionFileName 
           cacheWitnessSessions %witnessSessions %witnessADSessions);

use DBI;
use DBD::Oracle qw(:ora_types);
use archDB;
use archCache;
use Video::Info::RIFF;
use Win32::OLE;
use File::Copy;
use File::Path;
use archActLogging;
use archZipUtil;


sub init{
#
# Initialize module, creating local copies of logActivityDB and AVICompression flag
#
  my($x,$location,$result);
# Localize parameters
  ($logActivityDB,$AVIcompression,$WitnessURL,$removeSource,$stubmode,
   $witEarliestDtOverride,$testAVIfile,$existCheckDelay,$existCheckTries,
   $sizeCheckDelay,$exportRetryDelay)=@_;
#
# Connect to the eQuality system and error out if can't connect.
#

  $eqobj = Win32::OLE->new('EQualityConnectClient.ConnectManager');
  $x=Win32::OLE->LastError;
  if ($x) {
    actLog("Error","Error establishing connection to COM object [$x]");
    exit;
  }
#
# Configure with correct URL
#
  $x=$eqobj->Configure("Adapter URL",$WitnessURL);
#
# Test connection to verify that it is functioning, exit if it isn't
#
  $location=$eqobj->QueryURLStates();
  $result=$eqobj->isValidContact("TestingConnection");
  if (!($result eq "ContactNotFound") && !($result eq "ContactError")) {
    actLog("Error","Error establishing connection to eQuality server at $location ($result)");
    exit;
  }
#
# Log that connection to eQuality has been successful, and what compression
# level is being used if any.
#
  actLog("Normal","Established eQuality connection to $WitnessURL");
  $initialized=1;
  
  actLog("Warning","Witness Stub Mode active!") if $stubmode;
  actLog("Normal","Using compression level $AVIcompression") if $AVIcompression;
  $x="Variable removeSource is ";$x.="not " if $removeSource !=1;$x.="set.";
  actLog("Normal",$x);
}

sub convertSession{
#
# Convert a Witness session into AVI file and, if compressing, zip it
#
  local($guid,$destDir,$destFileNameBase)=@_;
  my($result,$duration,$path,$subdir,@subdirs,$i,$dqresult);

  local($video,$fps,$vframes);

  mkpath($destDir,1,0777) unless -d "$destDir";

  $outfile="$destDir\\$destFileNameBase";
#
# Don't add avi to filename if compressing to avoid xxx.avi.zip filename which
# Internet Explorer interprets as a DNS name in relative url.
#
  $outfile.=".avi" unless $AVIcompression;
#
# This guid could already have been converted in this session, don't do it again
#
  if ($converted{$guid}) {
    $outfile.=".exe" if $converted{$guid} =~ /\.exe$/ & $AVIcompression;
    if ($converted{$guid} ne $outfile) {
      actLog("Normal","File for $guid has already been converted as $converted{$guid}, copying to $outfile");
      copy($converted{$guid},$outfile);
    } # if ($converted{$guid} ne $outfile)
    
    $duration=$durationFor{$guid};
  } else {
    if ($stubmode) {
      # For diagnostic purposes only, stubmode bypasses conversion of Witness data
      # to AVI, substituting pre-defined avi file instead.
      ###$result="\\\\us0075918\\lockup\\temp.avi";  # TODO use ini for path
      $result="$testAVIfile";
    } else { # if ($stubmode)
      $three=3;
      $result=$eqobj->ExportContact($guid,$three);

#Debug Only Message
actLog("Warning","ExportContact result = [$result]");

      # Check for error from ExportContact
      if ($result !~ /^\\\\/) {
        actLog("Error","ExportContact returned [$result] for $guid.");
        $WitnessURL =~ /(\w+)\..*/;  # get hostname
        $guess="\\\\$1\\exports\\Export-$guid-b.avi";

#Debug Only Message
actLog("Warning","guess = [$guess]");

        # Check for 0 error
        if ($result == 0){

          # Initalize loop counter
          $lCounter = 0;
#Debug Only Message
actLog("Warning","Pre $guess exists check.");
actLog("Warning","lCounter = [$lCounter]");

          #Loop until time expired or file exists
          while ( $lCounter < $existCheckTries ){
            $lCounter++;

            sleep $existCheckDelay; 
              
            # check to see if file exists yet
            if (-e $guess) {
              actLog("Warning","$guess exists. Loop count is [$lCounter]");
              
              #set loop counter to a value that will end the looping and signify
              #that the file exists (bad form I know...)
              $lCounter = 10;
            } # if if (-e $guess)
          } # while ( $lCounter < 4 )
          

#Debug Only Message
actLog("Warning","Post Sleep 10 before $guess exists check.");

          # Check to see if the file exists
          if ($lCounter == 10) {
            #Get initial file size
            $s = (stat($guess))[7];
            actLog("Warning","$guess exists. $s bytes");

            sleep $sizeCheckDelay;
            $news = (stat($guess))[7];

#Debug Only Message
actLog("Warning","Initial size $s , new size $news");
            
            #Loop until file has stopped growing
            while ( $news > $s ) {
              $s = $news;

              sleep $sizeCheckDelay; 
              $news = (stat($guess))[7];
              
              # check to see if file grew
              if ($news > $s) {
                actLog("Warning","$guess is growing. Now $news bytes");
              } # if ($news > $s)
            } # while ( $news > $s )
            
            # File exists and done growing
            $result = $guess;
          } else { # if ($lCounter == 10)
            actLog("Warning","$guess DOES NOT exist");
          } # if ($lCounter == 10)
        } else { # if ($result = 0)
        # Any error other than 0 
          sleep $exportRetryDelay;
          $result=$eqobj->ExportContact($guid,$three);  # try again
          actLog("Warning","2nd call to ExportContact returned [$result] for $guid");
        } # if ($result = 0)
      } # if ($result !~ /^\\\\/)
    } # if ($stubmode)

#
# Result could contain error message but doesn't if it begins with two slashes
# indicating a path to the resulting file.
#
    if ($result =~ /^\\\\/) {
#
# If an AVI has been created, get the duration.  Then, if compressing, zip it
# and capture/bubble up any error messages.
#
      $duration=getDuration($result);
      $durationFor{$guid}=$duration;
      if ($AVIcompression > 0) {
        $errorcode=zipIt($result,$outfile);
        if ($errorcode ne "") {
          $@="error message";
          return undef;
        } else {
          $outfile.=".exe";
          if ($removeSource) {
            unlink $result;
            actLog("Warning","File $result not removed: $msg") if -e $result;
            actLog("Warning","For source file $result, output file $outfile doesn't exist") unless -e $outfile;
          }
        }
      } else {
        if ($removeSource) {
          move($result,$outfile);
          unlink $result if -e $result; # remove it if move didn't
        } else {
          copy($result,$outfile);
        }
      }
    } else { # allow caller to process error condition from Witness conversion
      $@=$result;
      chomp ($@);
      return undef;
    }
  }
#
# Remember that we've converted this so we don't have to do it again if there
# is a match for the same guid for another reason.
#
  $converted{$guid}=$outfile;
#
# Remember the size
#
  actLog("Warning","Output file $outfile doesn't exist") unless -e $outfile;
  $fsize=(stat($outfile))[7];

  return $duration;
}

sub sessionFileSize{
#
# Expose the value of the sessionFileSize by this call
#
  return $fsize;
}

sub sessionFileName{
#
# Expose the value of the output file name by this call
#
  return $outfile;
}

sub _videoWarningHandler{
#
# Third-party routine to determine video information can raise a warning signal
# when there are error conditions.  We want this to be handled with a "die"
# which doesn't actually die (since the routine raising the signal was started
# in an eval) but returns the error message for further processing.
#
  local($msg)="@_";
#
# If message has "... at line ..." only keep the part before the word at.
#
  $msg=$1 if $msg=~/(.*) at /;
  die "$msg\n"; # set error message to warning message
}

sub getDuration{
#
# Get duration of video and size of file (in k) rounded to highest 16k
#
  local($videoFile)=@_;
  my($video,$SAVEWARN,$fps,$vframes,$time,$min,$sec,$duration);
#
# Undefine values to ensure that definitions from previous invodations don't
# affect this one.
#
  undef $video,$@;
  if (-e $videoFile) {

    $video = Video::Info::RIFF->new(-file=>$videoFile);
    $SAVEWARN=$SIG{__WARN__}; # trap warnings from probe as if they were errors
#
# Set up warning handler so that a carp in the probe routine can be captured and
# handled as if it happened here as a die (in the eval)
#
    $SIG{__WARN__}=\&_videoWarningHandler;
#
# Eval the call to probe to trap any otherwise deadly errors; restore warning
# signal handler afterwards.
#
    eval {$video->probe } if defined $video;
    $SIG{__WARN__}=$SAVEWARN;
  } else {
    $@="File $videoFile does not exist";
    return undef;
  }
   if (!defined $video || $@) { # There is some kind of error, warn but continue
    chomp($@) if $@;
    $@="[$@]" if $@; # put brackets around error message only if it exists.
    actLog("Warning","Unable to determine length of AVI for $guid $@");
    $duration="x:xx";
  } else {
#
# Determine the duration buy inspecting the info returned by the probe and
# calculating the time as frames per second times number of seconds -- then
# convert to number of minutes and seconds in form min:ss.
#
    $fps=$video->fps();
    $vframes=$video->vframes();
    $time=($fps==0)? 0 : int($vframes/$fps+.5);
    $min=int($time/60);
    $min=($min == 0) ? "0" : $min;
    $sec=$time-($min*60);
    $sec= "0$sec" if $sec < 10;
    $duration="$min:$sec";
  }
  close($video->handle); # close the open handle, object doesn't destroy when out of scope!

  return $duration;
}

sub cacheWitnessSessions{
#
# Cache witness session information
#
my ($dbh,$sth,$sth0,$sth2,$sth3,$sth4,$dt,@row,$nc);
actLog("Normal","Caching Witness Sessions");
$dbh=openDB($logActivityDB);
#
# Build SQL statement to pull date of earliest start time of any contact in
# Witness; then prepare/execute/fetch result
#
$sth0 = $dbh->prepare( q{
  BEGIN
      :dt := CRCARCH_BATCH.WITNESS.GET_OLDEST_CONTACT;
  END;
} );

$sth0->bind_param_inout(":dt", \$dt, 20);
$sth0->execute;

if ( $witEarliestDtOverride == 'None' ) {
  $witnessSessions{'earliest'}=$dt;
} else {
  $witnessSessions{'earliest'}=$witEarliestDtOverride;
  actLog("Warning","\$witnessSessions{earliest} from db is $dt but override is $witnessSessions{earliest}");
}

#
# Pull data from Witness for each contact for Product
#
$sth = $dbh->prepare( q{
  BEGIN
      :sth2 := CRCARCH_BATCH.WITNESS.GET_ALL_CONTACTS;
  END;
} );

$sth->bind_param_inout(":sth2", \$sth2, 0, { ora_type => ORA_RSET });
$sth->execute;

while (@row=$sth2->fetchrow_array()) {
  $row[1]="NS" if $row[1] eq "";
  $nc++ unless defined $witnessSessions{$row[0]};
  $witnessSessions{$row[0]}{'AGENTTYPE'}=$row[1];
  $witnessSessions{$row[0]}{'STARTTIME'}=$row[2];

}

#
# Pull data from Witness for each contact for Caller attached data
#
$sth3 = $dbh->prepare( q{
  BEGIN
      :sth4 := CRCARCH_BATCH.WITNESS.GET_ATTACHED_DATA_CONTACTS('CALLER_ROLE','FIELD%');
  END;
} );

$sth3->bind_param_inout(":sth4", \$sth4, 0, { ora_type => ORA_RSET });
$sth3->execute;

while (@row=$sth4->fetchrow_array()) {
  $row[1]="NS" if $row[1] eq "";
  $nc++ unless defined $witnessADSessions{$row[0]};
  $witnessADSessions{$row[0]}{'AGENTTYPE'}=$row[1];
  $witnessADSessions{$row[0]}{'STARTTIME'}=$row[2];

}

actLog("Normal","$nc Witness and WitnessAD sessions cached");

#
# Set flag indicating that witness data has been cached
#
setCached('witness');
}
