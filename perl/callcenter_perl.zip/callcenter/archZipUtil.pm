###################################################################
#
#  archZipUtil.pm
#
#  Provide ziping to self-extracting archives
#
###################################################################

package archZipUtil;

use Exporter ();
@ISA=qw(Exporter);
use File::Basename;
use archActLogging;

@EXPORT=qw(zipIt);


sub init{
#
# Initialization to create local copies of values
#
($rate,$zipProg,$zipSEProg,$batchfile,$semsgfile,$logofile,$removeSource)=@_;
actLog("Warning","Zip program $zipProg does not exist") unless !$zipProg || -e $zipProg;
actLog("Warning","ZipSE program $zipSEProg does not exist") unless !$zipSEProg || -e $zipSEProg;
}

sub zipIt{
#
# Zip the input file to the output file
#
my($infilename,$outfilename)=@_;
#
# Set up options; localize filename adding ".zip" unless it already has it;
# then get filename portion of the input file
#
my($stdopts)="-e$rate -o -a";
my($zipfile)=$outfilename;
$zipfile.=".zip" unless $zipfile=~/\.zip$/;
my($czipfile)=$outfilename;
$czipfile.=".exe" unless $czipfile=~/\.exe$/;
my($innerfile)=basename($infilename);

#
# Save stdout and stderror and close them.  This is required to eliminate
# messages from zip program from appearing in output.
#
open SAVEOUT,">&STDOUT";
open SAVEERR,">&STDERR";
close(STDERR);
close(STDOUT);
#
# Perform zipping adding the inputfile and the batch file to the new zip file
#
system("$zipProg $stdopts $zipfile $infilename $batchfile");
actLog("Warning","Zip file not created for $innerfile") unless -e $zipfile;
### do error checks here, return error message
#
# If a self-extract program is defined, set up options and create the exe file
# removing the intermediate file afterwards
#

if ($zipSEProg ne "") {
  $options="-setup -le -auto -st\"Extracting...\"";
  $options.=" -t $semsgfile" if $semsgfile ne "";
  $options.=" -i $logofile" if $logofile ne "";
  $options.=" -o -c\"$batchfile $innerfile\"";
  $rc=system("$zipSEProg $zipfile $options");
  actLog("Warning","Compressed Zip file ($czipfile) not created for $zipfile, retcode:$rc") unless -e "$czipfile";
  unlink $zipfile if -e $czipfile;
}
unlink $infilename if $removeSource; # removes AVI file
#
# Re-instate STDOUT and STDERROR
#
open STDOUT,">&SAVEOUT";
open STDERR,">&SAVEERR";
return "";
}

1;
