2007-08-02 added Debugging section, copied to rtpsaeql002

2007-07-25 mostly the same as on rtpsaeql002 but don't edit these, use the
server versions
