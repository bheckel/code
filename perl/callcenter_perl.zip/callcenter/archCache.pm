###################################################################
#
#  archCache.pm
#
#  Provide access to cache hash across modules
#
#  Always used as class, never instantiated
#
###################################################################

package archCache;
use Exporter ();
@ISA=qw(Exporter);

@EXPORT=qw(setCached resetCached isCached);

sub setCached{
#
# Set variable to indicate that area (as passed in) has been cached
#
  $cached{$_[0]}=1;
}

sub resetCached{
#
# Reset variable indicating that area cache is no longer valid
#
  $cached{$_[0]}="";
}

sub isCached{
#
# Check to see if area has been cached
#
  return $cached{$_[0]}
}
