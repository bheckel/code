###################################################################
#
#  archBeaconUtil.pm
#
#  Provide access/caching for Beacon data
#
#  Always used as class, never instantiated
#
###################################################################

package archBeaconUtil;

use Exporter ();
@ISA=qw(Exporter);

@EXPORT=qw(cacheBeaconSessionProductInfo @beaconSessions @beaconADSessions);

use DBI;
use DBD::Oracle qw(:ora_types);
use archDB;
use archCache;
use archActLogging;
use archWitnessUtil;

sub init{
#
# Initialize, creating local copy of session information database information
# and populate a list of known AEs.
#
($logactivityDB)=@_;

$dbh=openDB($logactivityDB);

$sth = $dbh->prepare( q{
  BEGIN
      :sth2 := CRCARCH_BATCH.BEACON.GET_AE_NODES;
  END;
} );

$sth->bind_param_inout(":sth2", \$sth2, 0, { ora_type => ORA_RSET });
$sth->execute;

my $n=0;
while ( my @row = $sth2->fetchrow_array ) { 
  $adverseEventList .= $row[0] . '|'; 
  $n++;
}
chop $adverseEventList;  # remove trailing '|' for later regex

actLog("Normal","$n AE nodes loaded");
}

sub cacheBeaconSessionProductInfo{
#
# Cache session information about Beacon related to products
#
my $date = shift;

my($qh,$qh2,$qh3,$qh4,$dateRestriction,$aeFlag,$withessOptomization,$productOptomization);
my($includecomments,$sp);

if ($date) {
  actLog("Normal","Caching Beacon Sessions for products since $date");
} else {
  # Default
  $date = 200700000000000;
  actLog("Warning","Caching Beacon Sessions for products using default date $date");
}
#
# Open the database and define optomizations/options for inclusion
#
$dbh=openDB($logactivityDB);

#
# Build SQL statment (outer join on NC Node id because not all nodes have content
# but we only need to identify as different those that do and are AEs
#
# 1------ Beacon Product:
# [0] Product   - Product Name
# [1] SessionID - Beacon Session ID
# [2] GUID      - Witness GUID
# [3] StartTime - When the contact started {YYYYMMDDHH24MISS}
# [4] FirstName - Customer First Name
# [5] LastName  - Customer Last Name
# [6] State     - Customer State from address
# [7] ContentID - Beacon Node Content ID
$qh = $dbh->prepare( q{
  BEGIN
      CRCARCH_BATCH.BEACON.get_product_contacts(:date, :qh2);
  END;
} );

$qh->bind_param(":date", $date);
$qh->bind_param_inout(":qh2", \$qh2, 0, { ora_type => ORA_RSET });

$qh->execute();
#
# Initialize and cache rows into array of hash entries but don't cache unless
# GUID from Beacon is listed in witnessSessions hash. May need to change when
# archiving of non-witness interaction information based on this data
#
$sp=0; # session position
while (@row=$qh2->fetchrow_array()) {
  next unless defined $witnessSessions{$row[2]}; # don't cache unless matching witness session (for now)
  $beaconSessions[$sp]{'PRODUCT'}=$row[0];
  $beaconSessions[$sp]{'SESSIONID'}=$row[1];
  $beaconSessions[$sp]{'GUID'}=$row[2];
  $beaconSessions[$sp]{'STARTTIME'}=$row[3];
  $beaconSessions[$sp]{'FIRSTNAME'}=$row[4];
  $beaconSessions[$sp]{'LASTNAME'}=$row[5];
  $beaconSessions[$sp]{'STATE'}=$row[6];
  $beaconSessions[$sp]{'CONTENTID'}=$row[7];
  $beaconSessions[$sp]{'COMMENTS'}=$row[8] if $includecomments;
  $beaconSessions[$sp]{'AE'}= ($beaconSessions[$sp]{'CONTENTID'}=~m/^($adverseEventList)$/) ? 'T' : 'F';
  $sp++;
}


# 2------ Beacon Caller:
# [0] SessionID - Beacon Session ID
# [1] GUID      - Witness GUID
# [2] StartTime - When the contact started {YYYYMMDDHH24MISS}
# [3] FirstName - Customer First Name
# [4] LastName  - Customer Last Name
# [5] State     - Customer State from address
# [6] ContentID - Beacon Node Content ID
$qh3 = $dbh->prepare( q{
  BEGIN
      :qh4 := CRCARCH_BATCH.BEACON.get_all_contacts(:date);
  END;
} );

$qh3->bind_param(":date", $date);
$qh3->bind_param_inout(":qh4", \$qh4, 0, { ora_type => ORA_RSET });

$qh3->execute();

while (@row=$qh4->fetchrow_array()) {
  next unless defined $witnessADSessions{$row[1]}; # don't cache unless matching witness session (for now)
  $beaconSessions[$sp]{'PRODUCT'}='Attached_Data';
  $beaconSessions[$sp]{'SESSIONID'}=$row[0];
  $beaconSessions[$sp]{'GUID'}=$row[1];
  $beaconSessions[$sp]{'STARTTIME'}=$row[2];
  $beaconSessions[$sp]{'FIRSTNAME'}=$row[3];
  $beaconSessions[$sp]{'LASTNAME'}=$row[4];
  $beaconSessions[$sp]{'STATE'}=$row[5];
  $beaconSessions[$sp]{'CONTENTID'}=$row[6];
  $beaconSessions[$sp]{'AE'}= 'F';
  $sp++;
}
$beaconSessions[$sp]{'PRODUCT'}='Attached_Data';
$beaconSessions[$sp]{'SESSIONID'}='500000';
$beaconSessions[$sp]{'GUID'}='{CEADADAD-60CD-4111-B3C6-AE70DFA6506B}';
$beaconSessions[$sp]{'STARTTIME'}='20070321101900';
$beaconSessions[$sp]{'FIRSTNAME'}='FoobAD';
$beaconSessions[$sp]{'LASTNAME'}='BarbAD';
$beaconSessions[$sp]{'STATE'}='NCAD';
$beaconSessions[$sp]{'CONTENTID'}='9000';
$beaconSessions[$sp]{'AE'}='F';
$sp++;

#
# Set flag that "product" information has been cached
#
setCached('beacon');
actLog("Normal","$sp Beacon sessions cached");
}

1;
