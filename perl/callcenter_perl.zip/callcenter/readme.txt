2007-10-18
project backup:
Make sure Lit_Hold doesn't have tons of .exes, then:
$ cd /home/bheckel/projects;p=crc;d=`date '+%Y%m%d'`;tar cfz $p.$d.tar.gz callcenter/ && cp -i $p.$d.tar.gz /cygdrive/u/ && rmv $p.$d.tar.gz

-----

2007-09-27
$ rm -rf /home/bheckel/projects/callcenter/harness/LitHold_Test/CAInstall/harness/Lit_Hold_Images/DDProdMedB/ANCEF/ && rm -rf /home/bheckel/projects/callcenter/harness/LitHold_Test/CAInstall/harness/Lit_Hold_Images/ProdMedB/SUMATRIPTAN/ && rm -rf /home/bheckel/projects/callcenter/harness/LitHold_Test/CAInstall/harness/Lit_Hold_Images/Caller_Role/FIELD/ && perl Lockup.pl; #grep -a potentialHeaderFields junkdumpmain

-----

2007-09-19
indexTop.txt, rowHeaders.txt on cygwin (development) must be ff=unix

-----

2007-07-19 
Any INIs in this folder are debug-only

-----

Compile to exe:

1. edit here on laptop


1.5 make sure the VM has been logged into as Administrator/the9Fisu lately and
    that current code should go into the main /callcenter-compile dir


2. backup (rename) VM's old version then copy laptop's new to VM

$ mv //192.168.52.128/callcenter-compile/{Custody.pl,Custody.`date +%d%b`.pl}
  or
$ mv //192.168.52.128/callcenter-compile/{Cleanup.pl,Cleanup.`date +%d%b`.pl}
$ cp -i ~/projects/callcenter/Custody.pl //192.168.52.128/callcenter-compile/Custody.pl
  or
$ cp -i ~/projects/callcenter/Cleanup.pl //192.168.52.128/callcenter-compile/Cleanup.pl


3. on VM,
> cd C:\projects\callcenter-compile
> perl2exe Custody.pl


4. on laptop, copy (or just Send To) to U:
TODO not working 2007-11-18 - used Send To instead
$ cp //192.168.52.128/callcenter-compile/Custody.exe U:/


5. Remote Desktop to rtpsaeql002, copy new Custody.exe from U: to
   F:\LitHold_Test\CAinstall\
   or
   F:\LitHold_Test\CAinstall_Lockup
   or
   F:\LitHold_Test\CAinstall_Cleanup
