{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}

Custody.pl ("Extract and store data related to contacts")
1-initializeProgram() 
  get ini data, Initialize each module with local copies of those config
  variables

  return to Custody.pl

2-archReasons::load() 
  use "global" db handle $logactivityDB to run 1 DBI:

  SQL Statement which produced this data:  APPEARS TO ALWAYS BE SAME DATA??
            [0]         [1]             [2]           [3]      [4]             [5]
    select reason_id, group_dir_name, area_dir_name, value, search_type_name,source_name,Xend_date 
    from crc_arch_reasons r, crc_arch_grp g, crc_arch_area a, 
    crc_arch_search_type t, crc_arch_source s 
    where end_date > sysdate
    and r.group_id=g.group_id 
    and r.area_id=a.area_id 
    and r.search_type_id=t.search_type_id 
    and r.source_id=s.source_id 
    order by search_type_name, group_dir_name, area_dir_name, reason_id
  1	DDProdMedB	ANCEF	ANCEF	Product	Witness	31-Dec-99	
  2	DDProdMedB	BACTOCILL	BACTOCILL	Product	Witness	31-Dec-99	

  | @{ $reasonList[$p++] }=@row; <---used next in archreason::process/WITNESSPROD::process(...)
    e.g. $reasonList[0] is a ref to an array that looks like this:
$VAR1 = [
          '1',
          'DDProdMedB',
          'ANCEF',
          'ANCEF',
          'Product',  <---search_type_name/$type will be 'Attached_Data' for new version
          'Witness'
        ];
...
$VAR121 = [...       <---about 121 reasons load

  | $areaForReason{$row[0]}="$row[1]\\$row[2]" <---exported to WITNESSPRODUCT.pm
                                                   (and archLogging.pm)
  so %areaForReason looks partially like this:
$VAR131 = '1';
$VAR132 = 'DDProdMedB\\ANCEF';

  return to Custody.pl

3-archReasons::process() 
 process each reason | @{ $reasonList[$r] } parsing like so:
 ($reasonNo,$group,$area,$value,$type,$source)=@{ $reasonList[$r] };
 "Normal 07/16/03 15:23:49 Object is WITNESSPRODUCT, area is ANCEF, reason is 1"
...
123VaccinesENGERIXBENGERIX-BProductWitness
148Caller_RoleFIELDFIELD%Attached_DataWitness
1DDProdMedBANCEFANCEFProductWitness
...

  then use runtime magic on $type 'require WITNESSPRODUCT.pm;',dynamically call foo::process()
  for each array elem (may be called by WITN or WITNAD but uses cache so runs once) e.g.:
                            WITNESSPRODUCT,   1,      DDProdMedB,ANCEF,ANCEF
**-*WITNESSPRODUCT::process($self,         $reasonNo,  $group,  $area,$value) ****
    - call archWitnessUtil::cacheWitnessSessions() PASSING NOTHING, just do 
      2 bulk DBIs using "global" equadmin/passion@usprd94 $witnessDB handle to 
      do A & B:
                              [0]
      A-select to_char(min(c.begin_time),'YYYYMMDDHH24MISS')      <---get earliest date
      from cust_cont c, cont_fold_ass a, cont_cat_fold f
      where c.cust_cont_pk=a.cust_cont_pk
      and a.cont_cat_fold_pk=f.cont_cat_fold_pk
      and f.cont_cat_type_pk = 3
      | witnessSessions{'earliest'}=$row[0];  <---eg 20040304184943

      and then still using same witness db handle:
               [0]          [1]                 [2]
      B-select cont_guid, character1, to_char(c.begin_time,'YYYYMMDDHH24MISS')
      from cust_cont c, cont_fold_ass fa, cont_cat_fold cf, agent a, person p
      where cf.cont_cat_type_pk=3
      and   cf.cont_cat_fold_pk=fa.cont_cat_fold_pk
      and   c.cust_cont_pk=fa.cust_cont_pk
      and   a.cust_cont_pk=c.cust_cont_pk
      and   p.person_pk=a.person_pk

        [0]         [1]            [2]
      CONT_GUID	CHARACTER1	TO_CHAR(C.BEGIN_TIME,'YYYYMMDDHH24MISS')
      {1F11A5BF-608A-49A2-978F-160A50E1B42F}	NS	20070223130427
      {1F11A5BF-608A-49A2-978F-160A50E1B42F}		20070223130427
      {1F11A5BF-608A-49A2-978F-160A50E1B42F}		20070223130427
      {1F11A5BF-608A-49A2-978F-160A50E1B42F}		20070223130427
      {1F11A5BF-608A-49A2-978F-160A50E1B42F}		20070223130427
      {1F11A5BF-608A-49A2-978F-160A50E1B42F}		20070223130427
      {1F11A5BF-608A-49A2-978F-160A50E1B42F}		20070223130427
      {1F11A5BF-608A-49A2-978F-160A50E1B42F}		20070223130427
      {1F11A5BF-608A-49A2-978F-160A50E1B42F}		20070223130427
      {1F11A5BF-608A-49A2-978F-160A50E1B42F}		20070223130427
      {34A17A73-5EE1-4D21-8C59-AEFB684656D5}		20060523211235

      |   $nc++ unless defined $witnessSessions{$row[0]};
          $witnessSessions{$row[0]}{'AGENTTYPE'}=$row[1];  
          $witnessSessions{$row[0]}{'STARTTIME'}=$row[2];

          to build hash of hashes with first hash indexed by GUID and second hash
          indexed by agenttype of data:
$VAR1 = '{9B5E23D7-8C7E-4C3D-B7F3-62F83AF0C3C7}';
$VAR2 = {
          'AGENTTYPE' => 'NS',
          'STARTTIME' => '20060316222701'
        };
    return from archWitnessUtil::cacheWitnessSessions to the calling WITNESSPROD[or AD]::process()

    - call archBeaconUtil::cacheBeaconSessionProductInfo($witnessSessions{'earliest'}):  YET ANOTHER 1TIME CALL
      passing only 20040304184943 and using crc/crc@usprd53 sessionInfoDB handle:

      SQL Statement which produced this data:
      SELECT P.NAME, S.SESS_ID, W.WITNESS_GUID, to_char(S.START_TIME,'YYYYMMDDHH24MISS'), 
      C.FIRST_NAME, C.LAST_NAME, A.STATE, NC.CONTENT_ID 
      FROM   SESS S, SESS_REASONS R, SESS_WITNESS W, BD_PRODUCT P, CALLER C, ADDRESS A, BD_NODE N, 
      BD_NODE_CONTENT NC 
      WHERE  S.SESS_ID=R.SESS_ID 
      AND    S.SESS_ID=W.SESS_ID 
      AND    R.PROD_ID=P.PRODUCT_ID 
      AND    S.CALLER_ID=C.CALLER_ID 
      AND    S.CALLER_ID=A.CALLER_ID 
      AND    N.NODE_ID=R.NODE_ID 
      AND    P.NAME IS NOT NULL 
      AND    N.NODE_ID=NC.NODE_ID(+) 
      ORDER BY P.NAME, S.SESS_ID, NC.CONTENT_ID
            [0]          [1[    [2]     [3]           [4]        [5]      [6] [7]
      5-DAY DEODORANT	2964632	-99	20021003115549	ANONYMOUS	ANONYMOUS		6271
      5-DAY DEODORANT	2994864	{1F6E116F-E530-11D6-B1EA-0002A53F9408}	20021021161156	Jennifer	Ornedi	DC	6271
      5-DAY DEODORANT	3301473	{E6030F5E-7A87-11D7-B20B-0002A53F9408}	20030429173509	ANONYMOUS	ANONYMOUS		6271
      A-200	2924209	{EA170806-C4E4-11D6-B1E9-0002A53F9408}	20020910135139	Linda	Schwarz	NY	6265
      A-200	3179505	{92F686AC-404E-11D7-B206-0002A53F9408}	20030214140059	Becky	Bressette	VT	6265
      A-200	3246766	{7CDDF8E6-605C-11D7-B20A-0002A53F9408}	20030327091014	Halena	Lyons	NJ	6265
      A-200	3569248	{F15CC720-8C4F-4D92-AD83-41763A722530}	20031008103959	Laura	Hayes	MD	6265
      A-200	4130771	{3EEE1443-C401-42FE-872A-2DB104F58224}	20040929085725	David	Goodwill	PA	6265
      A-200	4528782	{A646A658-B064-4C10-868A-6F1C6ED9BB0C}	20050601114330	Gretchen	Burton	CA	6265
      A-200	4713513	{EDCAA52D-5D7B-4761-A661-B59D7121161E}	20050927101705	Patricia	Diehl	PA	6265
      A-200	5001498	{80F2B671-DA01-489E-84E3-D1F4D6FCA531}	20060317171720	ANONYMOUS	ANONYMOUS		6265
      A.R.M.	2740340	-99	20020516165636	David	Schnurvin	MD	6255
      A.R.M.	2754647	-99	20020524155003	Mr.	Fermo		6255
      A.R.M.	3246090	{5E95132C-5FCB-11D7-B20A-0002A53F9408}	20030326155123	Homaira	Zahir	CA	6255
      A.R.M.	3279316	{AAA43F82-6F80-11D7-B20A-0002A53F9408}	20030415163425	Jennifer	Porterfield	WV	6255
      A.R.M.	3316733	{98CDB239-8181-11D7-B20B-0002A53F9408}	20030508142724	Sargent	Williams	GA	6255
      A.R.M.	3472964	{D7AFE490-0AB9-4776-9AE1-D05325405256}	20030813100055	Anita	Camarillo	OR	6255
      A.R.M.	3569248	{F15CC720-8C4F-4D92-AD83-41763A722530}	20031008103959	Laura	Hayes	MD	6255
      A.R.M.	3954104	{EEB0C513-CCF8-41DE-A4D4-7D08D7B8CE4E}	20040604102547	Cindy	Schulze	WI	6255
      ABREVA	2595807	-99	20020226112425	Maxi	Pla		6799

      array of hash entries
    | $beaconSessions[$sp]{'PRODUCT'}=$row[0];
      $beaconSessions[$sp]{'SESSIONID'}=$row[1];
      $beaconSessions[$sp]{'GUID'}=$row[2];
      $beaconSessions[$sp]{'STARTTIME'}=$row[3];
      $beaconSessions[$sp]{'FIRSTNAME'}=$row[4];
      $beaconSessions[$sp]{'LASTNAME'}=$row[5];
      $beaconSessions[$sp]{'STATE'}=$row[6];
      $beaconSessions[$sp]{'CONTENTID'}=$row[7];
      $beaconSessions[$sp]{'COMMENTS'}=$row[8] if $includecomments;
      $beaconSessions[$sp]{'AE'}= ($beaconSessions[$sp]{'CONTENTID'}=~m/^($adverseEventList)$/) ? 'T' : 'F';
$VAR1 = {
          'PRODUCT' => 'ADVAIR',
          'SESSIONID' => '4177271',
          'GUID' => '{F61B296D-34EA-41A1-9DAE-8011E2C1266E}',
          'CONTENTID' => '14570',
          'LASTNAME' => 'Bradley',
          'STARTTIME' => '20041026145735',
          'FIRSTNAME' => 'Cynthia',
          'AE' => 'F',
          'STATE' => 'SC'
        };

    return from archBeaconUtil::cacheBeaconSessionProductInfo to 
    WITNESSPRODUCT::process()

    call archLogging::cacheLogTable($witnessSessions{'earliest'} aka $date 
    in cacheLogTable())
    use $logActivityDB (and %areaForReason after sql) to build
    SELECT Sess,Guid,Reason_Id,to_char(Match_Date,'YYYYMMDDHH24MISS')
    FROM   crc_arch_log
    WHERE contact_date > to_date('$date','YYYYMMDDHH24MISS')
     [0]   [1[   [2[          [3]
    SESS	GUID	REASON_ID	TO_CHAR(MATCH_DATE,'YYYYMMDDHH24MISS')
    5432037	{1BF1678E-E04D-47C9-B11B-0FE04C4968A0}	81	20070103010355
    5432774	{3A77601A-4872-46AC-A09E-626B098A7686}	81	20070103010432
    5433088	{9614A6D4-32DC-44EC-AC2C-7ABD0EC98215}	81	20070103010440
    5431641	{C02C7E49-8FBC-43C8-8DFA-42EF49B563D0}	111	20070103010454

    Build 4 hashes from sql to determine what's already been done (in prev
    day's runs??  status='ARCHIVE'??):
    $loggedsr{$row[0].$row[2]}=$row[3]; # K=Beacon Session.Reason V=date
$VAR1 = '5115854.39';
$VAR2 = '20060602030646';
$VAR3 = '4849300.111';
$VAR4 = '20051221010848';
    $loggedgr{$row[1].$row[2]}=$row[3]; # K=Guid.Reason V=date
$VAR1 = '{6D52DC5A-F2D6-408F-AB20-3D66C4275F77}.115';
$VAR2 = '20050328141723';
$VAR3 = '{94BD28D8-2750-410A-A4B2-0D3222CA0411}.29';
$VAR4 = '20060607011852';
    $loggedga{$row[1].$areaForReason{$row[3]}}=$row[2]; # K=Guid.(Group/Area) V=reason
$VAR1 = '{B98FA883-B471-4B21-924D-BB0161441E8F}.';
$VAR2 = '29';
$VAR3 = '{AC09D06D-A0CC-4C46-ABC3-7607EC042140}.';
$VAR4 = '36';
    $loggeds{$row[0]}=$row[3]; # K=Session V=date
$VAR1 = '3904003';
$VAR2 = '20040505011211';
$VAR3 = '4813592';
$VAR4 = '20051129011318';

    | %logg*
    return from archLogging::cacheLogTable to WITNESSPRODUCT::process()
    call WITNESSPRODUCT::IsLogged() with %logg hashes still in scope, loop over %beaconSessions
    ...if (isLogged(Session=>$beaconSessions[$bsp]{"SESSIONID"},Reason=>$reasonNo)) {...
    ...if ($why=isLogged(GUID=>$thisGUID,Area=>$areaForReason{$reasonNo})) {...
    to elim already loggeds, enqueue $beaconSessions[$bsp] if not (ie, it's new),
    do this for each:
      call archRequests::enqueue('Witness','beacon',$area,$group,$value,  $reasonNo,
                                 %{ $beaconSessions[$bsp] });
    refilling args -             $type,   $metaType,$area,$group,$product,$reason,%metaData
    each time                e.g.                   CEFUROXIMINE,Product,CEFTIN,

      | unshift args ultimately into @requests:
$VAR1 = {
          'group' => 'Product',
          'metatype' => 'beacon',
          'area' => 'CEFUROXIMINE',
          'reason' => '33',
          'type' => 'Witness',
          'product' => 'CEFTIN',
          'meta' => {
                      'PRODUCT' => 'CEFTIN',
                      'SESSIONID' => '5553055',
                      'GUID' => '{90C9A173-35CC-4E56-9F50-1A54CA7EED78}',
                      'CONTENTID' => '7127',
                      'LASTNAME' => 'Freidich',
                      'AE' => 'F',
                      'FIRSTNAME' => 'Larry',
                      'STARTTIME' => '20070313162714',
                      'STATE' => 'NY'
                    }
        };

****return from archLogging::cacheLogTable to WITNESSPRODUCT::process()****
    return to archReasons::process()
    return to Custody.pl
    | still have @requests in scope in archRequests.pm

4-archRequests::process() 
  sessions to archive are in @requests.  again use runtime magic 
    i.e. use $type to build "Witness".pm and call (ultimately parsed out of 
    @requests)-
    Witness::process($guid,$sessionid,$base,$group,$area) ultimately to pass
    back AVI's $duration, $fname and $fsize
     - Witness::process() calls  
       1-archWitnessUtil::convertSession($guid,"$base\\$group\\$area",$sessionid) 
         After using COM, convert a Witness session into AVI file and zip it
         mkdir $base\\$group\\$area
         | $converted{$guid}=$outfile
         return to Witness::process()
       2-archWitnessUtil::sessionFileName() 
         return to Witness::process()
       3-archWitnessUtil::sessionFileSize()
         return to Witness::process()
       return to Witness::process()
   return to archRequests::process()
   should have "Converted and stored sessions" like this:
   {Z9999E7D-98F3-45BF-AD37-5AC0E60237AD},599999,20070321101900,duration,Bar,Foo,Bar,NC,F,fsize,fname,99
 return to Custody.pl

exit Custody.pl

{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}

Lockup.pl ("Identify directories of contact data that exceed a configured
  threshold and generate requests to copy this data, up to that threshold, to
  the specified media")
  ---To debug and force lockup in harness/ use file logfile.txtUSETOFORCELOCKUP

- initializeprogram() get ini data.  simple.
- scanforthresholds() find files until max MB reached 
  
$VAR1 = 'COUNT';
$VAR2 = 2;
$VAR3 = 'DDProdMedB\\KYTRIL';
$VAR4 = 1;
$VAR5 = 'DDProdMedB\\ANCEF';
$VAR6 = 0;

  | %archive keys are counts or 'areas'
- processqueue() 
    - analyzeLogRecords($area eg DDProdMedB\ANCEF) find fields with 
      nonmissing values
    - generateHeaders()  for the mindex sorted breakout html
    - moveFilesAndGenerateIndices() Session,File,Date,Duration,Product,CallerFN,CallerLN,State,Adverse Event
      to \Lit_Hold
      buildhtmlfilefor() | %order
    - generateStandardFiles() copy ShelExec.exe etc to ...\files
    - generateOrder() orderfile.nwp, labeldata.txt | $area parsed
      - newMediaAssociation() update crc_arch_log db
      - copy TYKERB070620101512.nwp to \\us00011931\RIMAGE\Publisher Orders (old loc)
      - resetTextIndex("$sourceBase\\$area")
        - <$basedir\\logfile.txt
        - >>$basedir\\queuedlogfile.txt

exit Lockup.pl


{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}

Cleanup.pl ("Verify media creation, remove temporary files, and record
  information in database")
  ---To debug and force cleanup in harness/ to run, edit file orderfile.nwpHOLD

1- initializeprogram() get ini data, Pre define/prepare SQLs

2- identifyActive() sql to $logActivityDB crc_arch_media tbl on what media are
   currently "Active" | %{ $activeRecords }

3- scanTempDirs() list of discs/contents use orderfile.nwp, get orderid and/or
   volume  | $volumeForOrder{$orderid} $groupForOrder{$orderid} $areaForOrder{$orderid}

4- scanresultfiles() ck orderid status in rimage\Publisher Orders, build
   $remoteLoc\\nwplog.txt

5- analyseData() For complete orders, update database and rename order file,
   for in process or queued but not in process on the rimage box, update the
   database with status but do not do any other updating, For order requests
   that don't map to active records, provide notice but don't do anything else

exit Cleanup.pl

{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}





$ perl Custody.pl 
Normal 07/28/03 14:53:24 Program started
Normal 07/28/03 14:53:24 Established eQuality connection to us8n05.corpnet1.com:3021
Normal 07/28/03 14:53:24 Using compression level 1
Normal 07/28/03 14:53:24 Variable removeSource is not set.
Normal 07/28/03 14:53:26 Loading 48 AE nodes
Warning 07/28/03 14:53:26 Zip program D:\Progra~1\Winzip\Wzzip.exe does not exist
Warning 07/28/03 14:53:26 ZipSE program D:\Progra~1\Winzip\Wzzip.exe does not exist
Normal 07/28/03 14:53:26 Initialization complete
Normal 07/28/03 14:53:26 122 Reasons loaded
Normal 07/28/03 14:53:26 Caching Witness Sessions <---sub cacheWitnessSessions
Normal 07/28/03 14:53:44 8538 Witness sessions cached <---sub cacheWitnessSessions
Normal 07/28/03 14:53:44 Caching Beacon Sessions for products since 20040304184943
Normal 07/28/03 14:55:55 4394 Beacon sessions cached
Normal 07/28/03 14:55:55 Caching Logged records since 20040304184943
Normal 07/28/03 14:55:55 49 log records cached.
Normal 07/28/03 14:55:57 Converting and storing 2017 sessions
Normal 07/28/03 14:56:01 Program ended normally.

