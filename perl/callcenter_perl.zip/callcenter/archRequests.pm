###################################################################
#
#  archRequests.pm
#
#  Provide request queue functions/data
#
#  Always used as class, never instantiated
#
###################################################################

package archRequests;

use warnings;
use POSIX qw(strftime);
use Exporter ();
@ISA=qw(Exporter);

@EXPORT=qw();

use archActLogging;
use archLogging;

sub init{
#
# import base directory from main program
#
  ($base,$logdatefmt)=@_
}

sub enqueue{
#
# Put request into the queue unless already there
#
my($type,$metaType,$area,$group,$product,$reason,%metaData)=@_;
return if $queuedThisSession{"$reason.$type.$metaData{SESSIONID}"};
$queuedThisSession{"$reason.$type.$metaData{SESSIONID}"} = 1;
my(%request);
%request=(
'type'=>$type,
'metatype'=>$metaType,
'area'=>$area,
'group'=>$group,
'product'=>$product,
'reason'=>$reason
);
%{ $request{'meta'} }=%metaData;
unshift @requests,{ %request }; # use unshift/pop to keep order correct
}

sub dumpRequests{
my $i;
if ($_[0]) {
  open(DUMP,">$_[0]");
} else {
  open(DUMP,">&STDERR");
}
print DUMP "order source_type meta_source area group product reason# guid ae sessionid contentid\n";
for ($i=0;$i<=$#requests;$i++) {
  print DUMP "$i $requests[$i]{'type'} $requests[$i]{'metatype'} $requests[$i]{'area'} $requests[$i]{'group'} $requests[$i]{'product'} $requests[$i]{'reason'} $requests[$i]{'meta'}{'GUID'} $requests[$i]{'meta'}{'AE'} $requests[$i]{'meta'}{'SESSIONID'} $requests[$i]{'meta'}{'CONTENTID'}\n";
}
close(DUMP);
}

sub process{
#
# For each session, convert it and for each product, copy it to
# the destination location for that product.  After converted and
# stored successfully, update database to mark as complete/commit
#
  $reqcount=$#requests+1;
  if ($reqcount == 0) {
    actLog("Warning","No sessions identified for archiving");
    return;
  }
  actLog("Normal","Converting and storing $reqcount sessions");
  undef %processed;
  undef %converted;
  $cnt=0;
#
# Pop request pointers off of queue (which were inserted from other end giving
# a FIFO) and break request into consistuant parts
#
#
  while (defined($requestPtr=pop(@requests))) {
    %thisRequest=%{ $requestPtr };
    $cnt++;
    $reason=$thisRequest{'reason'};
    %meta=%{ $thisRequest{'meta'} };
    $guid=$meta{'GUID'};
#
# If this reason/guid have already been processed in this session, skip them
#
    next if $processed{"$reason.$guid"};
    $area=$thisRequest{'area'};
    $group=$thisRequest{'group'};
    $product=$thisRequest{'product'};
    $processed{"$reason.$guid"}=1;
    $type=$thisRequest{'type'};
    $sessionid=$meta{'SESSIONID'};
    $starttime=$meta{'STARTTIME'};
    $metaType=$thisRequest{'metatype'};
    if ($metaType eq "beacon") {
      $first_name=$meta{'FIRSTNAME'};
      $last_name=$meta{'LASTNAME'};
      $state=$meta{'STATE'};
      $ae=$meta{'AE'};
    } else {
      $first_name=$last_name=$state=$ae="";
    }
#
# Dynamically require the module unless it's already been loaded.  This
# technique allows this code to call "new" routines based on data in the
# database without changing this routine's code.  Of course, the modules will
# have to be coded and installed but no change will be required here.
#
    require $type.".pm" unless defined($typeloaded{$type}); # load at run-time
    $typeloaded{$type}=1;
    $subroutine="$type"."::process"; # Define name of subroutine so as not to call it when testing for existance
    if (exists &$subroutine ) {
      ($duration,$fname,$fsize)=$type->process($guid,$sessionid,$base,$group,$area);
       if ($duration ne "Error") {
         logMetaInfo($guid,$sessionid,$starttime,$duration,$product,$first_name,$last_name,$state,$ae,$fsize,$fname,$reason);
         addLogRecord($sessionid,$guid,$reason,$area,'QUEUED',$first_name,$last_name,$state,$starttime,$ae);
       }
    } else {
#
# If problem with required module, log it as an error and exit
#
     actLog("Error","Unable to process request for $type");
     exit;
    }

  }
}

sub logMetaInfo{
#
#  Add meta-information to log file in area directory; used package global for
# base and area value set in calliing subroutine -- maybe this should be passed?
#
  my($guid,$sessionid,$starttime,$duration,$product,$first_name,$last_name,$state,$ae,$fsize,$fname,$reason)=@_;
  $outlog="$base\\$group\\$area\\logfile.txt";
  $fname=~s/(.*)\\(.*)/$2/; # Remove all but last part of filename (path stuff)
  $now=strftime($logdatefmt,localtime(time));
#
# Open and close the log file to ensure that data if written to physical file
# immediatly.
#
  open(LOG,">>$outlog") || actLog("Error","Error logging to $outlog [$!]");
  print LOG "$now,$fname,$reason,$starttime,$duration,$product,$first_name,$last_name,$state,$ae,$fsize\n";
  close(LOG);
}

1;
