2007-10-23

phaseIII is the fix of 12/31/9999 create dates
