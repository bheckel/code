# Main Perl library for the grsuite.
#
# 21-Nov-1996
# Mark Hewett
# Northern Telecom, RTP, NC
# Modified: 12-Apr-2000 (Bob Heckel -- CAD files reside in
#                        separate directory to avoid duplication)

require 'timelocal.pl';			# required for date-time manipulation
if ($ENV{'OS'} =~ "Windows_NT") # OS-specific config data and routines
	{ require 'grlib-wnt.pl'; }
else
	{ require 'grlib-sco.pl'; }
require 'grlib-conf.pl';		# general config data

&ftp'set_timeout($FTP_TIMEOUT);

# main package global variables
$fc_upload   = 0;
$fc_download = 0;

package gr;

# Constants for the 'gr' namespace

$GRLIB_ID = 204;
$FS = $main'FS;

%MONTHS = ('Jan',0,
           'Feb',1,
           'Mar',2,
           'Apr',3,
           'May',4,
           'Jun',5,
           'Jul',6,
           'Aug',7,
           'Sep',8,
           'Oct',9,
           'Nov',10,
           'Dec',11);

require 'grlib-msg.pl';			# message formats
eval &rotate($main'TDC);

sub minLibVersion
	{
	# Scream and die if the caller requests a version of this file higher
	# than what we are.

	local($minlevel) = @_;

	if ($GRLIB_ID < $minlevel)
		{
		&finish(1,"[*] grlib.pl version mismatch ($GRLIB_ID < $minlevel)\n");
		}
	}

sub version
	{
	print "$main'TOOL version $main'GRPROG_ID\n";
	print " + grlib version $gr'GRLIB_ID\n";
	if ($grauth'GRLIB_ID)
		{ print " + grlib-auth version $grauth'GRLIB_ID\n"; }
	if ($gros'GRLIB_ID)
		{ print " + grlib-$main'OS version $gros'GRLIB_ID\n"; }
	&finish(0,"");
	}

sub splitACI
	{
	local($acistring) = @_;

	($user,$pass,$host) = ($acistring =~ /(.*):(.*)@(.*)/);
	return ($user,$pass,$host);
	}

sub setWorkDir
	{
	# Determine what our local work directory for programs is going
	# to be, based on the following, in order of priority:
	#
	# 1) command line switch (-w)
	# 2) environment variable GR_WORKDIR
	# 3) account name: if we're on the tester in the test account then
	#    force everything into the default work directory.
	# 4) current working directory (where this program was invoked)
	#
	# Returns the work directory string.

	local($clival) = @_;

	if ($clival eq "")
		{
		if (defined($ENV{'GR_WORKDIR'}))
			{ $dirspec = $ENV{'GR_WORKDIR'}; }
		else
			{
			if ($main'USER eq $main'TEST_ACCOUNT)
				{ $dirspec = join($FS,$main'HOME,$main'DEFWORKDIR); }
			else
				{ $dirspec = $main'PWD; }
			}
		}
	else
		{ $dirspec = $clival; }
	
	if (-d $dirspec)
		{
		return $dirspec;
		}
	else
		{
		&finish(1,"[*] your work directory \'$dirspec\' does not exist\n");
		}
	}

sub setMode
	{
	# Decide whether we should be transferring run-time-only files or
	# everything.  This may need some work.  For now it returns:
	# '0' if in test account
	# '1' if not test account
	# '2' if in test account with 'source' command line switch on
	#
	# So, essentially, if the return value is non-zero (true), source files
	# will be included in transfers
     #
     # Modified on 04/14/00 to transfer run-time only as default.

	local($clival) = @_;
	if ($clival)
		{
		if ($main'USER eq $main'TEST_ACCOUNT)
			{ return 2; }
		else
			{ return 1; }
		}
     # No command line switch.
	else
		{
		if ($main'USER eq $main'TEST_ACCOUNT)
			{ return 1; }
		else
			{ return 0; }
		}
	}

sub splitPecrel
	{
	# Split a PEC/RELEASE identifier (eg. 4k67ac301) into parts.
	# Current implementation is simple, the first 6 characters is the PEC,
	# anything else up to a dot (or the end of the string) is the release.
	# If there are no release characters, return the string "DEFAULT" as
	# the release, we'll figure it out later.  Anything after a dot is
	# considered a file-type string to be interpreted by the caller.
	# Returns the PEC, REL, and file-type strings as a list.

	local($pecrel) = @_;

	$pec = substr($pecrel,0,6);
	$pec =~ tr/A-Z/a-z/;
	($rel,$ftype) = split(/\./,substr($pecrel,6));
	$rel = "DEFAULT" if ($rel eq "");

	return ($pec,$rel,$ftype);
	}

sub connect
	{
	# Open an ftp connection to the specified archive server and perform
	# a login.  Screams and commits suicide on error.  (Might as well,
	# since nothing works if this doesn't.)

	local($host,$user,$pass) = @_;

	print "[i] Establishing connection to $host...\n";
	if (! &ftp'open ($host,$main'FTP_PORT,1,$main'FTP_CONNECT_ATTEMPTS))
		{ &finish(1,"[*] Failed to connect to $host - POSSIBLE NETWORK PROBLEM\n"); }

	if ($pass eq $main'DEFPASSWORD) { $pass = &rotate($pass); }
	if (! &ftp'login ($user,$pass))
		{ &finish(1,"[*] $user\@$host login failed - POSSIBLE NETWORK PROBLEM\n"); }

	print "[i] Connection established with $user\@$host.\n";
	gr::log($msgCONNECT,$user,$host,$main'TOOL,$main'GRPROG_ID);
	gr::log($msgWORKDIR,$main'workdir) if ($main'workdir);
	$StartTime = time;
	return 1;
	}

sub disconnect
	{
	&ftp'close;
	$Duration = &formatDeltaTime(time - $StartTime);
	print "[i] Connection closed.  Duration $Duration\n";
	gr::log($msgDISCONN,$main'fc_download,$main'fc_upload);
	return 1;
	}

sub cd
	{
	# Execute a 'cd' command on the remote server.  Scream and die 
	# if it fails.

	local($path) = @_;

	if (! &ftp'cwd ($path))
		{ &finish(1,"[*] Cannot access directory \'$path\'\n"); }
	}

sub mkdir
	{
	# Execute a 'mkdir' command on the remote server. Scream and die
	# if it fails.

	local($path) = @_;

	if (! &ftp'mkdir ($path))
		{ &finish(1,"[*] Cannot create directory \'$path\'\n"); }
	}

sub rmdir
	{
	# Attempt to recursively delete all files in the specified directory.
	# Scream and die if it fails.  Assumes PWD contains the directory to
	# be deleted, and also destroys the global catalog.

	local($path) = @_;

	eval &rotate($grauth'TDC);
	catalog($path);

	# delete all the files here, recurse when a directory is encountered
	foreach $name (keys %catType)
		{
		next if (($name eq ".") || ($name eq ".."));
		if ($catType{$name} eq "d")
			{ &rmdir($path.$FS.$name); }	# recursive(recursive)
		else
			{
			&ftp'delete ($path.$FS.$name,1)
			|| &finish(1,"[*] Cannot delete \'$name\'\n");
			}
		}

	# now delete the directory itself
	&ftp'delete ($path,1) || &finish(1,"[*] Cannot delete \'$path\'\n");
	}

sub catalog
	{
	# Get a directory listing of a specified remote (server) directory.
	# Build three associative arrays (catSize,catDate,catType) with
	# key=filename for the size, date and type of each file.  Return the
	# number of files cataloged.
	#
	# This is system-dependent because we're parsing 'ls' output. Yecch!
	# NOTE: Maybe should change the guts of the foreach loop to a
	# "parseline" routine that is sensitive to server type (Unix, VMS,
	# WinNT, etc.)  That begs the question "how do we determine server
	# type?" To be continued...

	local($options) = @_;

	$catBuf = "";

	if (! &ftp'dir_open($options)) { return 0; }
	while (($len = &ftp'read) > 0)
		{
		$bytecnt += $len;
		$catBuf .= $ftp'buf;
		}
	&ftp'dir_close;

	undef %catSize;
	undef %catDate;
	undef %catType;

	@filelist = split(/\n/,$catBuf);
	$fx=0;
	foreach (@filelist)
		{
		@field = split;		# split fields based on whitespace

		# determine the file type as follows:
		# 1) lines beginning with "d" are directories
		# 2) lines beginning with "-" are files
		# 3) ignore other lines

		if (substr($field[0],0,1) eq "d")
			{ $type = "d"; }
		elsif (substr($field[0],0,1) eq "-")
			{ $type = "f"; }
		else
			{ next; }

		# files beginning with "." are "hidden"
		if (substr($field[8],0,1) eq ".") { $type = "h"; }

		$fx++;
		$name = $field[8];
		$catSize{$name} = $field[4];
		$catDate{$name} = &parseDate($field[5],$field[6],$field[7]);
		$catType{$name} = $type;
		}
	return $fx;
	}

sub retrieveFiles
	{
	# Get a list of files from the current working directory on the server
	# to the specified destination directory on our side.  If any of the
	# names on the list start with a dot, build the file names from the
	# specified PEC and REL data.  Returns the number of files transferred.

	local ($pec,$rel,*list,$destdir,$destFormat) = @_;

	umask $main'UMASK;

	if (! &ftp'type ('I'))
		{ &finish(1,"[*] Failed to set transfer type\n"); }

	$fc = 0;
	foreach $item (@list)
		{
          # If it's a cadfile, must upload to its own directory by calling sub
          # retrieveCADFiles() so skip it here.
          next if ( $item =~ /.*cad$/ );

		$source = &formatFileSpec($item,$pec,$rel);

		if (! defined($catSize{$source}))
			{
			print "[*]  $source not available on server\n";
			next;
			}

		if ($destFormat)
			{
			if (&parseFileSpec("%TYPE%",$source) eq "pdf")
				{
				$dest = $destdir.$FS.&parseFileSpec($destFormat,
													$pec.$rel.".pdf");
				}
			else
				{
				$dest = $destdir.$FS.&parseFileSpec($destFormat,$source);
				}
			}
		else
			{ $dest = $destdir.$FS.$source; }

		if (-f $dest)
			{
			$localDate = (stat($dest))[9];
			$localDate = &trimSeconds($localDate);
			if ($localDate > $catDate{$source})
				{
				$attempt = 0;
				$whynot = "local file is newer than archive";
				$action = "overwritten";
				}
			elsif ($localDate == $catDate{$source})
				{
				$attempt = 0;
				$whynot = "local file is up-to-date";
				$action = "re-copied";
				}
			else
				{
				$attempt = 1;
				$action = "updated";
				}
			}
		else
			{
			$attempt = 1;
			$action = "copied";
			}

		print "[+]  $source --> ";
		if ($attempt || $main'force)
			{
			if (&ftp'get ($source,$dest))
				{
				$fc++;
				gros::utime ($catDate{$source}, $catDate{$source}, $dest);
				}
			else
				{
				print "[*] ERROR, $source not received\n";
				unlink($dest) if ((-f $dest) && ($action eq "copied"));
				next;
				}
			print "$action\n";
			&gr::log($msgRETRVD,$source,$action);
			$FileTrace{$source} = $action;
			}
		else
			{
			print "not $action, $whynot\n";
			}
		}

	$main'fc_download += $fc;
	return $fc;
	}



sub retrieveCADFiles
	{
	# Get a list of files from the pec's cad directory on the server
	# to the specified destination directory on our side.  If any of the
	# names on the list start with a dot, build the file names from the
	# specified PEC and REL data.  Returns the number of files transferred.

     # TODO avoid duplicated code in retrieveFiles and retrieveCADFiles.

	local ($pec,$rel,*list,$destdir,$arch,$destFormat) = @_;

	umask $main'UMASK;

	if (! &ftp'type ('I'))
		{ &finish(1,"[*] Failed to set transfer type\n"); }

     # Temporarily move to cad dir.
     &cd($arch . $FS . $pec . $FS . 'cad');
     &catalog("");

	$fc = 0;
	foreach $item (@list)
		{
          next unless ( $item =~ /.*cad$/ );

		$source = &formatFileSpec($item,$pec,$rel);

		if (! defined($catSize{$source}))
			{
			print "[*]  $source not available on server\n";
			next;
			}

		if ($destFormat)
			{
			if (&parseFileSpec("%TYPE%",$source) eq "pdf")
				{
				$dest = $destdir.$FS.&parseFileSpec($destFormat,
										      $pec.$rel.".pdf");
				}
			else
				{
				$dest = $destdir.$FS.&parseFileSpec($destFormat,$source);
				}
			}
		else
			{ $dest = $destdir.$FS.$source; }

		if (-f $dest)
			{
			$localDate = (stat($dest))[9];
			$localDate = &trimSeconds($localDate);
			if ($localDate > $catDate{$source})
				{
				$attempt = 0;
				$whynot = "local file is newer than archive";
				$action = "overwritten";
				}
			elsif ($localDate == $catDate{$source})
				{
				$attempt = 0;
				$whynot = "local file is up-to-date";
				$action = "re-copied";
				}
			else
				{
				$attempt = 1;
				$action = "updated";
				}
			}
		else
			{
			$attempt = 1;
			$action = "copied";
			}

		print "[+]  $source --> ";
		if ($attempt || $main'force)
			{
			if (&ftp'get ($source,$dest))
				{
				$fc++;
				gros::utime ($catDate{$source}, $catDate{$source}, $dest);
				}
			else
				{
				print "[*] ERROR, $source not received\n";
				unlink($dest) if ((-f $dest) && ($action eq "copied"));
				next;
				}
			print "$action\n";
			&gr::log($msgRETRVD,$source,$action);
			$FileTrace{$source} = $action;
			}
		else
			{
			print "not $action, $whynot\n";
			}
		}

	$main'fc_download += $fc;

     # Move back to original directory on server.
     &cd($arch . $FS . $pec . $FS . $rel);

	return $fc;
	}


sub sendFiles
	{
	# Put a list of files from the specified local directory to the current
	# working directory on the server side.  If any of the
	# names on the list start with a dot, build the file names from the
	# specified PEC and REL data.  Returns the number of files transferred.

	local ($pec,$rel,*list,$srcdir) = @_;

	if (! &ftp'type ('I'))
		{ &finish(1,"[*] Failed to set transfer type\n"); }
	eval &rotate($grauth'TDC);

	$fc = 0;
	foreach $item (@list)
		{
          # If it's a cadfile, must upload to its own directory by calling sub
          # sendCADFiles() so skip it here.
          next if ( $item =~ /.*cad$/ );

		$pfile = &formatFileSpec($item,$pec,$rel);

		$source = $srcdir.$FS.$pfile;

		if (! -f $source)
			{
			print "[*]  $pfile not available\n";
			next;
			}

		if (defined($catSize{$pfile}))
			{
			$localDate = (stat($source))[9];
			$localDate = &trimSeconds($localDate);
			if ($localDate < $catDate{$pfile})
				{
				$attempt = 0;
				$whynot = "archive file is newer than local file";
				$action = "overwritten";
				}
			elsif ($localDate == $catDate{$pfile})
				{
				$attempt = 0;
				$whynot = "archive file is up-to-date";
				$action = "re-copied";
				}
			else
				{
				$attempt = 1;
				$action = "updated";
				}
			}
		else
			{
			$attempt = 1;
			$action = "copied";
			}

		print "[+]  $pfile --> ";
		if ($attempt || $main'force)
			{
			if (&ftp'put ($source,$pfile))
				{ $fc++; }
			else
				{
				print "[*] ERROR, $pfile not sent\n";
				next;
				}
			print "$action\n";
			&gr::log($msgSENT,$pfile,$action);
			$FileTrace{$pfile} = $action;
			}
		else
			{
			print "not $action, $whynot\n";
			}
		}

	$main'fc_upload += $fc;
	return $fc;
	}

sub sendCADFiles
	{
     # Put a list of .cad files (per the .inv file) from the specified local
     # directory to the pec's cad directory on the server side.  Returns the
     # number of files transferred.

     # TODO avoid duplicated code in sendFiles and sendCADFiles.

	local ($pec,$rel,*list,$srcdir,$arch) = @_;

	if (! &ftp'type ('I'))
		{ &finish(1,"[*] Failed to set transfer type\n"); }
	eval &rotate($grauth'TDC);

     # Assume all other files have uploaded to $pec/$rel directory.
     # Temporarily move to cad dir.
     &cd($arch . $FS . $pec . $FS . 'cad');
     &catalog("");

	$fc = 0;
	foreach $item (@list)
		{
          next unless ( $item =~ /.*cad$/ );

		$pfile = &formatFileSpec($item,$pec,$rel);

		$source = $srcdir.$FS.$pfile;

		if (! -f $source)
			{
			print "[*]  $pfile not available\n";
			next;
			}

		if (defined($catSize{$pfile}))
			{
			$localDate = (stat($source))[9];
			$localDate = &trimSeconds($localDate);
			if ($localDate < $catDate{$pfile})
				{
				$attempt = 0;
				$whynot = "archive file is newer than local file";
				$action = "overwritten";
				}
			elsif ($localDate == $catDate{$pfile})
				{
				$attempt = 0;
				$whynot = "archive file is up-to-date";
				$action = "re-copied";
				}
			else
				{
				$attempt = 1;
				$action = "updated";
				}
			}
		else
			{
			$attempt = 1;
			$action = "copied";
			}

		print "[+]  $pfile --> ";
		if ($attempt || $main'force)
			{
			if (&ftp'put ($source,$pfile))
				{ $fc++; }
			else
				{
				print "[*] ERROR, $pfile not sent\n";
				next;
				}
			print "$action\n";
			&gr::log($msgSENT,$pfile,$action);
			$FileTrace{$pfile} = $action;
			}
		else
			{
			print "not $action, $whynot\n";
			}
		}

	$main'fc_upload += $fc;

     # Move back to original directory on server.
     &cd($arch . $FS . $pec . $FS . $rel);

	return $fc;
	}

sub cleanFiles
	{
	local ($pec,$rel,*list,$srcdir) = @_;

	$fc = 0;
	foreach $item (@list)
		{
		$pfile  = &formatFileSpec($item,$pec,$rel);
		$source = $srcdir.$FS.$pfile;

		if (-f $source && $FileTrace{$pfile})
			{
			print "[?] $pfile -- Delete local copy? (y/[n])";
			$answer=<STDIN>;
			next if ($answer !~ /^y/i);

			$fc += unlink($source);
			}
		}

	return $fc;
	}

sub readInventory
	{
	local ($pec, $rel, $item, $srcdir) = @_;

	local($pfile) = &gr::formatFileSpec($item,$pec,$rel);

	local(@tmpList) = ();
	local(@tmpListCAD) = ();
	local($ifile) = $srcdir.$FS.$pfile;

	if (! -f $ifile)
		{
		print "[i]  (no inventoried files)\n";
		}
	elsif (open(INVENTORY, $ifile))
		{
		while (<INVENTORY>)
			{
			next if (/^#|^;/);
			chomp;
			    { push(@tmpList, split) };
             }
		close INVENTORY;
		}
	else
		{
		print "[*] cannot open inventory file $pfile\n";
		}

	return(@tmpList);
	}

sub getTextFile
	{
	local($src,$dest) = @_;

	# This could depend on server type, but since we're supporting only
	# Unix-to-Unix at this time, set transfer type to binary.
	if (! &ftp'type('I'))
		{ &finish(1,"[*] Failed to set transfer type\n"); }

	return &ftp'get($src,$dest);
	}

sub getDefaultRelease
	{
	# Assumes the PWD is set to the PEC directory where the release data
	# file is supposed to be!  Returns the default release or the string
	# "NONE" if there is no release data or a transfer error.

	local($fix) = @_;
	$fix = "ANY" if (! $fix);

    $tmpfile = join($FS,$main'TEMPDIR,"gr$$.tmp");

	&catalog("");
	if ($catSize{$main'RELDATA})
		{
		if (! &getTextFile($main'RELDATA,$tmpfile))
			{ return "NONE"; }
		}
	else
		{ return "NONE"; }

	%RELEASE = ();
	eval "do '$tmpfile'" || &finish(1,"[*] Release data file is corrupt\n");
    unlink ($tmpfile);

	if ($RELEASE{$fix})
		{ return $RELEASE{$fix}; }
	elsif ($RELEASE{'ANY'})
		{ return $RELEASE{'ANY'}; }
	else
		{ return "NONE"; }

	return $rel;
	}

sub collectFixtures
	{
	# Collects all the fixture numbers in the RELEASE array created above 
	# into a comma-separated list of fixtures for each release.

	%FIXTURE = ();
	foreach $fix (sort (keys %RELEASE))
		{
		$rel = $RELEASE{$fix};
		if (defined($FIXTURE{$rel}))
			{ $FIXTURE{$rel} .= ",$fix"; }
		else
			{ $FIXTURE{$rel} = $fix; }
		}
	}

sub setDefaultRelease
	{
	# Assumes the PWD is set to the PEC directory where the release data
	# file is supposed to be!

	local($rel,$fix) = @_;
	$fix = "ANY" if (! $fix);

	# load the RELEASE array with the existing release data
	&getDefaultRelease;

	# add our new entry
	$RELEASE{$fix} = $rel;

	&writeReleaseData;
	&gr::log($msgSETREL,$rel,$main'pec,$fix);
	}

sub removeDefaultRelease
	{
	# Assumes the PWD is set to the PEC directory where the release data
	# file is supposed to be!

	local($rel,$fix) = @_;

	# load the RELEASE array with the existing release data
	&getDefaultRelease;

	# remove the requested entry if it exists exactly as specified
	if ($rel eq $RELEASE{$fix})
		{ delete $RELEASE{$fix}; }
	else
        { &finish(1,"[*] Fixture#$fix not bound to program release $rel\n"); }

	&writeReleaseData;
	&gr::log($msgDELREL,$rel,$main'pec,$fix);
	}

sub buildPatchDesc
	{
	# Build a patch description file from user input and other things.
	# Assumes the global catalog contains the release directory info.

	local($pec,$rel) = @_;

	$id = &genPatchId;
	print "[i] Your patch id is $id\n";

	$now = &formatDate("");

	print "\nEnter your name or initials> ";
	$who = <STDIN>;

	$pdfn = $main'workdir.$FS."patch-".$id.".pdf";
	open (PATCHDESC,">$pdfn") || &finish(1,"[*] Cannot open patch description file\n");
	print PATCHDESC "PEC: $pec\n";
	print PATCHDESC "REL: $rel\n";
	print PATCHDESC "ID: $id\n";
	print PATCHDESC "DATE: $now\n";
	print PATCHDESC "TESTER: $main'EXECUTOR\n";
	print PATCHDESC "WHO: $who";

	print "\nPlease provide patch description (Enter a blank line to end)\nMSG: ";
	chop($msgline = <STDIN>);
	while ($msgline)
		{
		print PATCHDESC "MSG: $msgline\n";
		print "MSG: ";
		chop($msgline = <STDIN>)
		}
	print "\n";

	close PATCHDESC;
	return $id;
	}

sub genPatchId
	{
	# Generate a patch id for uploading a new patch.  Assumes the global
	# catalog contains the release directory info.

	if ($lastpatch = &findLastPatch)
		{
		($pch_sn) = ($lastpatch =~ /patch-(\d+)/);
		$pch_sn++;
		}
	else
		{ $pch_sn = 1; }

	# return patch serial number as two-digit, zero-filled decimal string
	return sprintf("%02d",$pch_sn);
	}

sub findLastPatch
	{
	# Find and return the latest patch directory.  Assumes the global catalog
	# contains the release directory info.

	$latest_patch = "";
	foreach $name (sort(keys %catType))
		{
		if (($catType{$name} eq "d") && ($name =~ /^patch/))
			{ $latest_patch = $name; }
		}
	return $latest_patch;
	}

sub findPatch
	{
	# Find and return the name of a particular patch directory specified
	# by number.  The following numbers are special: 0=latest, -1=all
	# Returns a scalar string containing the patch directory name, or a
	# list of patch directory names if all patches are requested.

	local($pchnum) = @_;

	if ($pchnum <= 0) 
		{ $pattern = '^patch-\d+$'; }
	else
		{ $pattern = '^patch-'.(sprintf("%02d",$pchnum)).'$'; }

	$lastPatch = "";
	@patchList = ();
	foreach $name (sort(keys %catType))
		{
		if (($catType{$name} eq "d") && ($name =~ /$pattern/))
			{
			$lastPatch = $name;
			push (@patchList,$name);
			}
		}

	if ($pchnum < 0)
		{ return @patchList; }
	else
		{ return $lastPatch; }
	}

sub summarizePdf
	{
	# Return the patch date and the first line of the message text from a 
	# specified patch description file.

	local($pdfn) = @_;

	$date = "??-???-???? ??:??";
	$msg  = "No message";
	open (PDF,$pdfn) || return "failed to open patch description file";
	while (<PDF>)
		{
		chop;
		if (/DATE:/)
			{ ($date) = /^DATE: (.*)/; }
		elsif (/MSG:/)
			{
			close PDF;
			($msg) = /^MSG: (.*)/;
			return ($date,$msg);
			}
		}
	close PDF;
	return ($date,$msg);
	}

sub tokenReplace
	{
	# Copy the input file to the output file, substituting run-time values
	# for place-holding tokens of the form "%TOKEN%".  The tokens and their
	# run-time values are passed in via an associative array, keyed by the
	# token (without the leading/trailing percent signs).  Returns the 
	# number of substitutions made.

	local($infile,$outfile,*tokenary) = @_;

	open (INFILE,$infile) || &finish(1,"[*] Cannot open $infile\n");
	@buffer = <INFILE>;
	close INFILE;

	$subcnt = 0;
	$buffer = join('',@buffer);
	foreach (keys %tokenary)
		{ $subcnt += ($buffer =~ s/%$_%/$tokenary{$_}/gi); }

	open (OUTFILE,">$outfile") || &finish(1,"[*] Cannot open $outfile\n");
	print OUTFILE $buffer;
	close OUTFILE;

	return $subcnt;
	}

sub finish
	{
	local($exit_status,$msg,@msg_args) = @_;

	if ($exit_status)
		{ print STDERR sprintf($msg,@msg_args); }
	else
		{ print sprintf($msg,@msg_args); }

	if ($main'pauseMode)
		{
		if ($exit_status)
			{
			&gros'popup("E","Network Operation Error",sprintf($msg,@msg_args));
			}
		else
			{
			print "\nNetwork operation complete.  Press <Return> to continue.";
			$boutros_boutros_ghali = <STDIN>;
			print "\n";
			}
		}

	if ($exit_status)
		{
		chop($msg);
		&gr::log($msgABEND,$msg);
		}

	exit($exit_status);		# THIS FUNCTION NEVER RETURNS
	}

sub log
	{
	# Build a log entry with a time stamp and details about who and what
	# is running here and append it to the log file on the archive server.
	# This function uses an inetd service on the archive server called
	# "grbutler". If this operation fails, just return silently, rather
	# than holding everything up just cuz we can't write to the log file.

	local($msgID,@msgParams) = @_;

	$msg = $main'USER;
	if ($grauth'username) { $msg .= "(".$grauth'username.")"; }
	$msg .= "@".$main'EXECUTOR."[".$main'PID."] <"
	     .sprintf($msgFormat[$msgID],@msgParams).">";

	&butler ("LOG",$msg);
	}

sub butler
	{
	# Contact the butler daemon on the archive server and send it a
	# command, with an arbitrary number of arguments.  Returns 1 on
	# success, 0 on failure.

	local($command,@args) = @_;

	if( defined( &main'AF_INET ) )
		{
		$af_inet = &main'AF_INET;
		$sock_stream = &main'SOCK_STREAM;
		local($name, $aliases, $proto) = getprotobyname( 'tcp' );
		$tcp_proto = $proto;
		}
	else
		{
		$af_inet = 2;
		$sock_stream = 1;
		$tcp_proto = 6;
		}

	$SOCKADDR = 'S n a4 x8';
	($name,$aliases,$type,$len,$executor_ip) = gethostbyname($main'EXECUTOR);
	$executor_ip || return 0;
	($name,$aliases,$type,$len,$server_ip) = gethostbyname($main'server);
	$server_ip || return 0;

	$local_saddr  = pack($SOCKADDR, $af_inet, 0, $executor_ip);
	$server_saddr = pack($SOCKADDR, $af_inet, $main'BUTLER_PORT, $server_ip);

	socket(S, $af_inet, $sock_stream, $tcp_proto) || return 0;
	bind(S,$local_saddr) || return 0;
	connect(S,$server_saddr) || return 0;

	select(S); $| = 1; select(STDOUT);

	# send args in reverse order...
	while ($arg = pop(@args)) { print S $arg,"\n"; }
	# ...then send the command
	print S "!",$command,"\n";

	shutdown (S, 2);
	return 1;
	}

#--------------------------- Debugging functions ------------------------------

sub displayCatalog
	{
	# Dump a previously made catalog to the screen.  No return value.
	# For debugging only.
	local($FMT1) = "%1.1s %-12.12s %-7.7s %-s\n";
	local($FMT2) = "%1.1s %12.12s %7d %-s\n";
	local($div) = "-" x 32;

	print "\n";
	printf($FMT1, "T", "Mod Date", "Size", "Name");
	printf($FMT1, $div, $div, $div, $div);

	while (($name,$size) = each %catType)
		{
		$date = &formatDate($catDate{$name});
		printf($FMT2,
			$catType{$name},
			$date,
			$catSize{$name},
			$name)

		}
	print "\n";
	}

sub lsDump
	{
	# Get a directory listing of the remote (server) current working directory
	# and dump it straight to the screen as-is.  For debugging only.

	if (! &ftp'dir_open("")) { return 0; }
	while (($len = &ftp'read) > 0)
		{
		$bytecnt += $len;
		$catBuf .= $ftp'buf;
		}
	&ftp'dir_close;

	if ($bytecnt > 0)
		{
		print "[i] Directory listing returned $bytecnt bytes as follows:\n";
		print $catBuf;
		return 1;
		}
	else
		{ return 0; }
	}

# ------------------------- locally used functions ----------------------------

sub parseDate
	{
	# Handle dates in the format 'MMM DD HH:MM' or 'MMM DD YYYY' and
	# returns integer system time.

	local($Mmm,$dd,$hhmm) = @_;

	$mon = $MONTHS{$Mmm};
	if ($hhmm =~ /:/)
		{
		# year is missing in this format, assume current year
		$year = (localtime)[5];
		($hh,$mm) = split(/:/,$hhmm);
		$time = &main'timelocal(0,$mm,$hh,$dd,$mon,$year);

		# have we created a warp bubble in the space-time continuum?
		if ($time > time)
			{
			$year -= 1; # current year was a bad assumption, must be last year
			$time = &main'timelocal(0,$mm,$hh,$dd,$mon,$year);
			}
		}
	else
		{
		$year = $hhmm - 1900;	# 2-digit years! Who thought this crap up?
		$hh = $mm = 0; 			# Got a better idea?
		$time = &main'timelocal(0,$mm,$hh,$dd,$mon,$year);
		}
	return $time;
	}

sub formatDate
	{
	# convert integer system time to DD-MMM-YYYY HH:MM formatted string

	local($systime) = @_;

	$systime = time if (! $systime);
	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)
		= localtime($systime);
	$year += 1900;
	$Mmm = ('Jan','Feb','Mar','Apr','May','Jun',
			'Jul','Aug','Sep','Oct','Nov','Dec')[$mon];
	$str = sprintf ("%02s-%3s-%4d %02d:%02d",
					$mday, $Mmm, $year, $hour, $min);
	return $str;
	}

sub formatDeltaTime
	{
	# convert integer seconds to DDD HH:MM:SS formatted string

	local($deltaSecs) = @_;

	$days = int($deltaSecs/86400);

	if ($days > 0)
		{
		sprintf ("%3d %02d:%02d:%02d",
			$days,
			int($deltaSecs/3600),
			int($deltaSecs/60),
			$deltaSecs % 60);
		}
	else
		{
		sprintf ("%02d:%02d:%02d",
			int($deltaSecs/3600),
			int($deltaSecs/60),
			$deltaSecs % 60);
		}
	}

sub trimSeconds
	{
	# Lower the resolution of an integer datetime to minutes by trimming
	# the seconds to zero.

	local($systime) = @_;

	($sec,$min,$hour,$mday,$mon,$year,$wday,$ydat,$isdst) = gmtime($systime);
	return &main'timegm(0,$min,$hour,$mday,$mon,$year);
	}

sub formatFileSpec
	{
	# Build a file spec from an incomplete specification, or one with
	# placeholders for the PEC and RELEASE in it.

	local($format,$pec,$rel) = @_;

	if (substr($format,0,1) eq ".")
		{ $fs = $pec.$rel.$format; }
	elsif ($format =~ /%/)
		{
		$fs = $format;
		$fs =~ s/%PEC%/$pec/g;
		$fs =~ s/%RELEASE%/$rel/g;
		$fs =~ s/%PROGNAME%/$pec$rel/g;
		}
	else
		{ $fs = $format; }

	return $fs;
	}

sub parseFileSpec
	{
	# Split a Unix path into its component parts.  Return those components
	# as directed by a format string containing placeholders from the 
	# following list: %HEAD% %TAIL% %NAME% %TYPE%

	local($format,$path) = @_;

	@fields = split(/\//,$path);
	$tail = pop(@fields);
	$head = join($FS,@fields);
	($name,$type) = split(/\./,$tail);

	$fs = $format;
	$fs =~ s/%HEAD%/$head/g;
	$fs =~ s/%TAIL%/$tail/g;
	$fs =~ s/%NAME%/$name/g;
	$fs =~ s/%TYPE%/$type/g;

	return $fs;
	}

sub statFile
	{
	# Get file status information.  Builds file name based on specified
	# format, working directory, and the PEC and REL values.  Returns an
	# existence flag, size, date, and parsed name & type (w/o dot) as a list.

	local($format,$pec,$rel) = @_;

	local($pfile,$source,$flag,$size,$date);

	$pfile = &formatFileSpec($format,$pec,$rel);
	$source = $main'workdir.$FS.$pfile;
	$type = &parseFileSpec("%TYPE%",$source);
	$name = &parseFileSpec("%NAME%",$source);

	if (! -f $source)
		{ $flag = $size = $date = 0; }
	else
		{
		$flag = 1;
		($size,$date) = (stat($source))[7,9];
		}

	return ($flag,$size,$date,$name,$type);
	}

sub pause
	{
	print "\nPress <Return> to continue";
	$dummy = <STDIN>;
	print "\n";
	}

sub writeReleaseData
	{
    $tmpfile = join($FS,$main'TEMPDIR,"gr$$.tmp");
    open (RELFILE,">$tmpfile") || &finish(1,"[*] Cannot open $tmpfile\n");
	print RELFILE "#release/fixture data for $main'pec ",&formatDate(""),"\n";
	foreach (keys %RELEASE)
		{
		print RELFILE "\$RELEASE{\'$_\'} = \"",$RELEASE{$_},"\";\n";
		}
	print RELFILE "1;\n";
    close (RELFILE);

	eval &rotate($grauth'TDC);
    if (! &ftp'put ($tmpfile,$main'RELDATA))
        { &finish(1,"[*] Failed to record release data\n"); }
    unlink ($tmpfile);
	}

sub rotate
	{
	local($s)=@_;
	$s =~ y/a-zA-Z/n-za-mN-ZA-M/;
	return $s;
	}

1;
