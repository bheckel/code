# OS-specific Perl library for the grsuite.
#
# Windoze NT4.0 version
#
# 06-Feb-1997
# Mark Hewett
# Northern Telecom, RTP, NC

use Win32;

# This lib should be required in 'main' namespace BEFORE the
# configuration library is required.

# client-side config data
$OS              = "WNT";
$FS              = "/";
if (-d "C:/projects/grsuite")
	{ $EXEC_PATH = "C:\\\\PROJECTS\\\\GRSUITE"; }
else
	{ $EXEC_PATH = "C:\\\\LOCAL\\\\BIN"; }
$TEMPDIR         = "C:/TEMP";
$TEST_ACCOUNT    = "gr228x";
$MAINT_ACCOUNT   = "maint";
$UMASK           = 022;
$DEFWORKDIR      = "boards";

# dynamic local info
$USER = Win32::LoginName;
$PWD  = Win32::GetCwd;
$HOME = $ENV{'HOMEDRIVE'}.$ENV{'HOMEPATH'};
$PID  = $$;
$TOOL = &gr'parseFileSpec("%NAME%",$0);
$EXECUTOR = Win32::NodeName;

# Decide whether critical messages will need a pause or not.  
$pauseMode = ($ENV{'MONEXE'} =~ /mon.exe/) ? 1 : 0;

# Decide whether to use GUI popup messages for pauses.
# This is probably a moot point in Windoze, because the desktop display is 
# apparently always available to every app running here (unlike X displays).
$popupMessagesEnabled = 1;

package gros;

# Constants for the 'gros' namespace

$GRLIB_ID = 104;
$FS = $main'FS;

sub gros'minLibVersion
	{
	# Scream and die if the caller requests a version of this file higher
	# than what we are.

	local($minlevel) = @_;

	if ($GRLIB_ID < $minlevel)
		{
		&gr'finish(1,"[*] grlib-os.pl version mismatch ($GRLIB_ID < $minlevel)\n");
		}
	}

sub gros'popup
	{
	# Display the specified message string in a GUI dialog box. Requires
	# external Win32 program WPOPUP.EXE.
	#
	# Titles and colors are not in my bag o'goodies yet.  Maybe later...
	# You can put "\\n" for line breaks in the message, tho.

	local($type,$title,$message) = @_;

	system("wpopup $message");
	}

sub gros'getpasswd
	{
	# Gets a string from standard input with echo turned off.  Requires
	# external console-mode program GETPASSWD.EXE.

	local($prompt) = @_;

	print $prompt;
	$response = `getpasswd`;
	print "\n";
	chop($response);

	return $response;
	}

sub gros'utime
	{
	# Emulate the utime() function with an external program, since utime()
	# is unimplemented in Win32 Perl.  Requires external console-mode 
	# program UTIME.EXE.

	local($atime, $mtime, @files) = @_;

	$" = " ";
	local($rc) = system("utime $atime $mtime @files");

	return ($rc >> 8);
	}

sub gros'chooser
	{
	# NOTE!!!
	#
	# Commas are apparently interpreted the same as spaces by CMD.EXE.
	# What a brilliant idea!  grumble, grumble...
	# PEC lists will have to enclosed in quotes for this feature to
	# work right.
	#
    local($peclist,$fixid) = @_;

    if (index($peclist,",") < $[)
        {
        return $peclist;
        }

    $text = ($fixid eq "ANY") ? "This fixture" : "Fixture #$fixid";

	system "CLS";

	$choice = "";
	$ambig  = 0;
	while (!$choice)
		{
		print "\n\n$text supports multiple test programs.\n\n";

		$c=0;
		foreach $pec (split(/,/,$peclist))
			{
			($upec = $pec) =~ tr/a-z/A-Z/;
			printf("%2d. %s\n", ($c+1), $upec);
			$CHOICE[$c++] = $pec;
			}

		print "\nPlease choose: ";
		$response = <STDIN>;
		chomp($response);

		# try for numeric match
		for ($i=0; $i<$c; $i++)
			{
			if ($response eq ($i+1))
				{
				$choice = $CHOICE[$i];
				last;
				}
			}

		next if (length($response) < 2);

		# if 2 chars or more try for unambiguous string match
		$ambig = 0;
		for ($i=0; $i<$c; $i++)
			{
			if ($CHOICE[$i] =~ /$response/i)
				{
				$ambig++;
				$choice = $CHOICE[$i];
				}
			}

		# must match unambiguously
		if ($ambig == 1)
			{ last; }
		else
			{ $choice = ""; }

		}

	return $choice;
	}


sub gros'fixture_chooser
	{
	# NOTE!!!
	#
	# Commas are apparently interpreted the same as spaces by CMD.EXE.
	# What a brilliant idea!  grumble, grumble...
	# PEC lists will have to enclosed in quotes for this feature to
	# work right.
	#
    local($fixlist,$progid) = @_;

    if (index($fixlist,",") < $[)
        {
        return $fixlist;
        }

	system "CLS";

	$choice = "";
	$ambig  = 0;
	while (!$choice)
		{
		print "\n\n$progid supports multiple configurations.\n\n";

		$c=0;
		foreach $pec (split(/,/,$fixlist))
			{
			($upec = $pec) =~ tr/a-z/A-Z/;
			printf("%2d. %s\n", ($c+1), $upec);
			$CHOICE[$c++] = $pec;
			}

		print "\nPlease choose: ";
		$response = <STDIN>;
		chomp($response);

		# try for numeric match
		for ($i=0; $i<$c; $i++)
			{
			if ($response eq ($i+1))
				{
				$choice = $CHOICE[$i];
				last;
				}
			}

		next if (length($response) < 2);

		# if 2 chars or more try for unambiguous string match
		$ambig = 0;
		for ($i=0; $i<$c; $i++)
			{
			if ($CHOICE[$i] =~ /$response/i)
				{
				$ambig++;
				$choice = $CHOICE[$i];
				}
			}

		# must match unambiguously
		if ($ambig == 1)
			{ last; }
		else
			{ $choice = ""; }

		}

	return $choice;
	}


sub gros'symlink
	{
	# Under Unix this would create a symbolic link, but on Windows NT all
	# we can do is just copy the original file to another file and give it
	# the name of the desired link.  Who's idea was it to switch to this
	# overgrown DOS dinosaur?  Grumble, grumble...

	local($file, $link) = @_;

	if (-f $link) { unlink $link; }

	open(ORIGINAL,$file);
	open(LINKFILE,">$link");
	while (<ORIGINAL>) { print LINKFILE $_; }
	close ORIGINAL;
	close LINKFILE;

	}

1;
