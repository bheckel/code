# Configuration Perl library for the grsuite.
#
# This lib should be required in 'main' namespace AFTER the
# OS-specific library is required.
#
# 5-Feb-1997
# Mark Hewett
# Modified: 14-Apr-2000 (Bob Heckel -- protect source)
# Northern Telecom, RTP, NC

# general constants
$FTP_PORT             = 21;
$FTP_CONNECT_ATTEMPTS = 3;
$FTP_TIMEOUT          = 15;
$BUTLER_PORT          = 2001;
$TDC = "vs (\$0 !~ /^\$znva'RKRP_CNGU/v) { &svavfu(1,\"Gnzcrevat qrgrpgrq.\\a\"); }";

# server-side config data
$DEFSERVER   = "grserver";
$DEFACCOUNT  = "gr8xprog";
$DEFPASSWORD = "1TE4hazr";
$DEFARCHROOT = "/gr8xprog";
$RELDATA     = "release.dat";
$LOGFILE     = "/gr8xprog/access_log";

# file lists
@TEST_FILELIST  = ('.obc','.idd','.smt','.ncl',
                   '.ddb','.ddf','.pod','.inv','%PEC%.bat');
@SRC_FILELIST   = ('.tpg','.ckt');
@PATCH_FILELIST = ('.dbt','.obc','.pod');
@CLEAN_FILELIST = ('.tpg','.obc');

$FILE_OPTIONS{'.inv'} = "OPTIONAL,INVENTORY";
$FILE_OPTIONS{'.ncl'} = "OPTIONAL";
$FILE_OPTIONS{'.ddb'} = "OPTIONAL";
$FILE_OPTIONS{'.ddf'} = "OPTIONAL";
$FILE_OPTIONS{'.pod'} = "OPTIONAL";

# authorization data
$AUTHENTICATE_ALL = 0;		# for DEBUG only (normally zero to deactivate);
# Now checking all users when they request the source .tpg and .ckt files.
$PROTECT_SOURCE   = 1;
$AUTHORIZED_GIDS{'PUT'}     = "10,0";
$AUTHORIZED_GIDS{'RELEASE'} = "10,0";
$AUTHORIZED_GIDS{'PATCH'}   = "11,10,0";

1;
