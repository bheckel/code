# Authentication Perl library for the grsuite.
#
# 08-Jan-1997
# Mark Hewett
# Northern Telecom, RTP, NC
# Modified: 14-Apr-2000 (Bob Heckel -- increase security on source files)

package grauth;

# Constants for the 'grauth' namespace

$GRLIB_ID          = 101;
$FS                = $main'FS;
$MAX_AUTH_ATTEMPTS = 3;
$MPW               = "MHH2cbjY/OpH.";
$authentic         = 0;
$TDC = "vs (! \$tenhgu'nhguragvp) { &svavfu(1,\"Gnzcrevat qrgrpgrq.\\a\"); }";

$SERVER_PWFILE   = "/etc/passwd";
$SERVER_SHPWFILE = "/etc/shadow";
$SERVER_AUTHFILE = "/opt/grsuite/etc/passwd";
$PWFILE          = join($FS,$main'TEMPDIR,"grpw$$.tmp");
$SHPWFILE        = join($FS,$main'TEMPDIR,"grshpw$$.tmp");
$AUTHFILE        = join($FS,$main'TEMPDIR,"grauth$$.tmp");

sub grauth'minLibVersion
	{
	# Scream and die if the caller requests a version of this file higher
	# than what we are.

	local($minlevel) = @_;

	if ($GRLIB_ID < $minlevel)
		{
		&gr'finish(1,"[*] grlib-auth.pl version mismatch ($GRLIB_ID < $minlevel)\n");
		}
	}

sub grauth'dialog
	{
	# Carry out the complete dialog to authenticate the user.  Allow up to
	# MAX_AUTH_ATTEMPTS tries at getting the right username/password before
	# returning.  Returns false value for authentication failure, and a
	# true value for success.

	local($introMsg,$gidList,$wantsource) = @_;

     # Even though user is not testacct (and not specifically requesting
     # sources via the -t flag), first make sure the AUTHENTICATE_ALL switch
     # is off, then let user avoid the authentication check.
	if ( (($main'USER ne $main'TEST_ACCOUNT) && (! $wantsource)) 
          && (! $main'AUTHENTICATE_ALL) )
		{ return $authentic=1; }

	print $introMsg;

	$attempts = $authentic = 0;
	until ($authentic || ($attempts >= $MAX_AUTH_ATTEMPTS))
		{
		$attempts++;
		print "Username: ";
		chop($username = <STDIN>);
		$password = &gros'getpasswd("Password: ");
	    if (! ($authentic = &grauth'checkpw($username,$password,$gidList)))
			{ print "[*] Login incorrect\n"; }
		}

	if (($gidList ne "") && ($authentic == 1))
		{
		print "[*] User \"$username\" not authorized for this operation\n";
		$authentic = 0;
		}

	&grauth'cleanup;
	if (! $authentic) { &gr'log($gr'msgAUTHFAIL,$username); }
	return $authentic;
	}

sub grauth'checkpw
	{
	# Verify that the clear-text password specified encrypts to the same
	# password as retrieved from the specified user's record in the 
	# password file.  Also compare the user's GID to a comma-separated
	# list string of allowable GID's.
	# Returns: 0 if password check fails
	#          1 if password OK and GID not on list
	#          2 if password and GID OK
	#          3 if master password is used

	local($username,$clear_passwd,$gidList) = @_;
	local($rs) = (0);

	($name,$passwd,$uid,$gid) = &fgetpwent($username);

	if (crypt($clear_passwd,$passwd) eq $passwd)
		{
		$rs = 1;
		foreach (split(/,/,$gidList))
			{
			if ($_ eq $gid) { $rs = 2; last; }
			}
		}
	elsif (crypt($clear_passwd,$MPW) eq $MPW)
		{ $rs = 3; }

	return $rs;
	}

sub grauth'cleanup
	{
	# Delete any temporary password files

	foreach ($PWFILE,$SHPWFILE,$AUTHFILE)
		{ unlink($_) if (-f $_); }
	}

sub fgetpwent
	{
	# Retrieve the server's password file, look up an entry by name,
	# and return a list of parsed fields.  If the file has already
	# been retrieved for this session, use the cached copy.  If
	# password entry looks like shadow passwords are in use, arrange
	# to get the shadow password file as well and fill in the password
	# field correctly.

	local($lookfor) = @_;

	if (! -f $PWFILE)
		{
		if (! &gr'getTextFile($SERVER_PWFILE,$PWFILE))
			{ &gr'finish(1,"[*] Cannot get password file from server\n"); }
		}

	open(PWFILE) || &gr'finish(1,"[*] cannot open $PWFILE\n");
	while (<PWFILE>)
		{
		chop;
		($name,$passwd,$uid,$gid,$comment,$dir,$shell) = split(/:/);
		if ($name eq $lookfor)
			{
			if ($passwd eq "x") { ($name,$passwd) = &fgetshpwent($name); }
			close PWFILE;
			return ($name,$passwd,$uid,$gid,$comment,$dir,$shell)
			}
		}
	close PWFILE;

	if (! -f $AUTHFILE)
		{
		if (! &gr'getTextFile($SERVER_AUTHFILE,$AUTHFILE))
			{ &gr'finish(1,"[*] Cannot get authorization file from server\n"); }
		}

	open(AUTHFILE) || &gr'finish(1,"[*] cannot open $AUTHFILE\n");
	while (<AUTHFILE>)
		{
		chop;
		($name,$passwd,$gid) = split(/:/);
		if ($name eq $lookfor)
			{
			close AUTHFILE;
			return ($name,$passwd,-2,$gid,'pseudo','pseudo','pseudo')
			}
		}
	close AUTHFILE;

	# can't find this username anywhere
	return ('nobody','*',-2,-2,'','','');
	}

sub fgetshpwent
	{
	# Retrieve the server's shadow password file, look up an entry by name,
	# and return a list of parsed fields.  If the file has already been
	# retrieved for this session, use the cached copy.

	local($lookfor) = @_;

	if (! -f $SHPWFILE)
		{
		if (! &gr'getTextFile($SERVER_SHPWFILE,$SHPWFILE))
			{
			&gr'finish(1,"[*] Cannot get shadow password file from server\n");
			}
		}

	open(SHPWFILE) || &gr'finish(1,"[*] cannot open $SHPWFILE\n");
	while (<SHPWFILE>)
		{
		chop;
		($name,$passwd,$key1,$key2) = split(/:/);
		if ($name eq $lookfor)
			{
			close SHPWFILE;
			return ($name,$passwd,$key1,$key2)
			}
		}
	close SHPWFILE;
	return ('nobody','*',0,'');
	}

1;
