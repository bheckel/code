-- Use the PC IP address
call dbms_debug_jdwp.connect_tcp ('12.247.59.125', '2125');