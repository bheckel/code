BEGIN
   DBMS_OUTPUT.put_line (DBMS_SQL.open_cursor ());
   DBMS_OUTPUT.put_line (DBMS_SQL.open_cursor ());
   DBMS_OUTPUT.put_line (DBMS_SQL.open_cursor ());
END;