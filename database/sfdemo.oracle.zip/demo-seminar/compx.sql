create or replace procedure compx is begin null; end;
