# include <lib.h>

int main() {
  bill("Helowrld");
  exit(0);
}
