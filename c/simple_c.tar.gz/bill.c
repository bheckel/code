# include <stdio.h>

void bill(char *arg) {
  printf("bill has passed: %s\n", arg);
}

