/* Testing Beginning Linux Programming */
/* Created: Sat, 13 May 2000 16:38:30 (Bob Heckel) */

void bill(char *);
void fred(int);
void red(int);
