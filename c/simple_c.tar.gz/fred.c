# include <stdio.h>

void fred(int arg) {
  printf("fred has passed: %d\n", arg);
}


